# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

import os
import os.path as op
import time
import weakref
from io import BytesIO

import numpy as np
from scipy.interpolate import interp1d

from ..._freesurfer import _estimate_talxfm_rigid
from ...defaults import _handle_default
from ...surface import _decimate_surface_ico_oct, _mesh_borders, mesh_edges
from ...transforms import apply_trans
from ...utils import (
    Bunch,
    _auto_weakref,
    _check_option,
    _ensure_int,
    _path_like,
    _to_rgb,
    _validate_type,
    fill_doc_static,
    get_subjects_dir,
    logger,
    use_log_level,
    verbose_static,
    warn,
)
from .._3d import _check_views, _handle_time, _process_clim
from .._3d_overlay import LayeredMesh
from ..ui_events import (
    ColormapRange,
    TimeChange,
    _ColormapRangeUpdated,
    _get_event_channel,
    _OverlayAdded,
    _SurfaceUpdated,
    _TimeUpdated,
    publish,
    subscribe,
    unsubscribe,
)
from ..utils import (
    _generate_default_filename,
    _is_dark,
    _save_ndarray_img,
    concatenate_images,
    safe_event,
)
from ._movie import _MovieMixin
from ._scene import _SceneMixin
from ._time_viewer import _TimeViewerMixin
from .colormap import _CORTEX_PRESETS, calculate_lut
from .surface import _Surface
from .view import views_dicts


def _resolve_offset(offset, surf, hemi):
    if isinstance(offset, str):
        offset = surf in ("inflated", "flat")
    return None if (not offset or hemi != "both") else 0.0


@fill_doc_static("views", "view_layout", "theme_3d")
class Brain(_SceneMixin, _MovieMixin, _TimeViewerMixin):
    """Class for visualizing a brain.

    .. warning::
       The API for this class is not currently complete. We suggest using
       :meth:`mne.viz.plot_source_estimates` with the PyVista backend
       enabled to obtain a ``Brain`` instance.

    Parameters
    ----------
    subject : str
        Subject name in FreeSurfer subjects dir.

        .. versionchanged:: 1.2
           This parameter was renamed from ``subject_id`` to ``subject``.
    hemi : str
        Hemisphere id (ie 'lh', 'rh', 'both', or 'split'). In the case
        of 'both', both hemispheres are shown in the same window.
        In the case of 'split' hemispheres are displayed side-by-side
        in different viewing panes.
    surf : str
        FreeSurfer surface mesh name (ie 'white', 'inflated', etc.). Can also be
        ``'flat'`` to show a flat patch of the cortex, which requires the
        ``?h.cortex.patch.flat`` and ``?h.sphere`` files to be present in the
        subject's ``surf`` directory. A flat surface is always shown with
        ``views='flat'`` and is not rotatable.
    title : str
        Title for the window.
    cortex : str, list, dict
        Specifies how the cortical surface is rendered. Options:

        1. The name of one of the preset cortex styles:
            ``'classic'`` (default), ``'high_contrast'``,
            ``'low_contrast'``, or ``'bone'``.
        2. A single color-like argument to render the cortex as a single
            color, e.g. ``'red'`` or ``(0.1, 0.4, 1.)``.
        3. A list of two color-like used to render binarized curvature
            values for gyral (first) and sulcal (second). regions, e.g.,
            ``['red', 'blue']`` or ``[(1, 0, 0), (0, 0, 1)]``.
        4. A dict containing keys ``'vmin', 'vmax', 'colormap'`` with
            values used to render the binarized curvature (where 0 is gyral,
            1 is sulcal).

        .. versionchanged:: 0.24
           Add support for non-string arguments.
    alpha : float in [0, 1]
        Alpha level to control opacity of the cortical surface.

        See :meth:`set_cortex_alpha` to change this after creation.
    size : int | array-like, shape (2,)
        The size of the window, in pixels. can be one number to specify
        a square window, or a length-2 sequence to specify (width, height).
    background : matplotlib color
        The color of the background, e.g. ``"black"`` (default), ``"w"``, a
        hex string such as ``"#000000"``, or an RGB tuple of floats between
        0 and 1, e.g. ``(0, 0, 0)``.
    foreground : matplotlib color
        Color of the foreground (will be used for colorbars and text).
        None (default) will use black or white depending on the value
        of ``background``.
    figure : list of Figure | None
        If None (default), a new window will be created with the appropriate
        views.
    subjects_dir : str | None
        If not None, this directory will be used as the subjects directory
        instead of the value set using the SUBJECTS_DIR environment
        variable.
    views : str | list
        View to use. Using multiple views (list) is not supported for mpl
        backend. See :meth:`Brain.show_view <mne.viz.Brain.show_view>` for
        valid string options.
    offset : bool | str
        If True, shifts the right- or left-most x coordinate of the left and
        right surfaces, respectively, to be at zero. This is useful for viewing
        inflated surface where hemispheres typically overlap. Can be "auto"
        (default) use True with inflated surfaces and False otherwise
        (Default: 'auto'). Only used when ``hemi='both'``.

        .. versionchanged:: 0.23
           Default changed to "auto".
    interaction : str
        Can be "trackball" (default) or "terrain", i.e. a turntable-style
        camera.
    units : str
        Can be 'm' or 'mm' (default).
    view_layout : str
        Can be "vertical" (default) or "horizontal". When using "horizontal" mode,
        the PyVista backend must be used and hemi cannot be "split".
    silhouette : dict | bool
       As a dict, it contains the ``color``, ``linewidth``, ``alpha`` opacity
       and ``decimate`` of the brain's silhouette to display. ``decimate`` can be
       a level of decimation between 0 and 1, None for no decimation, or a spacing
       string (e.g. ``"ico4"``, ``"oct6"``) to instead pick vertices the same way
       :func:`mne.setup_source_space` does, which is faster and better preserves
       the shape than plain decimation. If True, ``"ico5"`` is used and
       if False, no silhouette will be displayed. Defaults to False.

       .. versionchanged:: 1.13
          The default ``decimate`` value changed from ``0.9`` to ``"ico5"``.

       See :meth:`set_silhouette_line_width` to change the line width (or
       show/hide the silhouette) after creation.
    theme : str | path-like
        Can be "auto", "light", or "dark" or a path-like to a
        custom stylesheet. For Dark-Mode and automatic Dark-Mode-Detection,
        `qdarkstyle <https://github.com/ColinDuquesnoy/QDarkStyleSheet>`__ and
        `darkdetect <https://github.com/albertosottile/darkdetect>`__,
        respectively, are required.
        If None (default), the config option MNE_3D_OPTION_THEME will be used,
        defaulting to "auto" if it's not found.
    show : bool
        Display the window as soon as it is ready. Defaults to True.

    Attributes
    ----------
    geo : dict
        A dictionary of PyVista surface objects for each hemisphere.
    overlays : dict
        The overlays.
    layered_meshes : dict
        A dictionary of :class:`~mne.viz.LayeredMesh` objects, one per
        hemisphere, used for compositing overlays during real-time streaming.

        .. versionadded:: 1.13

    Notes
    -----
    The figure will publish and subscribe to the following UI events:

    * :class:`~mne.viz.ui_events.TimeChange`
    * :class:`~mne.viz.ui_events.PlaybackSpeed`
    * :class:`~mne.viz.ui_events.ColormapRange`, ``kind="distributed_source_power"``
    * :class:`~mne.viz.ui_events.VertexSelect`

    This table shows the capabilities of each Brain backend ("✓" for full
    support, and "-" for partial support):

    .. table::
       :widths: auto

       +-------------------------------------+--------------+---------------+
       | 3D function:                        | surfer.Brain | mne.viz.Brain |
       +=====================================+==============+===============+
       | :meth:`add_annotation`              | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_data`                    | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_dipole`                  |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_foci`                    | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_forward`                 |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_head`                    |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_label`                   | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_sensors`                 |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_skull`                   |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_text`                    | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_volume_labels`           |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`close`                       | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | data                                | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | foci                                | ✓            |               |
       +-------------------------------------+--------------+---------------+
       | labels                              | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_data`                 |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_dipole`               |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_forward`              |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_head`                 |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_labels`               | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_annotations`          | -            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_sensors`              |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_skull`                |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_text`                 |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`remove_volume_labels`        |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`save_image`                  | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`save_movie`                  | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`screenshot`                  | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`show_view`                   | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | TimeViewer                          | ✓            | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`get_picked_points`           |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | :meth:`add_data(volume) <add_data>` |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | view_layout                         |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | flatmaps                            |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | vertex picking                      |              | ✓             |
       +-------------------------------------+--------------+---------------+
       | label picking                       |              | ✓             |
       +-------------------------------------+--------------+---------------+
    """

    # Tracks live instances when MNE_3D_BACKEND_TESTING is set (see
    # __init__), so that tests can check for lingering instances without
    # having to scan gc.get_objects() for the whole process.
    _instances = weakref.WeakSet()

    def __init__(
        self,
        subject,
        hemi="both",
        surf="pial",
        title=None,
        cortex="classic",
        alpha=1.0,
        size=800,
        background="black",
        foreground=None,
        figure=None,
        subjects_dir=None,
        views="auto",
        *,
        offset="auto",
        interaction="trackball",
        units="mm",
        view_layout="vertical",
        silhouette=False,
        theme=None,
        show=True,
    ):
        from ..backends import renderer as _renderer_mod
        from ..backends.renderer import _get_renderer, backend

        _validate_type(subject, str, "subject")
        self._surf = surf
        self._offset_request = offset
        if hemi is None:
            hemi = "vol"
        hemi = self._check_hemi(hemi, extras=("both", "split", "vol"))
        if hemi in ("both", "split"):
            self._hemis = ("lh", "rh")
        else:
            assert hemi in ("lh", "rh", "vol")
            self._hemis = (hemi,)
        self._view_layout = _check_option(
            "view_layout", view_layout, ("vertical", "horizontal")
        )

        if figure is not None and not isinstance(figure, int):
            backend._check_3d_figure(figure)
        if title is None:
            self._title = subject
        else:
            self._title = title
        self._interaction = "trackball"

        self._bg_color = _to_rgb(background, name="background")
        if foreground is None:
            foreground = "w" if _is_dark(self._bg_color, name="background") else "k"
        self._fg_color = _to_rgb(foreground, name="foreground")
        del background, foreground
        views = _check_views(surf, views, hemi)
        col_dict = dict(lh=1, rh=1, both=1, split=2, vol=1)
        shape = (len(views), col_dict[hemi])
        if self._view_layout == "horizontal":
            shape = shape[::-1]
        self._subplot_shape = shape

        size = tuple(np.atleast_1d(size).round(0).astype(int).flat)
        if len(size) not in (1, 2):
            raise ValueError(
                '"size" parameter must be an int or length-2 sequence of ints.'
            )
        size = size if len(size) == 2 else size * 2  # 1-tuple to 2-tuple
        subjects_dir = get_subjects_dir(subjects_dir)
        if subjects_dir is not None:
            subjects_dir = str(subjects_dir)

        self.time_viewer = False
        self._hash = time.time_ns()
        # This is only used in testing! Needs self._hash to already be set,
        # since Brain.__hash__ (used when adding to the WeakSet) depends on it.
        if _renderer_mod.MNE_3D_BACKEND_TESTING:
            Brain._instances.add(self)
        self._hemi = hemi
        self._units = units
        self._alpha = float(alpha)
        self._subject = subject
        self._subjects_dir = subjects_dir
        self._views = views
        self._times = None
        self._vertex_to_label_id = dict()
        self._annotation_labels = dict()
        self._labels = {"lh": list(), "rh": list()}
        self._unnamed_label_id = 0  # can only grow
        self._annots = {"lh": list(), "rh": list()}
        self.layered_meshes = dict()
        self._actors = dict()
        self._cleaned = False
        # default values for silhouette
        self._silhouette = {
            "color": self._bg_color,
            "line_width": 2,
            "alpha": alpha,
            "decimate": "ico5",
        }
        _validate_type(silhouette, (dict, bool), "silhouette")
        if isinstance(silhouette, dict):
            self._silhouette.update(silhouette)
            self.silhouette = True
        else:
            self.silhouette = silhouette
        if self.silhouette and surf == "flat":
            raise ValueError('silhouette is not supported for surf="flat"')
        self._silhouette_actors = []
        self._scalar_bar = None
        self._scalar_bar_ticks = None
        # for now only one time label can be added
        # since it is the same for all figures
        self._time_label_added = False
        self._all_data = {}
        self._active_data_key = None
        self._foci_data = {}
        self.geo = {}
        self.set_time_interpolation("nearest")

        geo_kwargs = self._cortex_colormap(cortex)
        # evaluate at the midpoint of the used colormap
        val = -geo_kwargs["vmin"] / (geo_kwargs["vmax"] - geo_kwargs["vmin"])
        self._brain_color = geo_kwargs["colormap"](val)
        self._cortex_preset = cortex if cortex in _CORTEX_PRESETS else "classic"

        # load geometry for one or both hemispheres as necessary
        _validate_type(offset, (str, bool), "offset")
        if isinstance(offset, str):
            _check_option("offset", offset, ("auto",), extra="when str")
        offset = _resolve_offset(offset, surf, hemi)
        logger.debug(f"Hemi offset: {offset}")
        _validate_type(theme, (str, None), "theme")
        self._renderer = _get_renderer(
            name=self._title, size=size, bgcolor=self._bg_color, shape=shape, fig=figure
        )
        self._renderer._window_close_connect(self._clean)
        self._renderer._window_set_theme(theme)
        self.plotter = self._renderer.plotter
        self.widgets = dict()
        self._setup_canonical_rotation()

        # plot hemis
        for h in ("lh", "rh"):
            if h not in self._hemis:
                continue  # don't make surface if not chosen
            # Initialize a Surface object as the geometry
            geo = _Surface(
                self._subject,
                h,
                surf,
                self._subjects_dir,
                offset,
                units=self._units,
                x_dir=self._rigid[0, :3],
            )
            # Load in the geometry and curvature
            geo.load_geometry()
            geo.load_curvature()
            self.geo[h] = geo
            for _, _, v in self._iter_views(h):
                if self.layered_meshes.get(h) is None:
                    mesh = LayeredMesh(
                        renderer=self._renderer,
                        vertices=self.geo[h].coords,
                        triangles=self.geo[h].faces,
                        normals=self.geo[h].nn,
                    )
                    mesh._map()
                    if self.geo[h].bin_curv is None:
                        scalars = mesh._default_scalars[:, 0]
                    else:
                        scalars = self.geo[h].bin_curv
                    mesh.add_overlay(
                        scalars=scalars,
                        colormap=geo_kwargs["colormap"],
                        rng=[geo_kwargs["vmin"], geo_kwargs["vmax"]],
                        opacity=alpha,
                        name="curv",
                    )
                    self.layered_meshes[h] = mesh
                else:
                    actor = self.layered_meshes[h]._actor
                    self._renderer.plotter.add_actor(actor, render=False)
                self._set_camera(**views_dicts[h][v])

        if self.silhouette:
            self._add_silhouette()

        self.interaction = interaction
        self._closed = False
        if show:
            self.show()
        # update the views once the geometry is all set
        for h in self._hemis:
            for ri, ci, v in self._iter_views(h):
                self.show_view(v, row=ri, col=ci, hemi=h, update=False)

        if surf == "flat":
            self._renderer.set_interaction("rubber_band_2d")
            self._fit_flat_camera()

        self._renderer._update()

    def _setup_canonical_rotation(self):
        self._rigid = np.eye(4)
        try:
            xfm = _estimate_talxfm_rigid(self._subject, self._subjects_dir)
        except Exception:
            logger.info(
                "Could not estimate rigid Talairach alignment, using identity matrix"
            )
        else:
            self._rigid[:] = xfm

    @safe_event
    def _clean(self):
        # resolve the reference cycle
        self._renderer._window_close_disconnect()
        self.remove_annotations()
        # clear init actors
        for hemi in self.layered_meshes:
            self.layered_meshes[hemi]._clean()
        for actor in getattr(self, "_silhouette_actors", None) or ():
            self.plotter.remove_actor(actor)
        self._silhouette_actors = None
        self._clear_callbacks()
        # XXX this should be done in PyVista
        for renderer in getattr(self._renderer, "_all_renderers", ()):  # VTK only
            renderer.RemoveAllLights()
        # app_window cannot be set to None because it is used in __del__
        for key in ("lighting", "interactor", "_RenderWindow"):
            setattr(self.plotter, key, None)
        # Qt LeaveEvent requires _Iren so we use _FakeIren instead of None
        # to resolve the ref to vtkGenericRenderWindowInteractor
        self.plotter._Iren = _FakeIren()
        if getattr(self.plotter, "picker", None) is not None:
            self.plotter.picker = None
        for picker in ("_picker", "_hover_picker"):
            if getattr(self._renderer, picker, None) is not None:
                setattr(self._renderer, picker, None)
        # XXX end PyVista
        for key in (
            "plotter",
            "_scalar_bar",
            "_scalar_bar_ticks",
            "geo",
            "_all_data",
        ):
            setattr(self, key, None)
        self._cleaned = True

    def apply_auto_scaling(self):
        """Detect automatically fitting scaling parameters."""
        if self._data is not None:
            self._update_current_time_idx(self._data["time_idx"])
        self._update_auto_scaling()

    def restore_user_scaling(self):
        """Restore original scaling parameters."""
        self._update_auto_scaling(restore=True)

        # the tick actor repositions itself on every render (see
        # _add_scalarbar_ticks), so no explicit update is needed here

    def _has_flatmaps(self):
        """Whether this subject has the patch files a flat surface needs."""
        return all(
            op.isfile(
                op.join(
                    self._subjects_dir, self._subject, "surf", f"{h}.cortex.patch.flat"
                )
            )
            for h in self._hemis
            if h != "vol"
        )

    def _on_time_change(self, event):
        """Respond to a time change UI event."""
        if event.time == self._current_time:
            return
        time_idx = self._to_time_index(event.time)
        self._update_current_time_idx(time_idx)
        publish(self, _TimeUpdated())
        self._renderer._update()

    def _on_colormap_range(self, event):
        """Respond to the colormap_range UI event."""
        if event.kind != "distributed_source_power":
            return
        lims = {key: getattr(event, key) for key in ("fmin", "fmid", "fmax", "alpha")}
        # Check if limits have changed at all.
        if all(val is None or val == self._data[key] for key, val in lims.items()):
            return
        # Update the render.
        self._update_colormap_range(**lims)
        publish(self, _ColormapRangeUpdated())
        self._renderer._update()

    def _clear_callbacks(self):
        # Remove the default key binding
        if getattr(self, "iren", None) is not None:
            self.plotter.iren.clear_key_event_callbacks()

    @property
    def interaction(self):
        """The interaction style."""
        return self._interaction

    @interaction.setter
    def interaction(self, interaction):
        """Set the interaction style."""
        _validate_type(interaction, str, "interaction")
        if self._surf == "flat":
            # a flat map is 2D: the rubber-band style is the only one that makes
            # sense, and a 3D style would leave it rotatable with no way back
            if interaction != self._interaction:
                warn(
                    f'interaction="{interaction}" is ignored for surf="flat", '
                    "which is always shown in 2D"
                )
            interaction = "rubber_band_2d"
        else:
            _check_option("interaction", interaction, ("trackball", "terrain"))
        self._interaction = interaction
        for _ in self._iter_views("vol"):  # will traverse all
            self._renderer.set_interaction(interaction)

    def _cortex_colormap(self, cortex):
        """Return the colormap corresponding to the cortex."""
        from matplotlib.colors import ListedColormap

        from .._3d import _get_cmap

        colormap_map = dict(
            classic=dict(colormap="Greys", vmin=-1, vmax=2),
            high_contrast=dict(colormap="Greys", vmin=-0.1, vmax=1.3),
            low_contrast=dict(colormap="Greys", vmin=-5, vmax=5),
            bone=dict(colormap="bone_r", vmin=-0.2, vmax=2),
        )
        _validate_type(cortex, (str, dict, list, tuple), "cortex")
        if isinstance(cortex, str):
            if cortex in colormap_map:
                cortex = colormap_map[cortex]
            else:
                cortex = [cortex] * 2
        if isinstance(cortex, list | tuple):
            _check_option(
                "len(cortex)",
                len(cortex),
                (2, 3),
                extra="when cortex is a list or tuple",
            )
            if len(cortex) == 3:
                cortex = [cortex] * 2
            cortex = list(cortex)
            for ci, c in enumerate(cortex):
                cortex[ci] = _to_rgb(c, name="cortex")
            cortex = dict(
                colormap=ListedColormap(cortex, name="custom binary"), vmin=0, vmax=1
            )
        cortex = dict(
            vmin=float(cortex["vmin"]),
            vmax=float(cortex["vmax"]),
            colormap=_get_cmap(cortex["colormap"]),
        )
        return cortex

    def _remove(self, item, render=False):
        """Remove actors from the rendered scene."""
        if item in self._actors:
            logger.debug(f"Removing {len(self._actors[item])} {item} actor(s)")
            for actor in self._actors[item]:
                self._renderer.plotter.remove_actor(actor, render=False)
            self._actors.pop(item)  # remove actor list
            if render:
                self._renderer._update()

    def _add_actor(self, item, actor):
        """Add an actor to the internal register."""
        if item in self._actors:  # allows adding more than one
            self._actors[item].append(actor)
        else:
            self._actors[item] = [actor]

    @verbose_static(
        "fmin_fmid_fmax",
        "thresh",
        "center",
        "transparent",
        "time_label",
        "src_volume_options",
    )
    def add_data(
        self,
        array,
        fmin=None,
        fmid=None,
        fmax=None,
        thresh=None,
        center=None,
        transparent=False,
        colormap="auto",
        alpha=1,
        vertices=None,
        smoothing_steps=None,
        time=None,
        time_label="auto",
        colorbar=True,
        hemi=None,
        remove_existing=None,
        time_label_size=None,
        initial_time=None,
        scale_factor=None,
        vector_alpha=None,
        clim=None,
        src=None,
        volume_options=0.4,
        colorbar_kwargs=None,
        key="data",
        verbose=None,
    ):
        """Display data from a numpy array on the surface or volume.

        This provides a similar interface to PySurfer, but it displays
        it with a single colormap. It offers more flexibility over the
        colormap, and provides a way to display four-dimensional data
        (i.e., a timecourse) or five-dimensional data (i.e., a
        vector-valued timecourse).

        .. note:: ``fmin`` sets the low end of the colormap, and is separate
                  from thresh (this is a different convention from PySurfer).

        Parameters
        ----------
        array : numpy array, shape (n_vertices[, 3][, n_times])
            Data array. For the data to be understood as vector-valued
            (3 values per vertex corresponding to X/Y/Z surface RAS),
            then ``array`` must be have all 3 dimensions.
            If vectors with no time dimension are desired, consider using a
            singleton (e.g., ``np.newaxis``) to create a "time" dimension
            and pass ``time_label=None`` (vector values are not supported).
        fmin : float
            Minimum value in colormap (uses real fmin if None).
        fmid : float
            Intermediate value in colormap (fmid between fmin and
            fmax if None).
        fmax : float
            Maximum value in colormap (uses real max if None).
        thresh : None or float
            Not supported yet.
            If not None, values below thresh will not be visible.
        center : float or None
            If not None, center of a divergent colormap, changes the meaning of
            fmin, fmax and fmid.
        transparent : bool | None
            If True: use a linear transparency between fmin and fmid
            and make values below fmin fully transparent (symmetrically for
            divergent colormaps). None will choose automatically based on colormap
            type.
        colormap : str, list of color, or array
            Name of matplotlib colormap to use, a list of matplotlib colors,
            or a custom look up table (an n x 4 array coded with RBGA values
            between 0 and 255), the default "auto" chooses a default divergent
            colormap, if "center" is given (currently "icefire"), otherwise a
            default sequential colormap (currently "rocket").
        alpha : float in [0, 1] | array, shape (n_vertices,)
            Alpha level to control opacity of the overlay. A scalar applies
            globally, while a 1D array applies per-vertex opacity.

            .. versionchanged:: 1.12
               Added support for per-vertex alpha.
        vertices : numpy array
            Vertices for which the data is defined (needed if
            ``len(data) < nvtx``).
        smoothing_steps : int or None
            Number of smoothing steps (smoothing is used if len(data) < nvtx)
            The value 'nearest' can be used too. None (default) will use as
            many as necessary to fill the surface.
        time : numpy array
            Time points in the data array (if data is 2D or 3D).
        time_label : str | callable | None
            Format of the time label (a format string, a function that maps
            floating point time values to strings, or None for no label). The
            default is ``'auto'``, which will use ``time=%0.2f ms`` if there
            is more than one time point.
        colorbar : bool
            Whether to add a colorbar to the figure. Can also be a tuple
            to give the (row, col) index of where to put the colorbar.
        hemi : str | None
            If None, it is assumed to belong to the hemisphere being
            shown. If two hemispheres are being shown, an error will
            be thrown.
        remove_existing : bool | None
            If ``True`` or ``None`` (default), the overlay added by the
            previous :meth:`add_data` call is removed before the new one is
            rendered. Set to ``False`` to keep existing overlays and composite
            the new one on top (requires distinct ``key`` values).

            .. versionchanged:: 1.13
               Now accepts ``True`` and ``False`` in addition to ``None``.
        time_label_size : int
            Font size of the time label (default 14).
        initial_time : float | None
            Time initially shown in the plot. ``None`` to use the first time
            sample (default).
        scale_factor : float | None
            The scale factor to use when displaying glyphs for vector-valued
            data.
        vector_alpha : float | None
            Alpha level to control opacity of the arrows. Only used for
            vector-valued data. If None (default), ``alpha`` is used.
        clim : dict
            Original clim arguments.
        src : instance of SourceSpaces | None
            The source space corresponding to the source estimate. Only necessary
            if the STC is a volume or mixed source estimate.
        volume_options : float | dict | None
            Options for volumetric source estimate plotting, with key/value pairs:

            - ``'resolution'`` : float | None
                Resolution (in mm) of volume rendering. Smaller (e.g., 1.) looks
                better at the cost of speed. None (default) uses the volume source
                space resolution, which is often something like 7 or 5 mm,
                without resampling.
            - ``'blending'`` : str
                Can be "mip" (default) for :term:`maximum intensity projection` or
                "composite" for composite blending using alpha values.
            - ``'alpha'`` : float | None
                Alpha for the volumetric rendering. Defaults are 0.4 for vector source
                estimates and 1.0 for scalar source estimates.
            - ``'surface_alpha'`` : float | None
                Alpha for the surface enclosing the volume(s). None (default) will use
                half the volume alpha. Set to zero to avoid plotting the surface.
            - ``'silhouette_alpha'`` : float | None
                Alpha for a silhouette along the outside of the volume. None (default)
                will use ``0.25 * surface_alpha``.
            - ``'silhouette_linewidth'`` : float
                The line width to use for the silhouette. Default is 2.
            - ``'interpolation'`` : str
                The interpolation method to use for resampling the volume source space
                to the specified resolution (and for sampling in the volume rendering).
                Can be "linear" (default) or "nearest".

                .. versionadded:: 1.13

            A float input (default 1.) or None will be used for the ``'resolution'``
            entry.
        colorbar_kwargs : dict | None
            Options to pass to :meth:`pyvista.Plotter.add_scalar_bar`, for
            example ``dict(label_font_size=10)``. By default a ``fmt``
            tick-label format is chosen automatically based on the data
            range. Other options that are often useful include ``n_labels``
            (number of ticks), ``label_font_size``, ``width``/``height``
            (as a fraction of the window), and ``position_x``/``position_y``.
        key : str
            Key used to identify this data overlay in
            ``Brain.layered_meshes``. Defaults to ``"data"``.  When multiple
            overlays are present (``remove_existing=False``), each overlay
            must have a distinct key; the key also becomes the label shown in
            the **Overlay** drop-down in the interactive time viewer (see
            :meth:`setup_time_viewer`).

            .. versionadded:: 1.12
        verbose : bool | str | int | None
            Control verbosity of the logging output. If ``None``, use the default
            verbosity level. See the :ref:`logging documentation <tut-logging>` and
            :func:`mne.verbose` for details. Should only be passed as a keyword
            argument.

        Notes
        -----
        If the data is defined for a subset of vertices (specified
        by the "vertices" parameter), a smoothing method is used to interpolate
        the data onto the high resolution surface. If the data is defined for
        subsampled version of the surface, smoothing_steps can be set to None,
        in which case only as many smoothing steps are applied until the whole
        surface is filled with non-zeros.

        Due to a VTK alpha rendering bug, ``vector_alpha`` is
        clamped to be strictly < 1.
        """
        _validate_type(transparent, bool, "transparent")
        _validate_type(vector_alpha, ("numeric", None), "vector_alpha")
        _validate_type(scale_factor, ("numeric", None), "scale_factor")

        # those parameters are not supported yet, only None is allowed
        _check_option("thresh", thresh, [None])
        _check_option("remove_existing", remove_existing, [None, True, False])
        _validate_type(time_label_size, (None, "numeric"), "time_label_size")
        if time_label_size is not None:
            time_label_size = float(time_label_size)
            if time_label_size < 0:
                raise ValueError(
                    f"time_label_size must be positive, got {time_label_size}"
                )

        hemi = self._check_hemi(hemi, extras=["vol"])
        stc, array, vertices = self._check_stc(hemi, array, vertices)
        array = np.asarray(array)
        vector_alpha = alpha if vector_alpha is None else vector_alpha

        # remove the previously active overlay when not keeping existing ones.
        old_key = self._active_data_key
        if remove_existing is not False and old_key is not None and old_key != key:
            for _hemi in list(self.layered_meshes):
                self.layered_meshes[_hemi].remove_overlay(old_key)
            del self._all_data[old_key]

        self._active_data_key = key
        self._all_data.setdefault(key, {})
        self._all_data[key]["vector_alpha"] = vector_alpha
        self._all_data[key]["scale_factor"] = scale_factor

        # Create time array and add label if > 1D
        if array.ndim <= 1:
            time_idx = 0
        else:
            # check time array
            if time is None:
                time = np.arange(array.shape[-1])
            else:
                time = np.asarray(time)
                if time.shape != (array.shape[-1],):
                    raise ValueError(
                        f"time has shape {time.shape}, but need shape "
                        f"{(array.shape[-1],)} (array.shape[-1])"
                    )
            self._all_data[key]["time"] = time

            if self._n_times is None:
                self._times = time
            elif len(time) != self._n_times:
                raise ValueError("New n_times is different from previous n_times")
            elif not np.array_equal(time, self._times):
                raise ValueError(
                    "Not all time values are consistent with previously set times."
                )

            # initial time
            if initial_time is None:
                time_idx = 0
            else:
                time_idx = self._to_time_index(initial_time)

        # time label
        time_label, _ = _handle_time(time_label, "s", time)
        y_txt = 0.05 + 0.1 * bool(colorbar)

        if array.ndim == 3:
            if array.shape[1] != 3:
                raise ValueError(
                    "If array has 3 dimensions, array.shape[1] must equal 3, got "
                    f"{array.shape[1]}"
                )
        fmin, fmid, fmax = _update_limits(fmin, fmid, fmax, center, array)
        if colormap == "auto":
            colormap = "mne" if center is not None else "hot"

        if smoothing_steps is None:
            smoothing_steps = 7
        elif smoothing_steps == "nearest":
            smoothing_steps = -1
        elif isinstance(smoothing_steps, int):
            if smoothing_steps < 0:
                raise ValueError(
                    "Expected value of `smoothing_steps` is positive but "
                    f"{smoothing_steps} was given."
                )
        else:
            raise TypeError(
                "Expected type of `smoothing_steps` is int or NoneType but "
                f"{type(smoothing_steps)} was given."
            )

        self._all_data[key]["stc"] = stc
        self._all_data[key]["src"] = src
        self._all_data[key]["smoothing_steps"] = smoothing_steps
        self._all_data[key]["clim"] = clim
        self._all_data[key]["time"] = time
        self._all_data[key]["initial_time"] = initial_time
        self._all_data[key]["time_label"] = time_label
        self._all_data[key]["initial_time_idx"] = time_idx
        self._all_data[key]["time_idx"] = time_idx
        self._all_data[key]["transparent"] = transparent
        # data specific for a hemi
        self._all_data[key][hemi] = dict()
        self._all_data[key][hemi]["glyph_dataset"] = None
        self._all_data[key][hemi]["glyph_mapper"] = None
        self._all_data[key][hemi]["glyph_actor"] = None
        self._all_data[key][hemi]["array"] = array
        self._all_data[key][hemi]["vertices"] = vertices
        if (
            stc is None
            and hemi in ("lh", "rh")
            and vertices is not None
            and len(array) == len(vertices)
        ):
            # Synthesize an stc from the raw arrays so that label-mode traces
            # (which use stc.extract_label_time_course) also work when data
            # is passed directly rather than plotted from an stc
            from ...source_estimate import SourceEstimate, VectorSourceEstimate

            stc_verts, stc_data = list(), list()
            for stc_hemi in ("lh", "rh"):
                hemi_data = self._all_data[key].get(stc_hemi)
                if not isinstance(hemi_data, dict) or "array" not in hemi_data:
                    stc_verts.append(np.array([], int))
                    continue
                stc_array = hemi_data["array"]
                if stc_array.ndim == 1:
                    stc_array = stc_array[:, np.newaxis]
                stc_verts.append(hemi_data["vertices"])
                stc_data.append(stc_array)
            if time is not None and len(time) > 1:
                tmin, tstep = time[0], time[1] - time[0]
            else:
                tmin, tstep = 0.0, 1.0
            klass = VectorSourceEstimate if stc_data[0].ndim == 3 else SourceEstimate
            self._all_data[key]["stc"] = klass(
                np.concatenate(stc_data), stc_verts, tmin, tstep, subject=self._subject
            )
        self._all_data[key]["alpha"] = alpha
        self._all_data[key]["colormap"] = colormap
        self._all_data[key]["center"] = center
        self._all_data[key]["fmin"] = fmin
        self._all_data[key]["fmid"] = fmid
        self._all_data[key]["fmax"] = fmax
        self._all_data[key]["colorbar_fmt"] = (colorbar_kwargs or {}).get("fmt")
        self._all_data[key]["colorbar_title"] = (colorbar_kwargs or {}).get(
            "title", key if key != "data" else None
        )
        self.set_time_interpolation(self.time_interpolation)
        self._update_colormap_range()

        # 1) add the surfaces first
        actor = None
        for _ in self._iter_views(hemi):
            if hemi in ("lh", "rh"):
                actor = self.layered_meshes[hemi]._actor
            else:
                src_vol = src[2:] if src.kind == "mixed" else src
                actor, _ = self._add_volume_data(hemi, src_vol, volume_options)
        assert actor is not None  # should have added one
        self._add_actor(key, actor)

        # 2) update time and smoothing properties
        # set_data_smoothing calls "_update_current_time_idx" for us, which will set
        # _current_time
        self.set_data_smoothing(self._all_data[key]["smoothing_steps"])

        # the time viewer reacts by selecting this overlay, which needs its
        # smooth_mat (and, for volumes, its grid) to already exist
        publish(self, _OverlayAdded())

        # 3) add the other actors
        if colorbar is True:
            # bottom left by default
            colorbar = (self._subplot_shape[0] - 1, 0)
        for ri, ci, v in self._iter_views(hemi):
            # Add the time label to the bottommost view
            do = (ri, ci) == colorbar
            if not self._time_label_added and time_label is not None and do:
                time_actor = self._renderer.text2d(
                    x_window=0.95,
                    y_window=y_txt,
                    color=self._fg_color,
                    size=time_label_size,
                    text=time_label(self._current_time),
                    justification="right",
                )
                self._all_data[key]["time_actor"] = time_actor
                self._time_label_added = True
            if colorbar and self._scalar_bar is None and do:
                kwargs = dict(
                    source=actor,
                    n_labels=8,
                    color=self._fg_color,
                    bgcolor=self._brain_color[:3],
                    fmt=_auto_scalar_bar_fmt(self._cmap_range),
                )
                kwargs.update(colorbar_kwargs or {})
                self._scalar_bar, self._scalar_bar_ticks = self._renderer.scalarbar(
                    **kwargs
                )
            self._set_camera(**views_dicts[hemi][v])

        # 4) update the scalar bar and opacity (and render)
        self._update_colormap_range(alpha=alpha)

        # 5) enable UI events to interact with the data
        subscribe(self, "colormap_range", self._on_colormap_range)
        if time is not None and len(time) > 1:
            subscribe(self, "time_change", self._on_time_change)

    def remove_data(self):
        """Remove rendered data from the mesh."""
        for key in list(self._all_data):
            for hemi in list(self.layered_meshes):
                self.layered_meshes[hemi].remove_overlay(key)
            self._remove(key, render=False)
            del self._all_data[key]
        self._active_data_key = None
        self._renderer._update()

        # Stop listening to events
        if "time_change" in _get_event_channel(self):
            unsubscribe(self, "time_change")

    def _iter_views(self, hemi):
        """Iterate over rows and columns that need to be added to."""
        hemi_dict = dict(lh=[0], rh=[0], vol=[0])
        if self._hemi == "split":
            hemi_dict.update(rh=[1], vol=[0, 1])
        for vi, view in enumerate(self._views):
            view_dict = dict(lh=[vi], rh=[vi], vol=[vi])
            if self._hemi == "split":
                view_dict.update(vol=[vi, vi])
            if self._view_layout == "vertical":
                rows, cols = view_dict, hemi_dict  # views are rows, hemis cols
            else:
                rows, cols = hemi_dict, view_dict  # hemis are rows, views cols
            for ri, ci in zip(rows[hemi], cols[hemi]):
                self._renderer.subplot(ri, ci)
                yield ri, ci, view

    def remove_labels(self):
        """Remove all the ROI labels from the image."""
        for hemi in self._hemis:
            for label in self._labels[hemi]:
                self.layered_meshes[hemi].remove_overlay(label.name)
            self._labels[hemi].clear()
        self._renderer._update()

    def remove_annotations(self):
        """Remove all annotations from the image."""
        for hemi, overlayer in self.layered_meshes.items():
            overlayer.remove_overlay([annot["name"] for annot in self._annots[hemi]])
            for annot in self._annots[hemi]:
                if "caption" in annot:
                    for _ in self._iter_views(hemi):
                        self.plotter.remove_actor(annot["caption"], render=False)
                    try:
                        self.plotter.RemoveObserver(annot["obs"])
                    except AttributeError:  # can happen during cleanup
                        pass
            self._annots[hemi].clear()
        self._renderer._update()

    def _add_volume_data(self, hemi, src, volume_options):
        from ...source_space import SourceSpaces
        from ..backends._pyvista import _hide_testing_actor

        _validate_type(src, SourceSpaces, "src")
        _check_option("src.kind", src.kind, ("volume",))
        _validate_type(volume_options, (dict, "numeric", None), "volume_options")
        assert hemi == "vol"
        if not isinstance(volume_options, dict):
            volume_options = dict(
                resolution=float(volume_options) if volume_options is not None else None
            )
        volume_options = _handle_default("volume_options", volume_options)
        allowed_types = (
            ["resolution", (None, "numeric")],
            ["blending", (str,)],
            ["alpha", ("numeric", None)],
            ["surface_alpha", (None, "numeric")],
            ["silhouette_alpha", (None, "numeric")],
            ["silhouette_linewidth", ("numeric",)],
            ["interpolation", (str,)],
        )
        for key, types in allowed_types:
            _validate_type(volume_options[key], types, f"volume_options[{repr(key)}]")
        extra_keys = set(volume_options) - set(a[0] for a in allowed_types)
        if len(extra_keys):
            raise ValueError(f"volume_options got unknown keys {sorted(extra_keys)}")
        blending = _check_option(
            'volume_options["blending"]',
            volume_options["blending"],
            ("composite", "mip"),
        )
        interpolation = _check_option(
            'volume_options["interpolation"]',
            volume_options["interpolation"],
            ("nearest", "linear"),
        )
        alpha = volume_options["alpha"]
        if alpha is None:
            alpha = 0.4 if self._data[hemi]["array"].ndim == 3 else 1.0
        alpha = np.clip(float(alpha), 0.0, 1.0)
        resolution = volume_options["resolution"]
        surface_alpha = volume_options["surface_alpha"]
        if surface_alpha is None:
            surface_alpha = min(alpha / 2.0, 0.1)
        silhouette_alpha = volume_options["silhouette_alpha"]
        if silhouette_alpha is None:
            silhouette_alpha = surface_alpha / 4.0
        silhouette_linewidth = volume_options["silhouette_linewidth"]
        del volume_options
        volume_pos = self._data[hemi].get("grid_volume_pos")
        volume_neg = self._data[hemi].get("grid_volume_neg")
        center = self._data["center"]
        if volume_pos is None:
            xyz = np.meshgrid(*[np.arange(s) for s in src[0]["shape"]], indexing="ij")
            dimensions = np.array(src[0]["shape"], int)
            mult = 1000 if self._units == "mm" else 1
            src_mri_t = src[0]["src_mri_t"]["trans"].copy()
            src_mri_t[:3] *= mult
            if resolution is not None:
                resolution = resolution * mult / 1000.0  # to mm
            del src, mult
            coords = np.array([c.ravel(order="F") for c in xyz]).T
            coords = apply_trans(src_mri_t, coords)
            self.geo[hemi] = Bunch(coords=coords)
            vertices = self._data[hemi]["vertices"]
            assert self._data[hemi]["array"].shape[0] == len(vertices)
            # MNE constructs the source space on a uniform grid in MRI space,
            # but mne coreg can change it to be non-uniform, so we need to
            # use all three elements here
            assert np.allclose(src_mri_t[:3, :3], np.diag(np.diag(src_mri_t)[:3]))
            spacing = np.diag(src_mri_t)[:3]
            origin = src_mri_t[:3, 3]
            scalars = np.zeros(np.prod(dimensions))
            scalars[vertices] = 1.0  # for the outer mesh
            # TODO: reaches into VTK through the renderer, which the
            # jupyterlite_notebook backend cannot offer (its pages are excluded
            # in doc/conf.py); refactor the renderer interface so Brain only
            # uses its abstract methods. Same for the time label and glyph
            # actors below.
            grid, grid_mesh, volume_pos, volume_neg = self._renderer._volume(
                dimensions,
                origin,
                spacing,
                scalars,
                surface_alpha,
                resolution,
                blending,
                center,
                interpolation,
            )
            self._data[hemi]["alpha"] = alpha  # incorrectly set earlier
            self._data[hemi]["grid"] = grid
            self._data[hemi]["grid_mesh"] = grid_mesh
            self._data[hemi]["grid_coords"] = coords
            self._data[hemi]["grid_src_mri_t"] = src_mri_t
            self._data[hemi]["grid_shape"] = dimensions
            self._data[hemi]["grid_volume_pos"] = volume_pos
            self._data[hemi]["grid_volume_neg"] = volume_neg
        actor_pos, _ = self._renderer.plotter.add_actor(
            volume_pos, name=None, culling=False, reset_camera=False, render=False
        )
        actor_neg = actor_mesh = None
        if volume_neg is not None:
            actor_neg, _ = self._renderer.plotter.add_actor(
                volume_neg, name=None, culling=False, reset_camera=False, render=False
            )
        grid_mesh = self._data[hemi]["grid_mesh"]
        if grid_mesh is not None:
            actor_mesh, prop = self._renderer.plotter.add_actor(
                grid_mesh,
                name=None,
                culling=False,
                pickable=False,
                reset_camera=False,
                render=False,
            )
            prop.SetColor(*self._brain_color[:3])
            prop.SetOpacity(surface_alpha)
            if silhouette_alpha > 0 and silhouette_linewidth > 0:
                for _ in self._iter_views("vol"):
                    self._renderer._silhouette(
                        mesh=grid_mesh.GetInput(),
                        color=self._brain_color[:3],
                        line_width=silhouette_linewidth,
                        alpha=silhouette_alpha,
                    )
        for actor in (actor_pos, actor_neg, actor_mesh):
            if actor is not None:
                _hide_testing_actor(actor)

        return actor_pos, actor_neg

    def add_label(
        self,
        label,
        color=None,
        alpha=1,
        scalar_thresh=None,
        borders=False,
        hemi=None,
        subdir=None,
    ):
        """Add an ROI label to the image.

        Parameters
        ----------
        label : str | instance of Label
            Label filepath or name. Can also be an instance of
            an object with attributes "hemi", "vertices", "name", and
            optionally "color" and "values" (if scalar_thresh is not None).
        color : matplotlib-style color | None
            Anything matplotlib accepts: string, RGB, hex, etc. (default
            "crimson").
        alpha : float in [0, 1]
            Alpha level to control opacity.
        scalar_thresh : None | float
            Threshold the label ids using this value in the label
            file's scalar field (i.e. label only vertices with
            scalar >= thresh).
        borders : bool | int
            Show only label borders. If int, specify the number of steps
            (away from the true border) along the cortical mesh to include
            as part of the border definition.
        hemi : str | None
            If None, it is assumed to belong to the hemisphere being
            shown.
        subdir : None | str
            If a label is specified as name, subdir can be used to indicate
            that the label file is in a sub-directory of the subject's
            label directory rather than in the label directory itself (e.g.
            for ``$SUBJECTS_DIR/$SUBJECT/label/aparc/lh.cuneus.label``
            ``brain.add_label('cuneus', subdir='aparc')``).

        Notes
        -----
        To remove previously added labels, run Brain.remove_labels().
        """
        from ...label import read_label

        if isinstance(label, str):
            if color is None:
                color = "crimson"

            if os.path.isfile(label):
                filepath = label
                label = read_label(filepath)
                hemi = label.hemi
                label_name = os.path.basename(filepath).split(".")[1]
            else:
                hemi = self._check_hemi(hemi)
                label_name = label
                label_fname = ".".join([hemi, label_name, "label"])
                if subdir is None:
                    filepath = op.join(
                        self._subjects_dir, self._subject, "label", label_fname
                    )
                else:
                    filepath = op.join(
                        self._subjects_dir, self._subject, "label", subdir, label_fname
                    )
                if not os.path.exists(filepath):
                    raise ValueError(f"Label file {filepath} does not exist")
                label = read_label(filepath)
            ids = label.vertices
            scalars = label.values
        else:
            # try to extract parameters from label instance
            try:
                hemi = label.hemi
                ids = label.vertices
                if label.name is None:
                    label.name = "unnamed" + str(self._unnamed_label_id)
                    self._unnamed_label_id += 1
                label_name = str(label.name)

                if color is None:
                    if hasattr(label, "color") and label.color is not None:
                        color = label.color
                    else:
                        color = "crimson"

                if scalar_thresh is not None:
                    scalars = label.values
            except Exception:
                raise ValueError(
                    "Label was not a filename (str), and could "
                    "not be understood as a class. The class "
                    'must have attributes "hemi", "vertices", '
                    '"name", and (if scalar_thresh is not None)'
                    '"values"'
                )
            hemi = self._check_hemi(hemi)

        if scalar_thresh is not None:
            ids = ids[scalars >= scalar_thresh]

        color = _to_rgb(color, alpha, alpha=True)
        cmap = np.array(
            [
                (
                    0,
                    0,
                    0,
                    0,
                ),
                color,
            ]
        )
        ctable = np.round(cmap * 255).astype(np.uint8)

        scalars = np.zeros(self.geo[hemi].coords.shape[0])
        scalars[ids] = 1
        if borders:
            # orig_faces, not faces: a flat patch drops the triangles outside
            # it, and adjacency cannot be computed from a subset of them
            keep_idx = _mesh_borders(self.geo[hemi].orig_faces, scalars)
            show = np.zeros(scalars.size, dtype=np.int64)
            if isinstance(borders, int):
                for _ in range(borders):
                    keep_idx = np.isin(self.geo[hemi].faces.ravel(), keep_idx)
                    keep_idx = keep_idx.reshape(self.geo[hemi].faces.shape, copy=False)
                    keep_idx = self.geo[hemi].faces[np.any(keep_idx, axis=1)]
                    keep_idx = np.unique(keep_idx)
            show[keep_idx] = 1
            scalars *= show
        for _, _, v in self._iter_views(hemi):
            mesh = self.layered_meshes[hemi]
            mesh.add_overlay(
                scalars=scalars,
                colormap=ctable,
                rng=[np.min(scalars), np.max(scalars)],
                opacity=alpha,
                name=label_name,
            )
            self._labels[hemi].append(label)
        self._renderer._update()

    @fill_doc_static("alpha")
    def add_annotation(
        self,
        annot,
        borders=True,
        alpha=1,
        hemi=None,
        *,
        remove_existing=True,
        color=None,
        hover=True,
    ):
        """Add an annotation (i.e. an atlas of many labels) to the brain figure.

        Parameters
        ----------
        annot : path-like | str | list of Label
            Either path to annotation file, an annotation name, or a list of
            :class:`mne.Label` objects.

            .. versionadded:: 1.13
               The ability to supply a list of :class:`~mne.Label` objects.
        borders : bool | int
            Show only label borders. If int, specify the number of steps
            (away from the true border) along the cortical mesh to include
            as part of the border definition.
        alpha : float in [0, 1]
            Alpha level to control opacity.
            Default is 1.
        hemi : str | None
            Optionally restrict the annotation to the given hemisphere.
        remove_existing : bool
            If True (default), remove old annotations.
        color : matplotlib-style color code
            If used, show all annotations in the same (specified) color.
            Probably useful only when showing annotation borders.
        hover : bool
            If True, show annotation labels on hover.

            .. versionadded:: 1.13
        """
        from ...label import read_labels_from_annot

        _validate_type(annot, ("path-like", str, list), "annot")

        hemis = self._check_hemis(hemi)
        kwargs = dict()

        for hemi_idx, hemi in enumerate(hemis):
            if _path_like(annot):
                if os.path.isfile(annot):
                    kwargs["annot_fname"] = annot
                else:
                    kwargs["parc"] = annot
                labels = read_labels_from_annot(
                    self._subject,
                    hemi=hemi,
                    subjects_dir=self._subjects_dir,
                    **kwargs,
                )
                name = annot
            else:
                labels = [label for label in annot if label.hemi == hemi]
                name = "annotation"  # placeholder name for the annotation
            n_labels = len(labels)
            ids = np.full(self.geo[hemi].coords.shape[0], -1, dtype=int)
            cmap = np.zeros((len(labels) + 1, 4))
            cmap[:, 3] = 1
            cmap[0] = np.array(self._brain_color)
            cmap[0, 3] = 0.0
            centroids = np.zeros((len(labels) + 1, 3))
            for li, label in enumerate(labels):
                ids[label.vertices] = li  # will have one added later
                cmap[li + 1] = label.color
                label.values[:] = 1
                centroids[li] = self.geo[hemi].coords[
                    label.center_of_mass(subjects_dir=self._subjects_dir)
                ]
            self._annots[hemi].append(
                dict(name=name, labels=labels, ids=ids, centroids=centroids)
            )
            del labels

            # Maybe zero-out the non-border vertices
            scalars = ids + 1  # make a copy and reindex
            self._to_borders(scalars, hemi, borders)

            # Override the cmap when a single color is used
            if color is not None:
                cmap[1:, :3] = _to_rgb(color)

            ctable = cmap.astype(np.float64)
            for _ in self._iter_views(hemi):
                mesh = self.layered_meshes[hemi]
                mesh.add_overlay(
                    scalars=scalars,
                    colormap=ctable * 255,
                    rng=[0, n_labels],
                    opacity=alpha,
                    name=name,
                )

        if hover:

            @_auto_weakref
            def on_annotation_hover(iren, event):
                self._on_annotation_hover(iren, event)

            obs = self.plotter.AddObserver("MouseMoveEvent", on_annotation_hover)
            for hemi in hemis:
                caption = self._create_caption()
                self._annots[hemi][-1].update(caption=caption, obs=obs)
                for _ in self._iter_views(hemi):
                    self.plotter.add_actor(
                        caption,
                        name=None,
                        culling=False,
                        pickable=False,
                        reset_camera=False,
                        render=False,
                    )
        self._renderer._update()

    def _create_caption(self):
        from vtkmodules.vtkRenderingAnnotation import vtkCaptionActor2D

        caption = vtkCaptionActor2D()
        caption.SetVisibility(False)
        caption.SetLeader(True)
        caption.SetBorder(False)  # use the text border instead
        caption.GetPositionCoordinate().SetCoordinateSystemToDisplay()
        caption.GetPosition2Coordinate().SetCoordinateSystemToDisplay()
        caption.SetThreeDimensionalLeader(False)
        caption.GetPositionCoordinate().SetValue(20, 20)
        caption.GetTextActor().SetTextScaleModeToNone()
        prop = caption.GetCaptionTextProperty()
        prop.SetFontSize(14)
        prop.SetItalic(False)
        prop.SetShadow(False)
        prop.SetBackgroundOpacity(0.5)
        prop.SetColor(*self._fg_color[:3])
        prop.SetFrame(True)
        prop.SetFrameWidth(3)
        prop.SetBackgroundColor(*self._bg_color[:3])
        return caption

    def _on_annotation_hover(self, iren, event):  # event == "MouseMoveEvent"
        from pyvista import DataSetMapper

        x, y = iren.GetEventPosition()
        picked_renderer = iren.FindPokedRenderer(x, y)
        vtk_picker = self._renderer._hover_picker
        vtk_picker.Pick(x, y, 0, picked_renderer)
        cell_id = vtk_picker.GetCellId()
        # This returns a vtkPolyData we don't seem to have access to:
        # vtk_picker.GetDataSet()
        # So we need to go through the mapper:
        mapper = vtk_picker.GetMapper()
        if not isinstance(mapper, DataSetMapper) or cell_id == -1:
            do_update = False
            for annot in self._annots.values():
                if not annot or "caption" not in annot[-1]:
                    continue
                caption = annot[-1]["caption"]
                if caption.GetVisibility():
                    logger.debug("No mesh picked, hiding caption")
                    caption.SetVisibility(False)
                    do_update = True
            if do_update:
                self._renderer._update()
            return  # didn't find a mesh
        for hemi, this_mesh in self.layered_meshes.items():
            if this_mesh._polydata is mapper.dataset:
                mesh = this_mesh._polydata
                break
        else:
            return
        pos = np.array(vtk_picker.GetPickPosition())
        vtk_cell = mesh.GetCell(cell_id)
        cell = [
            vtk_cell.GetPointId(point_id)
            for point_id in range(vtk_cell.GetNumberOfPoints())
        ]
        vert_pos = mesh.points[cell]
        vertex_id = cell[np.argmin(np.linalg.norm(vert_pos - pos, axis=1))]
        lidx = self._annots[hemi][-1]["ids"][vertex_id]
        label = self._annots[hemi][-1]["labels"][lidx]
        centroid = self._annots[hemi][-1]["centroids"][lidx]
        caption = self._annots[hemi][-1]["caption"]
        if caption.GetCaption() == label.name:
            logger.debug("Same label hovered, skipping update")
            return  # no-op to save a render call
        # We have lots of options here... can have the text move with the cursor
        # but that's a bit distracting (and slower UX because it takes some
        # time to render each time). Could also shift the label in world coords,
        # but it's cleaner just to move it by some number of pixels.
        logger.debug(
            "Hovering label %s from %s %d @ %s",
            label.name,
            hemi,
            vertex_id,
            centroid,
        )
        other_hemi = "lh" if hemi == "rh" else "rh"
        if self._annots.get(other_hemi):
            self._annots[other_hemi][-1]["caption"].SetVisibility(False)
        caption.SetCaption(label.name)
        caption.SetAttachmentPoint(*centroid)
        caption.SetVisibility(True)
        actor = caption.GetTextActor()
        prop = caption.GetCaptionTextProperty()
        prop.SetFrameColor(*label.color[:3])
        # This maybe isn't strictly needed because we hide the frame anyway, but for
        # completeness and future compat let's fix our size
        wh = np.zeros(2)
        actor.GetSize(self.plotter.renderer, wh)
        caption.SetPosition2(wh)
        self._renderer._update()

    def close(self):
        """Close all figures and cleanup data structure."""
        self._closed = True
        self._renderer.close()

    def show(self):
        """Display the window."""
        self._renderer.show()

    @fill_doc_static(
        "align_view", "roll", "distance", "azimuth", "elevation", "focalpoint"
    )
    def get_view(self, row=0, col=0, *, align=True):
        """Get the camera orientation for a given subplot display.

        Parameters
        ----------
        row : int
            The row to use, default is the first one.
        col : int
            The column to check, the default is the first one.
        align : bool
            If True, consider view arguments relative to canonical MRI
            directions (closest to MNI for the subject) rather than native MRI
            space. This helps when MRIs are not in standard orientation (e.g.,
            have large rotations).

        Returns
        -------
        roll : float | None
            The roll of the camera rendering the view in degrees.
        distance : float | "auto" | None
            The distance from the camera rendering the view to the focalpoint in plot
            units (either m or mm). If "auto", the bounds of visible objects will be
            used to set a reasonable distance.

            .. versionchanged:: 1.6
               ``None`` will no longer change the distance, use ``"auto"`` instead.
        azimuth : float
            The azimuthal angle of the camera rendering the view in degrees.
        elevation : float
            The zenith angle of the camera rendering the view in degrees.
        focalpoint : tuple, shape (3,) | str | None
            The focal point of the camera rendering the view: (x, y, z) in
            plot units (either m or mm). When ``"auto"``, it is set to the center of
            mass of the visible bounds.
        """
        row = _ensure_int(row, "row")
        col = _ensure_int(col, "col")
        rigid = self._rigid if align else None
        for h in self._hemis:
            for ri, ci, _ in self._iter_views(h):
                if (row == ri) and (col == ci):
                    return self._renderer.get_camera(rigid=rigid)
        return (None,) * 5

    @verbose_static(
        "view",
        "roll",
        "distance",
        "align_view",
        "azimuth",
        "elevation",
        "focalpoint",
        "brain_update",
    )
    def show_view(
        self,
        view=None,
        roll=None,
        distance=None,
        *,
        row=None,
        col=None,
        hemi=None,
        align=True,
        azimuth=None,
        elevation=None,
        focalpoint=None,
        update=True,
        verbose=None,
    ):
        """Orient camera to display view.

        Parameters
        ----------
        view : str | None
            The name of the view to show (e.g. "lateral"). Other arguments
            take precedence and modify the camera starting from the ``view``.
            See :meth:`Brain.show_view <mne.viz.Brain.show_view>` for valid
            string shortcut options.
        roll : float | None
            The roll of the camera rendering the view in degrees.
        distance : float | "auto" | None
            The distance from the camera rendering the view to the focalpoint in plot
            units (either m or mm). If "auto", the bounds of visible objects will be
            used to set a reasonable distance.

            .. versionchanged:: 1.6
               ``None`` will no longer change the distance, use ``"auto"`` instead.
        row : int | None
            The row to set. Default all rows.
        col : int | None
            The column to set. Default all columns.
        hemi : str | None
            Which hemi to use for view lookup (when in "both" mode).
        align : bool
            If True, consider view arguments relative to canonical MRI
            directions (closest to MNI for the subject) rather than native MRI
            space. This helps when MRIs are not in standard orientation (e.g.,
            have large rotations).
        azimuth : float
            The azimuthal angle of the camera rendering the view in degrees.
        elevation : float
            The zenith angle of the camera rendering the view in degrees.
        focalpoint : tuple, shape (3,) | str | None
            The focal point of the camera rendering the view: (x, y, z) in
            plot units (either m or mm). When ``"auto"``, it is set to the center of
            mass of the visible bounds.
        update : bool
            Force an update of the plot. Defaults to True.

            .. versionadded:: 1.6
        verbose : bool | str | int | None
            Control verbosity of the logging output. If ``None``, use the default
            verbosity level. See the :ref:`logging documentation <tut-logging>` and
            :func:`mne.verbose` for details. Should only be passed as a keyword
            argument.

        Notes
        -----
        The builtin string views are the following perspectives, based on the
        :term:`RAS` convention. If not otherwise noted, the view will have the
        top of the brain (superior, +Z) in 3D space shown upward in the 2D
        perspective:

        ``'lateral'``
            From the left or right side such that the lateral (outside)
            surface of the given hemisphere is visible.
        ``'medial'``
            From the left or right side such that the medial (inside)
            surface of the given hemisphere is visible (at least when in split
            or single-hemi mode).
        ``'rostral'``
            From the front.
        ``'caudal'``
            From the rear.
        ``'dorsal'``
            From above, with the front of the brain pointing up.
        ``'ventral'``
            From below, with the front of the brain pointing up.
        ``'frontal'``
            From the front and slightly lateral, with the brain slightly
            tilted forward (yielding a view from slightly above).
        ``'parietal'``
            From the rear and slightly lateral, with the brain slightly tilted
            backward (yielding a view from slightly above).
        ``'axial'``
            From above with the brain pointing up (same as ``'dorsal'``).
        ``'sagittal'``
            From the right side.
        ``'coronal'``
            From the rear.

        Three letter abbreviations (e.g., ``'lat'``) of all of the above are
        also supported.
        """
        _validate_type(row, ("int-like", None), "row")
        _validate_type(col, ("int-like", None), "col")
        hemi = self._hemi if hemi is None else hemi
        if hemi == "split":
            if (
                self._view_layout == "vertical"
                and col == 1
                or self._view_layout == "horizontal"
                and row == 1
            ):
                hemi = "rh"
            else:
                hemi = "lh"
        _validate_type(view, (str, None), "view")
        view_params = dict(
            azimuth=azimuth,
            elevation=elevation,
            roll=roll,
            distance=distance,
            focalpoint=focalpoint,
        )
        if view is not None:  # view_params take precedence
            if self._surf == "flat" and view != "flat":
                # every views dict holds all the 3D view names, so without this
                # a flat map would happily be rotated edge-on
                warn(f'view="{view}" is ignored for surf="flat"')
                return
            view_params = {
                param: val for param, val in view_params.items() if val is not None
            }  # no overwriting with None
            view_params = dict(views_dicts[hemi].get(view), **view_params)
        for h in self._hemis:
            for ri, ci, _ in self._iter_views(h):
                if (row is None or row == ri) and (col is None or col == ci):
                    self._set_camera(**view_params, align=align)
        if update:
            self._renderer._update()

    def _set_camera(
        self,
        *,
        distance=None,
        focalpoint=None,
        update=False,
        align=True,
        verbose=None,
        **kwargs,
    ):
        # Wrap to self._renderer.set_camera safely, always passing self._rigid
        # and using better no-op-like defaults
        return self._renderer.set_camera(
            distance=distance,
            focalpoint=focalpoint,
            update=update,
            rigid=self._rigid if align else None,
            **kwargs,
        )

    def reset_view(self):
        """Reset the camera."""
        for h in self._hemis:
            for _, _, v in self._iter_views(h):
                self._set_camera(**views_dicts[h][v])
        self._fit_flat_camera()
        self._renderer._update()

    def _fit_flat_camera(self):
        """Frame a flat patch, which the camera distance cannot do."""
        if self._surf != "flat":
            return
        for renderer in self._renderer._all_renderers:
            renderer.reset_camera()

    def save_image(self, filename=None, mode="rgb", *, scale=1):
        """Save view from all panels to disk.

        Parameters
        ----------
        filename : path-like
            Path to new image file.
        mode : str
            Either ``'rgb'`` or ``'rgba'`` for values to return.
        scale : int
            The scale factor for the screenshot. Larger values produce higher
            resolution images. Default is 1.

            .. versionadded:: 1.14
        """
        if filename is None:
            filename = _generate_default_filename(".png")
        _save_ndarray_img(
            filename, self.screenshot(mode=mode, time_viewer=True, scale=scale)
        )

    @fill_doc_static("time_viewer_brain_screenshot")
    def screenshot(self, mode="rgb", time_viewer=False, *, scale=1):
        """Generate a screenshot of current view.

        Parameters
        ----------
        mode : str
            Either ``'rgb'`` or ``'rgba'`` for values to return.
        time_viewer : bool
            If True, include time viewer traces. Only used if
            ``time_viewer=True`` and ``separate_canvas=False``.
        scale : int
            The scale factor for the screenshot. Larger values produce higher
            resolution images. Default is 1.

            .. versionadded:: 1.14

        Returns
        -------
        screenshot : array
            Image pixel values.
        """
        scale = _ensure_int(scale, "scale")
        n_channels = 3 if mode == "rgb" else 4
        img = self._renderer.screenshot(mode, scale=scale)
        logger.debug(f"Got screenshot of size {img.shape}")
        if (
            time_viewer
            and self.time_viewer
            and self.show_traces
            and not self.separate_canvas
        ):
            from matplotlib.image import imread

            canvas = self.mpl_canvas.fig.canvas
            canvas.draw_idle()
            fig = self.mpl_canvas.fig
            with BytesIO() as output:
                # Need to pass dpi here so it uses the physical (HiDPI) DPI
                # rather than logical DPI when saving in most cases.
                # But when matplotlib uses HiDPI and VTK doesn't
                # (e.g., macOS w/Qt 5.14+ and VTK9) then things won't work,
                # so let's just calculate the DPI we need to get
                # the correct size output based on the widths being equal
                size_in = fig.get_size_inches()
                dpi = fig.get_dpi() * scale
                want_size = tuple(x * dpi for x in size_in)
                n_pix = want_size[0] * want_size[1]
                logger.debug(
                    f"Saving figure of size {size_in} @ {dpi} DPI "
                    f"({want_size} = {n_pix} pixels)"
                )
                # Sometimes there can be off-by-one errors here (e.g.,
                # if in mpl int() rather than int(round()) is used to
                # compute the number of pixels) so rather than use "raw"
                # format and try to reshape ourselves, just write to PNG
                # and read it, which has the dimensions encoded for us.
                fig.savefig(
                    output,
                    dpi=dpi,
                    format="png",
                    facecolor=self._bg_color,
                    edgecolor="none",
                )
                output.seek(0)
                trace_img = imread(output, format="png")[:, :, :n_channels]
                trace_img = np.clip(np.round(trace_img * 255), 0, 255).astype(np.uint8)
            bgcolor = np.array(self._brain_color[:n_channels]) / 255
            img = concatenate_images(
                [img, trace_img], bgcolor=bgcolor, n_channels=n_channels
            )
        return img

    def set_cortex_alpha(self, alpha):
        """Set the opacity of the cortical surface.

        Parameters
        ----------
        alpha : float
            The opacity of the cortical surface, between 0 and 1.
        """
        self._alpha = float(alpha)
        for hemi in self._hemis:
            self.layered_meshes[hemi].update_overlay("curv", opacity=self._alpha)
        self._renderer._update()

    def set_cortex_colormap(self, cortex):
        """Set the curvature colormap preset of the cortical surface.

        Parameters
        ----------
        cortex : str
            One of ``'classic'``, ``'high_contrast'``, ``'low_contrast'``, ``'bone'``.
        """
        _check_option("cortex", cortex, _CORTEX_PRESETS)
        geo_kwargs = self._cortex_colormap(cortex)
        val = -geo_kwargs["vmin"] / (geo_kwargs["vmax"] - geo_kwargs["vmin"])
        self._brain_color = geo_kwargs["colormap"](val)
        self._cortex_preset = cortex
        for hemi in self._hemis:
            geo = self.geo[hemi]
            mesh = self.layered_meshes[hemi]
            scalars = (
                geo.bin_curv
                if geo.bin_curv is not None
                else mesh._default_scalars[:, 0]
            )
            mesh.update_overlay(
                "curv",
                scalars=scalars,
                colormap=geo_kwargs["colormap"],
                rng=[geo_kwargs["vmin"], geo_kwargs["vmax"]],
            )
        self._renderer._update()

    def set_surf(self, surf):
        """Set the cortical surface representation.

        Parameters
        ----------
        surf : str
            One of ``'pial'``, ``'white'``, ``'inflated'``, or ``'flat'``.
            ``'flat'`` needs the ``?h.cortex.patch.flat`` and ``?h.sphere``
            files in the subject's ``surf`` directory, and switches the view to
            a non-rotatable 2D one for as long as it is shown.
        """
        surfs = ("pial", "white", "inflated", "flat")
        _check_option("surf", surf, surfs)
        if surf == "flat" and not self._has_flatmaps():
            raise FileNotFoundError(
                f"Subject {self._subject} has no flatmap surface file "
                f"({{hemi}}.cortex.patch.flat) in {self._subjects_dir}"
            )
        if surf == self._surf:
            return
        if any(self._labels[h] for h in self._hemis) or any(
            "foci" in self._foci_data.get(h, {}) for h in self._hemis
        ):
            warn(
                "Foci and label/annotation outlines do not move when the "
                "surface representation changes and may now be misaligned."
            )
        flat_change = "flat" in (surf, self._surf)
        offset = _resolve_offset(self._offset_request, surf, self._hemi)
        for h in self._hemis:
            geo = _Surface(
                self._subject,
                h,
                surf,
                self._subjects_dir,
                offset,
                units=self._units,
                x_dir=self._rigid[0, :3],
            )
            geo.load_geometry()
            geo.load_curvature()
            self.geo[h] = geo
            self.layered_meshes[h].update_geometry(
                geo.coords, geo.nn, geo.faces if flat_change else None
            )
            for data in self._all_data.values():
                hemi_data = data.get(h)
                if hemi_data is None:
                    continue
                glyph_dataset = hemi_data.get("glyph_dataset")
                if glyph_dataset is None:
                    continue
                vertices = hemi_data["vertices"]
                vertices = slice(None) if vertices is None else vertices
                glyph_dataset.points = np.array(geo.coords)[vertices]
        self._surf = surf
        if flat_change:  # switch the camera and interaction to 2D/3D
            if surf == "flat":
                self._pre_flat = (list(self._views), self._interaction)
                self._views = ["flat"] * len(self._views)
                if self.silhouette:  # would look for a nonexistent {hemi}.flat
                    for actor in self._silhouette_actors:
                        self.plotter.remove_actor(actor)
                    self._silhouette_actors = []
                    self.silhouette = False
                interaction = "rubber_band_2d"
            else:
                self._views, interaction = getattr(self, "_pre_flat", None) or (
                    ["lateral"] * len(self._views),
                    "trackball",
                )
            self._interaction = interaction
            for _ in self._iter_views("vol"):  # will traverse all
                self._renderer.set_interaction(interaction)
        publish(self, _SurfaceUpdated(flat_change=flat_change))
        if self.silhouette:
            for actor in self._silhouette_actors:
                self.plotter.remove_actor(actor)
            self._add_silhouette()
        self.reset_view()

    def _add_silhouette(self):
        self._silhouette_actors = []
        for h in self._hemis:
            mesh = self.layered_meshes[h]
            for _, _, v in self._iter_views(h):
                self._set_camera(**views_dicts[h][v])
                decimate = self._silhouette["decimate"]
                if isinstance(decimate, str):
                    import pyvista as pv

                    vertno, tris = _decimate_surface_ico_oct(
                        self._subject, self._subjects_dir, h, self.geo[h].surf, decimate
                    )
                    sil_mesh = pv.PolyData(
                        self.geo[h].coords[vertno],
                        np.c_[np.full(len(tris), 3), tris],
                    )
                    decimate = None  # already decimated
                else:
                    sil_mesh = mesh._polydata
                actor = self._renderer._silhouette(
                    mesh=sil_mesh,
                    color=self._silhouette["color"],
                    line_width=self._silhouette["line_width"],
                    alpha=self._silhouette["alpha"],
                    decimate=decimate,
                )
                self._silhouette_actors.append(actor)

    def set_silhouette_line_width(self, line_width):
        """Set the width of the cortical surface silhouette outline.

        Parameters
        ----------
        line_width : float
            The silhouette line width. A value of ``0`` hides the
            silhouette entirely.
        """
        if self._surf == "flat":
            raise ValueError('silhouette is not supported for surf="flat"')
        line_width = float(line_width)
        self._silhouette["line_width"] = line_width
        if line_width <= 0:
            self.silhouette = False
            for actor in self._silhouette_actors:
                actor.SetVisibility(False)
        else:
            self.silhouette = True
            if not self._silhouette_actors:
                self._add_silhouette()
            for actor in self._silhouette_actors:
                actor.GetProperty().SetLineWidth(line_width)
                actor.SetVisibility(True)
        self._renderer._update()

    @fill_doc_static("fmin_fmid_fmax", "alpha")
    def update_lut(self, fmin=None, fmid=None, fmax=None, alpha=None):
        """Update the range of the color map.

        Parameters
        ----------
        fmin : float
            Minimum value in colormap (uses real fmin if None).
        fmid : float
            Intermediate value in colormap (fmid between fmin and
            fmax if None).
        fmax : float
            Maximum value in colormap (uses real max if None).
        alpha : float in [0, 1]
            Alpha level to control opacity.
        """
        publish(
            self,
            ColormapRange(
                kind="distributed_source_power",
                fmin=fmin,
                fmid=fmid,
                fmax=fmax,
                alpha=alpha,
            ),
        )

    @fill_doc_static("fmin_fmid_fmax", "alpha")
    def _update_colormap_range(self, fmin=None, fmid=None, fmax=None, alpha=None):
        """Update the range of the color map.

        Parameters
        ----------
        fmin : float
            Minimum value in colormap (uses real fmin if None).
        fmid : float
            Intermediate value in colormap (fmid between fmin and
            fmax if None).
        fmax : float
            Maximum value in colormap (uses real max if None).
        alpha : float in [0, 1]
            Alpha level to control opacity.
        """
        args = f"{fmin}, {fmid}, {fmax}, {alpha}"
        logger.debug(f"Updating LUT with {args}")
        center = self._data["center"]
        colormap = self._data["colormap"]
        transparent = self._data["transparent"]
        lims = {k: self._data[k] for k in ("fmin", "fmid", "fmax")}
        _update_monotonic(lims, fmin=fmin, fmid=fmid, fmax=fmax)
        assert all(val is not None for val in lims.values())

        self._data.update(lims)
        self._data["ctable"] = np.round(
            calculate_lut(
                colormap, alpha=1.0, center=center, transparent=transparent, **lims
            )
            * 255
        ).astype(np.uint8)
        # update our values
        rng = self._cmap_range
        ctable = self._data["ctable"]
        fmt = self._data["colorbar_fmt"] or _auto_scalar_bar_fmt(rng)
        if self._scalar_bar is not None:
            self._renderer.set_scalarbar_title(
                self._scalar_bar, self._data["colorbar_title"]
            )
        for hemi in ["lh", "rh", "vol"]:
            hemi_data = self._data.get(hemi)
            if hemi_data is not None:
                if hemi in self.layered_meshes:
                    mesh = self.layered_meshes[hemi]
                    mesh.update_overlay(
                        name=self._active_data_key,
                        colormap=self._data["ctable"],
                        opacity=alpha,
                        rng=rng,
                    )
                    self._renderer._set_colormap_range(
                        mesh._actor,
                        ctable,
                        self._scalar_bar,
                        rng,
                        self._brain_color,
                        fmt=fmt,
                    )

                grid_volume_pos = hemi_data.get("grid_volume_pos")
                grid_volume_neg = hemi_data.get("grid_volume_neg")
                for grid_volume in (grid_volume_pos, grid_volume_neg):
                    if grid_volume is not None:
                        self._renderer._set_volume_range(
                            grid_volume,
                            ctable,
                            hemi_data["alpha"],
                            self._scalar_bar,
                            rng,
                            fmt=fmt,
                        )

                glyph_actor = hemi_data.get("glyph_actor")
                if glyph_actor is not None:
                    for glyph_actor_ in glyph_actor:
                        self._renderer._set_colormap_range(
                            glyph_actor_, ctable, self._scalar_bar, rng, fmt=fmt
                        )
        self._renderer._update()

    def set_data_smoothing(self, n_steps):
        """Set the number of smoothing steps.

        Parameters
        ----------
        n_steps : int
            Number of smoothing steps.
        """
        from ...morph import _hemi_morph

        for hemi in ["lh", "rh"]:
            for data_key, key_data in self._all_data.items():
                hemi_data = key_data.get(hemi)
                if hemi_data is None:
                    continue
                if len(hemi_data["array"]) >= self.geo[hemi].x.shape[0]:
                    continue
                vertices = hemi_data["vertices"]
                if vertices is None:
                    raise ValueError(
                        f"len(data) < nvtx ({len(hemi_data['array'])} < "
                        f"{self.geo[hemi].x.shape[0]}): the vertices "
                        "parameter must not be None"
                    )
                morph_n_steps = "nearest" if n_steps == -1 else n_steps
                with use_log_level(False):
                    smooth_mat = _hemi_morph(
                        self.geo[hemi].orig_faces,
                        np.arange(len(self.geo[hemi].coords)),
                        vertices,
                        morph_n_steps,
                        maps=None,
                        warn=False,
                    )
                hemi_data["smooth_mat"] = smooth_mat
        self._update_current_time_idx(self._data["time_idx"])
        self._data["smoothing_steps"] = n_steps

    @property
    def _n_times(self):
        return len(self._times) if self._times is not None else None

    @property
    def time_interpolation(self):
        """The interpolation mode."""
        return self._time_interpolation

    @fill_doc_static("interpolation_brain_time")
    def set_time_interpolation(self, interpolation):
        """Set the interpolation mode.

        Parameters
        ----------
        interpolation : str | None
            Interpolation method (:class:`scipy.interpolate.interp1d` parameter).
            Must be one of ``'linear'``, ``'nearest'``, ``'zero'``, ``'slinear'``,
            ``'quadratic'`` or ``'cubic'``.
        """
        self._time_interpolation = _check_option(
            "interpolation",
            interpolation,
            ("linear", "nearest", "zero", "slinear", "quadratic", "cubic"),
        )
        self._time_interp_funcs = dict()
        self._time_interp_inv = None
        if self._times is not None:
            idx = np.arange(self._n_times)
            for data_key, key_data in self._all_data.items():
                for hemi in ["lh", "rh", "vol"]:
                    hemi_data = key_data.get(hemi)
                    if hemi_data is not None:
                        array = hemi_data["array"]
                        if array.ndim > 1:
                            self._time_interp_funcs[(data_key, hemi)] = _safe_interp1d(
                                idx,
                                array,
                                self._time_interpolation,
                                axis=-1,
                                assume_sorted=True,
                            )
            self._time_interp_inv = _safe_interp1d(idx, self._times)

    def _update_current_time_idx(self, time_idx):
        """Update all widgets in the figure to reflect a new time point.

        Parameters
        ----------
        time_idx : int | float
            The time index to use. Can be a float to use interpolation
            between indices.
        """
        self._current_act_data = dict()
        active = self._data
        time_actor = active.get("time_actor", None)
        time_label = active.get("time_label", None)
        for hemi in ["lh", "rh", "vol"]:
            staged_keys = list()
            for data_key, key_data in self._all_data.items():
                hemi_data = key_data.get(hemi)
                if hemi_data is None:
                    continue
                array = hemi_data["array"]
                # interpolate in time
                vectors = None
                if array.ndim == 1:
                    act_data = array
                    if data_key == self._active_data_key:
                        self._current_time = 0
                else:
                    act_data = self._time_interp_funcs[(data_key, hemi)](time_idx)
                    if data_key == self._active_data_key:
                        self._current_time = self._time_interp_inv(time_idx)
                    if array.ndim == 3:
                        vectors = act_data
                        act_data = np.linalg.norm(act_data, axis=1)
                        if data_key == self._active_data_key:
                            self._current_time = self._time_interp_inv(time_idx)

                if data_key == self._active_data_key:
                    self._current_act_data[hemi] = act_data
                    if time_actor is not None and time_label is not None:
                        # TODO: VTK text actor API, see _add_volume_data
                        time_actor.SetInput(time_label(self._current_time))

                # update the volume interpolation (active key only)
                if data_key == self._active_data_key:
                    grid = hemi_data.get("grid")
                    if grid is not None:
                        vertices = hemi_data["vertices"]
                        values = self._current_act_data[hemi]
                        rng = self._cmap_range
                        fill = 0 if active["center"] is not None else rng[0]
                        grid.point_data["values"].fill(fill)
                        grid.point_data["values"][vertices] = values
                        self._renderer._update_volume_rgba(
                            grid, self._data["ctable"], rng
                        )
                        # This can be useful for debugging fsaverage-5 source space by
                        # making the value at (0, -5, 5) high
                        # if 21334 in vertices:
                        #     grid.point_data["values"][21334] = values.max()

                # update the mesh scalar values
                if hemi in self.layered_meshes:
                    mesh = self.layered_meshes[hemi]
                    mesh.smooth_mat = hemi_data.get("smooth_mat")
                    key_rng = [
                        (
                            -key_data["fmax"]
                            if key_data["center"] is not None
                            else key_data["fmin"]
                        ),
                        key_data["fmax"],
                    ]
                    if data_key in mesh._overlays:
                        # Stage without recomposing; a single update below handles
                        # all overlays in O(N) instead of O(N²).
                        mesh.update_overlay(data_key, scalars=act_data, update=False)
                        staged_keys.append(data_key)
                    else:
                        mesh.add_overlay(
                            scalars=act_data,
                            colormap=key_data["ctable"],
                            rng=key_rng,
                            opacity=None,
                            name=data_key,
                            smooth=True,
                        )

                # update the glyphs (active key only)
                if vectors is not None and data_key == self._active_data_key:
                    self._update_glyphs(hemi, vectors)

            if staged_keys and hemi in self.layered_meshes:
                if len(staged_keys) == 1:
                    # Let update_overlay pick the cached path when the overlay we
                    # staged is the topmost one: the layers below it (curvature,
                    # labels, ...) have not changed, so their composite can be
                    # reused instead of color-mapping them all again.
                    self.layered_meshes[hemi].update_overlay(staged_keys[0])
                else:
                    self.layered_meshes[hemi].update()

        active["time_idx"] = time_idx
        self._renderer._update()

    def set_time_point(self, time_idx):
        """Set the time point to display (can be a float to interpolate).

        Parameters
        ----------
        time_idx : int | float
            The time index to use. Can be a float to use interpolation
            between indices.
        """
        if self._times is None:
            raise ValueError("Cannot set time when brain has no defined times.")
        elif 0 <= time_idx <= len(self._times):
            publish(self, TimeChange(time=self._time_interp_inv(time_idx)))
        else:
            raise ValueError(
                f"Requested time point ({time_idx}) is outside the range of "
                f"available time points (0-{len(self._times)})."
            )

    def set_time(self, time):
        """Set the time to display (in seconds).

        Parameters
        ----------
        time : float
            The time to show, in seconds.
        """
        if self._times is None:
            raise ValueError("Cannot set time when brain has no defined times.")
        elif min(self._times) <= time <= max(self._times):
            publish(self, TimeChange(time=time))
        else:
            raise ValueError(
                f"Requested time ({time} s) is outside the range of "
                f"available times ({min(self._times)}-{max(self._times)} s)."
            )

    def _update_glyphs(self, hemi, vectors):
        hemi_data = self._data.get(hemi)
        assert hemi_data is not None
        vertices = hemi_data["vertices"]
        vector_alpha = self._data["vector_alpha"]
        scale_factor = self._data["scale_factor"]
        vertices = slice(None) if vertices is None else vertices
        x, y, z = np.array(self.geo[hemi].coords)[vertices].T

        if hemi_data["glyph_actor"] is None:
            add = True
            hemi_data["glyph_actor"] = list()
        else:
            add = False
        count = 0
        for _ in self._iter_views(hemi):
            if hemi_data["glyph_dataset"] is None:
                glyph_mapper, glyph_dataset = self._renderer.quiver3d(
                    x,
                    y,
                    z,
                    vectors[:, 0],
                    vectors[:, 1],
                    vectors[:, 2],
                    color=None,
                    mode="2darrow",
                    scale_mode="vector",
                    scale=scale_factor,
                    opacity=vector_alpha,
                )
                hemi_data["glyph_dataset"] = glyph_dataset
                hemi_data["glyph_mapper"] = glyph_mapper
            else:
                glyph_dataset = hemi_data["glyph_dataset"]
                glyph_dataset.point_data["vec"] = vectors
                glyph_mapper = hemi_data["glyph_mapper"]
            if add:
                # TODO: VTK mapper/actor API, see _add_volume_data
                glyph_actor = self._renderer._actor(glyph_mapper)
                prop = glyph_actor.GetProperty()
                prop.SetLineWidth(2.0)
                prop.SetOpacity(vector_alpha)
                self._renderer.plotter.add_actor(glyph_actor, render=False)
                hemi_data["glyph_actor"].append(glyph_actor)
            else:
                glyph_actor = hemi_data["glyph_actor"][count]
            count += 1
            self._renderer._set_colormap_range(
                actor=glyph_actor,
                ctable=self._data["ctable"],
                scalar_bar=None,
                rng=self._cmap_range,
            )

    @property
    def _cmap_range(self):
        dt_max = self._data["fmax"]
        if self._data["center"] is None:
            dt_min = self._data["fmin"]
        else:
            dt_min = -1 * dt_max
        rng = [dt_min, dt_max]
        return rng

    def _update_auto_scaling(self, restore=False):
        user_clim = self._data["clim"]
        if user_clim is not None and "lims" in user_clim:
            allow_pos_lims = False
        else:
            allow_pos_lims = True
        if user_clim is not None and restore:
            clim = user_clim
        elif restore:
            self.update_lut(
                fmin=self._data["fmin"],
                fmid=self._data["fmid"],
                fmax=self._data["fmax"],
            )
            return
        else:
            clim = "auto"
        colormap = self._data["colormap"]
        transparent = self._data["transparent"]
        mapdata = _process_clim(
            clim,
            colormap,
            transparent,
            np.concatenate(list(self._current_act_data.values())),
            allow_pos_lims,
        )
        diverging = "pos_lims" in mapdata["clim"]
        colormap = mapdata["colormap"]
        scale_pts = mapdata["clim"]["pos_lims" if diverging else "lims"]
        transparent = mapdata["transparent"]
        del mapdata
        fmin, fmid, fmax = scale_pts
        center = 0.0 if diverging else None
        self._data["center"] = center
        self._data["colormap"] = colormap
        self._data["transparent"] = transparent
        self.update_lut(fmin=fmin, fmid=fmid, fmax=fmax)

    def _to_time_index(self, value):
        """Return the interpolated time index of the given time value."""
        time = self._data["time"]
        value = np.interp(value, time, np.arange(len(time)))
        return value

    @property
    def data(self):
        """Data used by time viewer and color bar widgets."""
        return self._data

    @property
    def _data(self):
        if self._active_data_key is None:
            return None
        return self._all_data.get(self._active_data_key)

    @property
    def labels(self):
        return self._labels

    @property
    def views(self):
        return self._views

    @property
    def hemis(self):
        return self._hemis

    def _check_stc(self, hemi, array, vertices):
        from ...source_estimate import (
            _BaseMixedSourceEstimate,
            _BaseSourceEstimate,
            _BaseSurfaceSourceEstimate,
            _BaseVolSourceEstimate,
        )

        if isinstance(array, _BaseSourceEstimate):
            stc = array
            stc_surf = stc_vol = None
            if isinstance(stc, _BaseSurfaceSourceEstimate):
                stc_surf = stc
            elif isinstance(stc, _BaseMixedSourceEstimate):
                stc_surf = stc.surface() if hemi != "vol" else None
                stc_vol = stc.volume() if hemi == "vol" else None
            elif isinstance(stc, _BaseVolSourceEstimate):
                stc_vol = stc if hemi == "vol" else None
            else:
                raise TypeError("stc not supported")

            if stc_surf is None and stc_vol is None:
                raise ValueError("No data to be added")
            if stc_surf is not None:
                array = getattr(stc_surf, hemi + "_data")
                vertices = stc_surf.vertices[0 if hemi == "lh" else 1]
            if stc_vol is not None:
                array = stc_vol.data
                vertices = np.concatenate(stc_vol.vertices)
        else:
            stc = None
        return stc, array, vertices

    def _check_hemi(self, hemi, extras=()):
        """Check for safe single-hemi input, returns str."""
        _validate_type(hemi, (None, str), "hemi")
        if hemi is None:
            if self._hemi not in ["lh", "rh"]:
                raise ValueError(
                    "hemi must not be None when both hemispheres are displayed"
                )
            hemi = self._hemi
        _check_option("hemi", hemi, ("lh", "rh") + tuple(extras))
        return hemi

    def _check_hemis(self, hemi):
        """Check for safe dual or single-hemi input, returns list."""
        if hemi is None:
            if self._hemi not in ["lh", "rh"]:
                hemi = ["lh", "rh"]
            else:
                hemi = [self._hemi]
        elif hemi not in ["lh", "rh"]:
            extra = " or None" if self._hemi in ["lh", "rh"] else ""
            raise ValueError('hemi must be either "lh" or "rh"' + extra)
        else:
            hemi = [hemi]
        return hemi

    def _to_borders(self, label, hemi, borders, restrict_idx=None):
        """Convert a label/parc to borders."""
        if not isinstance(borders, bool | int) or borders < 0:
            raise ValueError("borders must be a bool or positive integer")
        if borders:
            n_vertices = label.size
            edges = mesh_edges(self.geo[hemi].orig_faces)
            edges = edges.tocoo()
            border_edges = label[edges.row] != label[edges.col]
            show = np.zeros(n_vertices, dtype=np.int64)
            keep_idx = np.unique(edges.row[border_edges])
            if isinstance(borders, int):
                for _ in range(borders):
                    keep_idx = np.isin(self.geo[hemi].orig_faces.ravel(), keep_idx)
                    keep_idx = keep_idx.reshape(
                        self.geo[hemi].orig_faces.shape, copy=False
                    )
                    keep_idx = self.geo[hemi].orig_faces[np.any(keep_idx, axis=1)]
                    keep_idx = np.unique(keep_idx)
                if restrict_idx is not None:
                    keep_idx = keep_idx[np.isin(keep_idx, restrict_idx)]
            show[keep_idx] = 1
            label *= show

    def __hash__(self):
        """Hash the object."""
        return self._hash


def _safe_interp1d(x, y, kind="linear", axis=-1, assume_sorted=False):
    """Work around interp1d not liking singleton dimensions."""
    if y.shape[axis] == 1:

        def func(x):
            return np.take(y, np.zeros(np.asarray(x).shape, int), axis=axis)

        return func
    else:
        return interp1d(x, y, kind, axis=axis, assume_sorted=assume_sorted)


def _update_limits(fmin, fmid, fmax, center, array):
    if center is None:
        if fmin is None:
            fmin = array.min() if array.size > 0 else 0
        if fmax is None:
            fmax = array.max() if array.size > 0 else 1
    else:
        if fmin is None:
            fmin = 0
        if fmax is None:
            fmax = np.abs(center - array).max() if array.size > 0 else 1
    if fmid is None:
        fmid = (fmin + fmax) / 2.0

    if fmin >= fmid:
        raise RuntimeError(f"min must be < mid, got {fmin:0.4g} >= {fmid:0.4g}")
    if fmid >= fmax:
        raise RuntimeError(f"mid must be < max, got {fmid:0.4g} >= {fmax:0.4g}")

    return fmin, fmid, fmax


def _update_monotonic(lims, fmin, fmid, fmax):
    if fmin is not None:
        lims["fmin"] = fmin
        if lims["fmax"] < fmin:
            logger.debug(f"    Bumping fmax = {lims['fmax']} to {fmin}")
            lims["fmax"] = fmin
        if lims["fmid"] < fmin:
            logger.debug(f"    Bumping fmid = {lims['fmid']} to {fmin}")
            lims["fmid"] = fmin
    assert lims["fmin"] <= lims["fmid"] <= lims["fmax"]
    if fmid is not None:
        lims["fmid"] = fmid
        if lims["fmin"] > fmid:
            logger.debug(f"    Bumping fmin = {lims['fmin']} to {fmid}")
            lims["fmin"] = fmid
        if lims["fmax"] < fmid:
            logger.debug(f"    Bumping fmax = {lims['fmax']} to {fmid}")
            lims["fmax"] = fmid
    assert lims["fmin"] <= lims["fmid"] <= lims["fmax"]
    if fmax is not None:
        lims["fmax"] = fmax
        if lims["fmin"] > fmax:
            logger.debug(f"    Bumping fmin = {lims['fmin']} to {fmax}")
            lims["fmin"] = fmax
        if lims["fmid"] > fmax:
            logger.debug(f"    Bumping fmid = {lims['fmid']} to {fmax}")
            lims["fmid"] = fmax
    assert lims["fmin"] <= lims["fmid"] <= lims["fmax"]


def _auto_scalar_bar_fmt(rng):
    """Choose a scalar bar tick label format based on the data magnitude.

    Neural data commonly spans many orders of magnitude (e.g. ~1e-10 A·m
    dipole moments vs. ~1-10 dSPM/t-values), so a fixed-point format either
    prints unreadable strings of zeros or rounds everything to 0. Switch to
    scientific notation once the range falls outside what is comfortably
    readable in fixed-point.
    """
    abs_max = max(abs(rng[0]), abs(rng[1]))
    if abs_max != 0 and not (1e-2 <= abs_max < 1e5):
        return "%.2e"
    return "%.3g"


class _FakeIren:
    def EnterEvent(self):
        pass

    def MouseMoveEvent(self):
        pass

    def LeaveEvent(self):
        pass

    def SetEventInformation(self, *args, **kwargs):
        pass

    def CharEvent(self):
        pass

    def KeyPressEvent(self, *args, **kwargs):
        pass

    def KeyReleaseEvent(self, *args, **kwargs):
        pass
