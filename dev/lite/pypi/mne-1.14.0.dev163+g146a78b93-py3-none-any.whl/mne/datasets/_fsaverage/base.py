# Authors: The MNE-Python contributors.
# License: BSD-3-Clause
# Copyright the MNE-Python contributors.

from pathlib import Path

from ...utils import get_subjects_dir, set_config, verbose_static
from ..utils import _get_path, _manifest_check_download

FSAVERAGE_MANIFEST_PATH = Path(__file__).parent


@verbose_static()
def fetch_fsaverage(subjects_dir=None, *, verbose=None):
    """Fetch and update :ref:`fsaverage <fsaverage_background>`.

    Parameters
    ----------
    subjects_dir : str | None
        The path to use as the subjects directory in the MNE-Python
        config file. None will use the existing config variable (i.e.,
        will not change anything), and if it does not exist, will use
        ``~/mne_data/MNE-fsaverage-data``.
    verbose : bool | str | int | None
        Control verbosity of the logging output. If ``None``, use the default
        verbosity level. See the :ref:`logging documentation <tut-logging>` and
        :func:`mne.verbose` for details. Should only be passed as a keyword
        argument.

    Returns
    -------
    fs_dir : Path
        The fsaverage directory.
        (essentially ``subjects_dir / 'fsaverage'``).

        .. versionchanged:: 1.8
           A :class:`pathlib.Path` object is returned instead of a string.

    Notes
    -----
    This function is designed to provide

    1. All modern (FreeSurfer 6) fsaverage subject files
    2. All MNE fsaverage parcellations
    3. fsaverage head surface, fiducials, head<->MRI trans, 1- and 3-layer
       BEMs (and surfaces)

    This function will compare the contents of ``subjects_dir/fsaverage``
    to the ones provided in the remote zip file. If any are missing,
    the zip file is downloaded and files are updated. No files will
    be overwritten.

    The head surface ``bem/fsaverage-head.fif`` is the smooth head surface
    packaged with MNE-Python (the one :func:`mne.create_default_subject`
    installs) rather than the watershed outer skin surface. To update an
    existing copy of fsaverage, delete the file and call this function again.

    .. versionchanged:: 1.14
       The smooth head surface is used for ``bem/fsaverage-head.fif``.

    .. versionadded:: 0.18
    """
    # Code used to create the BEM (other files taken from MNE-sample-data):
    #
    # $ mne watershed_bem -s fsaverage -d $PWD --verbose info --copy
    # $ python
    # >>> bem = mne.make_bem_model('fsaverage', subjects_dir='.', verbose=True)
    # >>> mne.write_bem_surfaces(
    # ...     'fsaverage/bem/fsaverage-5120-5120-5120-bem.fif', bem)
    # >>> sol = mne.make_bem_solution(bem, verbose=True)
    # >>> mne.write_bem_solution(
    # ...     'fsaverage/bem/fsaverage-5120-5120-5120-bem-sol.fif', sol)
    # >>> import os
    # >>> import os.path as op
    # >>> names = sorted(op.join(r, f)
    # ...                for r, d, files in os.walk('fsaverage')
    # ...                for f in files)
    # with open('fsaverage.txt', 'w') as fid:
    #     fid.write('\n'.join(names))
    #
    # In fsaverage-1.1, bem/fsaverage-head.fif in both zip files was replaced
    # with mne/data/fsaverage/fsaverage-head.fif.
    #
    subjects_dir = _set_montage_coreg_path(subjects_dir)
    subjects_dir = Path(subjects_dir).expanduser().absolute()
    fs_dir = subjects_dir / "fsaverage"
    fs_dir.mkdir(parents=True, exist_ok=True)
    _manifest_check_download(
        manifest_path=FSAVERAGE_MANIFEST_PATH / "root.txt",
        destination=subjects_dir,
        url="https://github.com/mne-tools/mne-data/releases/download/fsaverage-1.1/fsaverage-root.zip",
        hash_="edad902f15196bdd0c98521e657f41b6",
    )
    _manifest_check_download(
        manifest_path=FSAVERAGE_MANIFEST_PATH / "bem.txt",
        destination=subjects_dir / "fsaverage",
        url="https://github.com/mne-tools/mne-data/releases/download/fsaverage-1.1/fsaverage-bem.zip",
        hash_="cdf3de397b02ca7f055a6d62dbfac1ff",
    )
    return fs_dir


def _get_create_subjects_dir(subjects_dir):
    subjects_dir = get_subjects_dir(subjects_dir, raise_error=False)
    if subjects_dir is None:
        subjects_dir = _get_path(None, "MNE_DATA", "montage coregistration")
        subjects_dir = subjects_dir / "MNE-fsaverage-data"
        subjects_dir.mkdir(parents=True, exist_ok=True)
    return subjects_dir


def _set_montage_coreg_path(subjects_dir=None):
    """Set a subject directory suitable for montage(-only) coregistration."""
    subjects_dir = _get_create_subjects_dir(subjects_dir)
    old_subjects_dir = get_subjects_dir(None, raise_error=False)
    if old_subjects_dir is None:
        set_config("SUBJECTS_DIR", subjects_dir)
    return subjects_dir
