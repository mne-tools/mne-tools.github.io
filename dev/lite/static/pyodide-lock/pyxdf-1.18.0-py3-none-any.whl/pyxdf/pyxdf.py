# Authors: Christian Kothe & the Intheon pyxdf team
#          Chadwick Boulay
#          Tristan Stenner
#          Clemens Brunner
#
# License: BSD (2-clause)

"""Defines the function load_xdf, which imports XDF files.

This function is closely following the load_xdf reference implementation.
"""

import functools
import gzip
import io
import itertools
import logging
import struct
from collections import OrderedDict, defaultdict
from pathlib import Path
from xml.etree.ElementTree import ParseError, fromstring

import numpy as np

__all__ = ["load_xdf"]

logger = logging.getLogger(__name__)


class StreamData:
    """Temporary per-stream data."""

    def __init__(self, xml):
        """Init a new StreamData object from a stream header."""
        fmts = {
            "double64": np.float64,
            "float32": np.float32,
            "string": object,
            "int32": np.int32,
            "int16": np.int16,
            "int8": np.int8,
            "int64": np.int64,
        }
        # number of channels
        self.nchns = int(xml["info"]["channel_count"][0])
        # nominal sampling rate in Hz
        self.srate = float(xml["info"]["nominal_srate"][0])
        # format string (int8, int16, int32, float32, double64, string)
        self.fmt = xml["info"]["channel_format"][0]
        # list of time-stamp chunks (each an ndarray, in seconds)
        self.time_stamps = []
        # list of time-series chunks (each an ndarray or list of lists)
        self.time_series = []
        # list of clock offset measurement times (in seconds)
        self.clock_times = []
        # list of clock offset measurement values (in seconds)
        self.clock_values = []
        # last observed time stamp, for delta decompression
        self.last_timestamp = 0.0
        # nominal sampling interval, in seconds, for delta decompression
        self.tdiff = 1.0 / self.srate if self.srate > 0 else 0.0
        self.effective_srate = 0.0
        # list of segments corresponding to detected time-stamp breaks
        # (each a tuple of start_idx, end_idx)
        self.segments = []
        # list of segments corresponding to detected clock resets (each
        # a tuple of start_idx, end_idx)
        self.clock_segments = []
        # pre-calc some parsing parameters for efficiency
        if self.fmt != "string":
            self.dtype = np.dtype(fmts[self.fmt])
            # little-endian view of the dtype, precomputed once because it is used
            # once per sample in _read_chunk3 (XDF sample data is little-endian)
            self.dtype_le = self.dtype.newbyteorder("<")
            # number of bytes to read from stream to handle one sample
            self.samplebytes = self.nchns * self.dtype.itemsize
            # layout of a sample with and without its time stamp, used in _read_chunk3
            # to parse whole chunks at once
            self.dtype_ts = np.dtype(
                [("flag", "u1"), ("ts", "<f8"), ("vals", self.dtype_le, (self.nchns,))]
            )
            self.dtype_nots = np.dtype(
                [("flag", "u1"), ("vals", self.dtype_le, (self.nchns,))]
            )


def verbose(func):
    """Apply the ``verbose`` argument of ``func`` to the logger for that call only.

    Without this, passing ``verbose`` leaves the level set on the module logger for
    the rest of the process, overriding whatever the application configured and
    breaking the documented meaning of ``verbose=None`` for every later call.
    """

    @functools.wraps(func)
    def wrapper(*args, verbose=None, **kwargs):
        if verbose is None:
            return func(*args, verbose=verbose, **kwargs)
        level = logger.level
        logger.setLevel(logging.DEBUG if verbose else logging.WARNING)
        try:
            return func(*args, verbose=verbose, **kwargs)
        finally:
            logger.setLevel(level)

    return wrapper


@verbose
def load_xdf(
    filename,
    select_streams=None,
    *,
    on_chunk=None,
    synchronize_clocks=True,
    handle_clock_resets=True,
    dejitter_timestamps=True,
    jitter_break_threshold_seconds=1,
    jitter_break_threshold_samples=500,
    clock_reset_threshold_seconds=5,
    clock_reset_threshold_stds=5,
    clock_reset_threshold_offset_seconds=1,
    clock_reset_threshold_offset_stds=10,
    winsor_threshold=0.0001,
    verbose=None,
):
    """Import an XDF file.

    This is an importer for multi-stream XDF (Extensible Data Format) recordings. All
    information covered by the XDF 1.0 specification is imported, plus any additional
    meta-data associated with streams or with the container file itself.

    See https://github.com/sccn/xdf/ for more information on XDF.

    The function supports several additional features, such as robust time
    synchronization, support for breaks in the data, as well as some other defects.

    Args:
        filename : Name of the file to import (*.xdf or *.xdfz).

        select_streams : int | list[int] | list[dict] | None
          One or more stream IDs to load. Accepted values are:
          - int or list[int]: load only specified stream IDs, e.g. select_streams=5
            loads only the stream with stream ID 5, whereas select_streams=[2, 4] loads
            only streams with stream IDs 2 and 4.
          - list[dict]: load only streams matching a query, e.g.
            select_streams=[{'type': 'EEG'}] loads all streams of type 'EEG'. Entries
            within a dict must all match a stream, e.g.
            select_streams=[{'type': 'EEG', 'name': 'TestAMP'}] matches streams with
            both type 'EEG' *and* name 'TestAMP'. If
            select_streams=[{'type': 'EEG'}, {'name': 'TestAMP'}], streams matching
            either the type *or* the name will be loaded.
          - None: load all streams (default).

        verbose : Passing True will set logging level to DEBUG, False will set it to
          WARNING, and None will use root logger level. The previous level is restored
          before this function returns, so the setting does not affect later calls or
          the rest of the application. (default: None)

        synchronize_clocks : Whether to enable clock synchronization based on
          ClockOffset chunks. (default: true)

        dejitter_timestamps : Whether to perform jitter removal for regularly sampled
          streams. (default: true)

        on_chunk : Function that is called for each chunk of data as it is being
          retrieved from the file; the function is allowed to modify the data (for
          example, sub-sample it). The four input arguments are (1) the matrix of
          [#channels x #samples] values (either numeric or 2D array of strings), (2) the
          vector of unprocessed local time stamps (one per sample), (3) the info struct
          for the stream (same as the .info field in the final output, but without the
          .effective_srate sub-field), and (4) the scalar stream number (1-based
          integers). The three return values are (1) the (optionally modified) data, (2)
          the (optionally modified) time stamps, and (3) the (optionally modified)
          header. (default: [])

        Parameters for advanced failure recovery in clock synchronization:

        handle_clock_resets : Whether the importer should check for potential resets of
          the clock of a stream (e.g. computer restart during recording, or hot-swap).
          Only useful if the recording system supports recording under such
          circumstances. (default: true)

        clock_reset_threshold_stds : A clock reset must be accompanied by a ClockOffset
          chunk being delayed by at least this many standard deviations from the
          distribution. (default: 5)

        clock_reset_threshold_seconds : A clock reset must be accompanied by a
          ClockOffset chunk being delayed by at least this many seconds. (default: 5)

        clock_reset_threshold_offset_stds : A clock reset must be accompanied by a
          ClockOffset difference that lies at least this many standard deviations from
          the distribution. (default: 10)

        clock_reset_threshold_offset_seconds : A clock reset must be accompanied by a
          ClockOffset difference that is at least this many seconds away from the
          median. (default: 1)

        winsor_threshold : A threshold above which the clock offsets will be treated
          robustly (i.e., like outliers), in seconds. (default: 0.0001)

        Parameters for jitter removal in the presence of data breaks:

        jitter_break_threshold_seconds : An interruption in a regularly-sampled stream
          of at least this many seconds will be considered as a potential break (if also
          the jitter_break_threshold_samples is crossed) and multiple segments will be
          returned. (default: 1)

        jitter_break_threshold_samples : An interruption in a regularly-sampled stream
          of at least this many samples will be considered as a potential break (if also
          the jitter_break_threshold_samples is crossed) and multiple segments will be
          returned. (default: 500)

    Returns:
        streams : list[dict] (one dict for each stream)
          Dicts have the following content:
          - 'time_series': Contains the time series as a [#Channels x #Samples] array of
            the type declared in ['info']['channel_format'].
          - 'time_stamps': Contains the time stamps for each sample (synced across
            streams).
          - 'info': Contains the meta-data of the stream (all values are strings).
          - 'name': Name of the stream.
          - 'type': Content type of the stream ('EEG', 'Events', ...).
          - 'channel_format': Value format ('int8', 'int16', 'int32', 'int64',
            'float32', 'double64', 'string').
          - 'nominal_srate': Nominal sampling rate of the stream (as declared by the
            device); zero for streams with irregular sampling rate.
          - 'effective_srate': Effective (measured) sampling rate of the stream if
            regular (otherwise omitted).
          - 'desc': Dict with any domain-specific meta-data.

        fileheader : Dict with file header contents in the 'info' field.

    Examples:
        >>> streams, fileheader = load_xdf('myrecording.xdf')
    """
    logger.info(f"Importing XDF file {filename}...")

    # if select_streams is an int or a list of int, load only streams associated with
    # the corresponding stream IDs
    # if select_streams is a list of dicts, use this to query and load streams
    # associated with these properties; matching happens when each stream header is
    # read, so that the file is only traversed once
    query = None
    if select_streams is None:
        pass
    elif isinstance(select_streams, int):
        select_streams = {select_streams}
    elif all(isinstance(elem, dict) for elem in select_streams):
        query = select_streams
        select_streams = set()  # filled with matching stream IDs while reading
    elif all(isinstance(elem, int) for elem in select_streams):
        select_streams = set(select_streams)
    else:
        raise ValueError(
            "Argument 'select_streams' must be an int, a list of ints, or a list of "
            "dicts."
        )

    # dict of returned streams, in order of appearance, indexed by stream id
    streams = OrderedDict()
    # dict of per-stream temporary data (StreamData), indexed by stream id
    temp = {}
    # XML content of the file header chunk
    fileheader = None

    with open_xdf(filename) as f:
        # for each chunk
        while True:
            # noinspection PyBroadException
            try:
                # read [NumLengthBytes], [Length]
                chunklen = _read_varlen_int(f)
            except EOFError:
                break
            except Exception:
                logger.exception("Error reading chunk length")
                # if there's more data available (i.e. a read() succeeds), find the next
                # boundary chunk
                if f.read(1):
                    logger.warning(
                        "got zero-length chunk, scanning forward to next boundary "
                        "chunk."
                    )
                    # move the stream position one byte back
                    f.seek(-1, 1)
                    if _scan_forward(f):
                        continue
                logger.info("  reached end of file.")
                break

            # read [Tag]
            tag = struct.unpack("<H", f.read(2))[0]
            # only query the position and format the message when it is logged,
            # because this runs once per chunk
            log_str = " Read tag: %d at %d bytes, length=%d"
            StreamId = None
            if tag in [2, 3, 4, 6]:
                _streamid = f.read(4)
                try:
                    StreamId = struct.unpack("<I", _streamid)[0]
                except struct.error:
                    # we scan forward to next (hopefully) valid block in a bid to load
                    # as much of the file as possible If the StreamId could not be
                    # parsed correctly, it will be None. We therefore also need to
                    # continue, because otherwise we might end up in one the
                    # tag-specific branches which expect a valid StreamId
                    log_str += (
                        ", StreamId is corrupt, scanning forward to next boundary "
                        "chunk."
                    )
                    pos = f.tell() - len(_streamid)
                    logger.error(log_str, tag, pos, chunklen)
                    _scan_forward(f)
                    continue
                else:
                    # to be executed if no exception was raised
                    if logger.isEnabledFor(logging.DEBUG):
                        pos = f.tell() - len(_streamid)
                        log_str += ", StreamId=%d"
                        logger.debug(log_str, tag, pos, chunklen, StreamId)

            if (
                StreamId is not None
                and select_streams is not None
                and StreamId not in select_streams
                and not (tag == 2 and query is not None)  # header decides selection
            ):
                f.read(chunklen - 2 - 4)  # skip remaining chunk contents
                continue

            # read the chunk's [Content]...
            if tag == 1:
                # read [FileHeader] chunk
                xml_string = f.read(chunklen - 2)
                fileheader = _xml2dict(fromstring(xml_string))
            elif tag == 2:
                # read [StreamHeader] chunk...
                # read [Content]
                xml_string = f.read(chunklen - 6)
                decoded_string = xml_string.decode("utf-8", "replace")
                xml = fromstring(decoded_string)
                if query is not None:
                    info = _streaminfo(StreamId, _parse_streamheader(xml))
                    if not match_streaminfos([info], query):
                        continue
                    select_streams.add(StreamId)
                hdr = _xml2dict(xml)
                streams[StreamId] = hdr
                logger.debug("  found stream " + hdr["info"]["name"][0])
                # initialize per-stream temp data
                temp[StreamId] = StreamData(hdr)
            elif tag == 3:
                # read [Samples] chunk...
                # noinspection PyBroadException
                try:
                    nsamples, stamps, values = _read_chunk3(f, temp[StreamId], chunklen)
                    logger.debug("  reading [%d,%d]", temp[StreamId].nchns, nsamples)
                    # optionally send through the on_chunk function
                    if on_chunk is not None:
                        values, stamps, streams[StreamId] = on_chunk(
                            values, stamps, streams[StreamId], StreamId
                        )
                    # append to the time series...
                    temp[StreamId].time_series.append(values)
                    temp[StreamId].time_stamps.append(stamps)
                except Exception as e:  # noqa: BLE001 (tolerate any corruption in the chunk)
                    # an error occurred (perhaps a chopped-off file): emit a warning and
                    # scan forward to the next recognized chunk
                    logger.error(
                        f"found likely XDF file corruption ({e}), scanning forward to "
                        "next boundary chunk."
                    )
                    _scan_forward(f)
            elif tag == 6:
                # read [StreamFooter] chunk
                xml_string = f.read(chunklen - 6)
                try:
                    streams[StreamId]["footer"] = _xml2dict(fromstring(xml_string))
                except ParseError as e:
                    logger.error(
                        f"found likely XDF file corruption ({e}), ignoring corrupted "
                        "XML element in footer."
                    )
            elif tag == 4:
                # read [ClockOffset] chunk
                temp[StreamId].clock_times.append(struct.unpack("<d", f.read(8))[0])
                temp[StreamId].clock_values.append(struct.unpack("<d", f.read(8))[0])
            else:
                # skip other chunk types (Boundary, ...)
                f.read(chunklen - 2)

    if query is not None and not streams:
        raise ValueError("No matching streams found.")

    # Concatenate the signal across chunks
    for stream in temp.values():
        if stream.time_stamps:
            # stream with non-empty list of chunks
            stream.time_stamps = np.concatenate(stream.time_stamps)
            if stream.fmt == "string":
                stream.time_series = list(itertools.chain(*stream.time_series))
            else:
                stream.time_series = np.concatenate(stream.time_series)
        else:
            # stream without any chunks
            stream.time_stamps = np.zeros((0,))
            if stream.fmt == "string":
                stream.time_series = []
            else:
                stream.time_series = np.zeros((0, stream.nchns))

    # perform (fault-tolerant) clock synchronization if requested
    if synchronize_clocks:
        logger.info("  performing clock synchronization...")
        temp = _clock_sync(
            temp,
            handle_clock_resets,
            clock_reset_threshold_stds,
            clock_reset_threshold_seconds,
            clock_reset_threshold_offset_stds,
            clock_reset_threshold_offset_seconds,
            winsor_threshold,
        )

    # perform jitter removal if requested
    if dejitter_timestamps:
        logger.info("  performing jitter removal...")
        temp = _jitter_removal(
            temp,
            jitter_break_threshold_seconds,
            jitter_break_threshold_samples,
            stream_headers=streams,
        )
    else:
        for stream in temp.values():
            # initialize effective_srate in case jitter_removal was not selected
            if stream.srate != 0 and len(stream.time_stamps) > 1:
                duration = stream.time_stamps[-1] - stream.time_stamps[0]
                stream.effective_srate = (len(stream.time_stamps) - 1) / duration
            # initialize segment list in case jitter_removal was not selected
            if len(stream.time_stamps) > 0:
                stream.segments.append((0, len(stream.time_stamps) - 1))  # inclusive

    for k in streams:
        stream = streams[k]
        tmp = temp[k]
        if "stream_id" in stream["info"]:  # this is non-standard
            logger.warning(
                "Found existing 'stream_id' key with value {} in StreamHeader XML. "
                "Using the 'stream_id' value {} from the beginning of the StreamHeader "
                "chunk instead.".format(stream["info"]["stream_id"], k)
            )
        if synchronize_clocks and tmp.segments != tmp.clock_segments:
            logger.warning(f"Stream {k}: Segments and clock-segments differ")
        stream["info"]["stream_id"] = k
        stream["info"]["effective_srate"] = tmp.effective_srate
        stream["info"]["segments"] = tmp.segments
        stream["info"]["clock_segments"] = tmp.clock_segments
        stream["time_series"] = tmp.time_series
        stream["time_stamps"] = tmp.time_stamps
        stream["clock_times"] = tmp.clock_times
        stream["clock_values"] = tmp.clock_values

    streams = [s for s in streams.values()]
    return streams, fileheader


def open_xdf(file):
    """Open XDF file for reading.
    :type file: str | pathlib.Path | io.RawIOBase
        File name or already opened file
    """

    if isinstance(file, (io.RawIOBase, io.BufferedIOBase)):
        if isinstance(file, io.TextIOBase):
            raise TypeError("file has to be opened in binary mode")
        f = file
    else:
        filename = Path(file)  # ensure convert to pathlib object
        # check absolute path after following symlinks
        if not filename.resolve().exists():
            raise FileNotFoundError(f"file {filename} does not exist.")

        if filename.suffix == ".xdfz" or filename.suffixes == [".xdf", ".gz"]:
            f = gzip.open(str(filename), "rb")  # noqa: SIM115 (returned open for caller)
        else:
            f = open(str(filename), "rb")  # noqa: SIM115 (returned open for caller)
    if f.read(4) != b"XDF:":  # magic bytes
        raise OSError(f"Invalid XDF file {file}")
    return f


def _read_chunk3(f, s, chunklen):
    # read [NumSampleBytes], [NumSamples]
    nsamples = _read_varlen_int(f)
    if s.fmt == "string":
        # allocate space
        stamps = np.zeros((nsamples,))
        # read a sample comprised of strings
        values = [[None] * s.nchns for _ in range(nsamples)]
        # for each sample...
        for k in range(nsamples):
            # read or deduce time stamp
            if f.read(1) != b"\x00":
                stamps[k] = struct.unpack("<d", f.read(8))[0]
            else:
                stamps[k] = s.last_timestamp + s.tdiff
            s.last_timestamp = stamps[k]
            # read the values
            for ch in range(s.nchns):
                raw = f.read(_read_varlen_int(f))
                values[k][ch] = raw.decode(errors="replace")
    else:
        # number of bytes left in the chunk after [Tag] (2 bytes), [StreamId] (4
        # bytes), [NumSampleBytes] (1 byte), and [NumSamples] (as many bytes as
        # _read_varlen_int just read into _read_varlen_int_buf)
        nbytes = chunklen - 7 - _read_varlen_int_buf[0]
        # each sample has a 1-byte flag, an optional 8-byte time stamp, and its values
        if nsamples * (1 + s.samplebytes) <= nbytes <= nsamples * (9 + s.samplebytes):
            buf = f.read(nbytes)
            samples = None
            if len(buf) == nbytes:
                samples = _parse_numeric_samples(buf, nsamples, s)
            if samples is None:
                # the chunk length does not match the time stamp flags (or the file
                # ends early), so go back and read the samples without relying on it
                f.seek(-len(buf), io.SEEK_CUR)
                samples = _read_numeric_samples(f, nsamples, s)
            stamps, values = samples
        else:
            # the chunk length does not match the number of samples, so read the
            # samples without relying on it
            stamps, values = _read_numeric_samples(f, nsamples, s)
        if nsamples:
            s.last_timestamp = stamps[-1]
    return nsamples, stamps, values


def _parse_numeric_samples(buf, nsamples, s):
    """Parse the numeric samples of a chunk from its bytes.

    Returns None if the time stamp flags do not match the number of bytes.
    """
    if len(buf) == nsamples * (9 + s.samplebytes):
        # every sample has a time stamp
        rec = np.frombuffer(buf, dtype=s.dtype_ts, count=nsamples)
        if not rec["flag"].all():
            return None
        stamps = rec["ts"].astype(np.float64)
        values = rec["vals"]
    elif len(buf) == nsamples * (1 + s.samplebytes):
        # no sample has a time stamp, so deduce them (summing sequentially like the
        # per-sample code path)
        rec = np.frombuffer(buf, dtype=s.dtype_nots, count=nsamples)
        if rec["flag"].any():
            return None
        stamps = np.full(nsamples, s.tdiff)
        stamps[0] += s.last_timestamp
        np.cumsum(stamps, out=stamps)
        values = rec["vals"]
    else:
        # only some samples have a time stamp, so walk through the samples in memory
        stamps = []
        parts = []
        last_timestamp = s.last_timestamp
        pos = 0
        try:
            for _ in range(nsamples):
                if buf[pos]:
                    last_timestamp = _unpack_timestamp(buf, pos + 1)[0]
                    pos += 9
                else:
                    last_timestamp += s.tdiff
                    pos += 1
                stamps.append(last_timestamp)
                parts.append(buf[pos : pos + s.samplebytes])
                pos += s.samplebytes
        except (IndexError, struct.error):  # ran past the end of the chunk
            return None
        if pos != len(buf):
            return None
        stamps = np.array(stamps)
        values = np.frombuffer(b"".join(parts), dtype=s.dtype_le)
        values = values.reshape(nsamples, s.nchns)
    # copy into a writable array of the native dtype
    return stamps, values.astype(s.dtype)


def _read_numeric_samples(f, nsamples, s):
    """Read the numeric samples of a chunk one by one."""
    stamps = np.zeros((nsamples,))
    values = np.zeros((nsamples, s.nchns), dtype=s.dtype)
    # read buffer
    raw = bytearray(s.samplebytes)
    last_timestamp = s.last_timestamp
    # for each sample...
    for k in range(nsamples):
        # read or deduce time stamp
        if f.read(1) != b"\x00":
            last_timestamp = struct.unpack("<d", f.read(8))[0]
        else:
            last_timestamp += s.tdiff
        stamps[k] = last_timestamp
        # read the values
        if f.readinto(raw) < len(raw):
            raise EOFError("unexpected end of file in samples chunk")
        # no fromfile(), see https://github.com/numpy/numpy/issues/13319
        values[k, :] = np.frombuffer(raw, dtype=s.dtype_le, count=s.nchns)
    return stamps, values


_read_varlen_int_buf = bytearray(1)
_unpack_timestamp = struct.Struct("<d").unpack_from


def _read_varlen_int(f):
    """Read a variable-length integer."""
    if not f.readinto(_read_varlen_int_buf):
        raise EOFError()
    nbytes = _read_varlen_int_buf[0]
    if nbytes == 1:
        return ord(f.read(1))
    elif nbytes == 4:
        return struct.unpack("<I", f.read(4))[0]
    elif nbytes == 8:
        return struct.unpack("<Q", f.read(8))[0]
    else:
        raise RuntimeError("invalid variable-length integer encountered.")


def _xml2dict(t):
    """Convert an attribute-less etree.Element into a dict."""
    dd = defaultdict(list)
    for dc in map(_xml2dict, list(t)):
        for k, v in dc.items():
            dd[k].append(v)
    return {t.tag: dd or t.text}


def _scan_forward(f):
    """Scan forward through file object until after the next boundary chunk."""
    blocklen = 2**20
    signature = bytes(
        [
            0x43,
            0xA5,
            0x46,
            0xDC,
            0xCB,
            0xF5,
            0x41,
            0x0F,
            0xB3,
            0x0E,
            0xD5,
            0x46,
            0x73,
            0x83,
            0xCB,
            0xE4,
        ]
    )
    while True:
        curpos = f.tell()
        block = f.read(blocklen)
        matchpos = block.find(signature)
        if matchpos != -1:
            f.seek(curpos + matchpos + len(signature))
            logger.debug("  scan forward found a boundary chunk.")
            return True
        if len(block) < blocklen:
            logger.debug("  scan forward reached end of file with no match.")
            return False


def _find_segment_indices(b_breaks):
    """Convert boundary breaks array to segment indices.

    Args:
        b_breaks : 1D bool array representing breaks between values.

    Returns:
        segments : list[tuple] (one tuple per segment)
          - tuple: inclusive start and end indices.

        start_idx : array
          - segment start indices

        end_idx : array
          - segment end indices
    """
    break_inds = np.where(b_breaks)[0]
    # Start: +1 to compensate for lost sample in np.diff
    start_idx = np.hstack(([0], break_inds + 1))
    # End: inclusive range (+1 will be required for slicing)
    end_idx = np.hstack((break_inds, len(b_breaks)))
    segments = list(zip(start_idx.tolist(), end_idx.tolist()))
    return segments, start_idx, end_idx


def _segment_clock_diff(diff, thresh_stds, thresh_secs):
    median = np.median(diff)
    diffs_shift = diff - median
    diffs_shift_abs = np.abs(diffs_shift)
    # Median absolute deviation
    mad = np.median(diffs_shift_abs) + np.finfo(float).eps
    # MAD-standardised distribution
    diffs_std = diffs_shift / mad
    cond1 = np.abs(diffs_std) > thresh_stds
    cond2 = diffs_shift_abs > thresh_secs
    b_break = cond1 & cond2
    return b_break


def _detect_clock_resets(
    stream,
    time_thresh_stds,
    time_thresh_secs,
    value_thresh_stds,
    value_thresh_secs,
):
    # First detect potential breaks in the synchronization data; this is
    # only necessary when the importer should be able to deal with
    # recordings where the computer that served a stream was restarted or
    # hot-swapped during an ongoing recording, or the clock was reset
    # otherwise.

    if len(stream.clock_times) <= 1:
        raise ValueError("Two or more clock offsets are required for reset detection")

    time_diff = np.diff(stream.clock_times)
    value_diff = np.diff(stream.clock_values)

    # Always segment at negative time intervals
    decreasing = time_diff < 0

    # Segment at time glitches
    time_glitch = _segment_clock_diff(
        time_diff,
        time_thresh_stds,
        time_thresh_secs,
    )

    # Segment at value glitches
    value_glitch = _segment_clock_diff(
        value_diff,
        value_thresh_stds,
        value_thresh_secs,
    )
    resets_at = decreasing | time_glitch & value_glitch

    # Determine segments: [start,end] index ranges between resets (inclusive)
    segments = _find_segment_indices(resets_at)[0]
    return segments


def _clock_sync(
    streams,
    handle_clock_resets=True,
    reset_threshold_stds=5,
    reset_threshold_seconds=5,
    reset_threshold_offset_stds=10,
    reset_threshold_offset_seconds=1,
    winsor_threshold=0.0001,
):
    for stream_id, stream in streams.items():
        if len(stream.time_stamps) > 0:
            clock_times = stream.clock_times
            clock_values = stream.clock_values
            if not clock_times:
                continue

            # Detect clock resets (e.g., computer restarts during recording) if
            # requested, this is only for cases where "everything goes wrong" during
            # recording note that this is a fancy feature that is not needed for normal
            # XDF compliance.
            if handle_clock_resets and len(clock_times) > 1:
                logger.debug(f" Handling clock resets stream: {stream_id}")
                ranges = _detect_clock_resets(
                    stream,
                    reset_threshold_stds,
                    reset_threshold_seconds,
                    reset_threshold_offset_stds,
                    reset_threshold_offset_seconds,
                )
            # Otherwise we just assume that there are no clock resets
            else:
                ranges = [(0, len(clock_times) - 1)]
            logger.debug(f"  Clock reset ranges: {ranges}")

            # Calculate clock offset mappings for each data range
            coef = []
            for range_i in ranges:
                if range_i[0] != range_i[1]:
                    start, stop = range_i[0], range_i[1] + 1
                    X = np.column_stack(
                        [
                            np.ones(stop - start),
                            np.array(clock_times[start:stop]) / winsor_threshold,
                        ]
                    )
                    y = np.array(clock_values[start:stop]) / winsor_threshold
                    try:
                        # noinspection PyTypeChecker
                        _coefs = _robust_fit(X, y)
                        _coefs[0] *= winsor_threshold
                    except np.linalg.LinAlgError:
                        logger.warning(
                            f"Stream {stream_id}: "
                            f"Clock offsets {range_i} cannot be used for synchronization"
                        )
                        _coefs = [0, 0]
                    coef.append(_coefs)
                else:
                    # Intercept for single sample segments
                    coef.append((clock_values[range_i[0]], 0))

            # Apply the correction to all time-stamps
            if len(ranges) == 1:
                stream.time_stamps += coef[0][0] + (coef[0][1] * stream.time_stamps)
                stream.clock_segments.append(
                    (0, len(stream.time_stamps) - 1)  # inclusive
                )
            else:
                # Assumes time-stamps are monotonically increasing
                ts_start = 0
                for coef_i, range_i in zip(coef, ranges):
                    stop = range_i[1] + 1
                    if stop < len(clock_times):
                        # Break at the first time-stamp that is closer to the next
                        # clock-time than the end of the current clock segment
                        current_end_t = clock_times[range_i[1]]
                        next_start_t = clock_times[stop]
                        cond = np.less(
                            np.abs(stream.time_stamps[ts_start:] - current_end_t),
                            np.abs(stream.time_stamps[ts_start:] - next_start_t),
                        )
                        if all(cond):
                            ts_stop = ts_start + len(cond)
                        else:
                            ts_stop = ts_start + np.argmin(cond).item()
                    else:
                        # Include all time-stamps from the last break until the end
                        ts_stop = len(stream.time_stamps)

                    if ts_start == ts_stop:
                        logger.warning(
                            f"Stream {stream_id}: "
                            f"No samples in clock offsets {range_i}, skipping..."
                        )
                    else:
                        stream.clock_segments.append((ts_start, ts_stop - 1))
                        ts_slice = slice(ts_start, ts_stop)
                        ts_start = ts_stop
                        stream.time_stamps[ts_slice] += (
                            coef_i[0] + coef_i[1] * stream.time_stamps[ts_slice]
                        )
    return streams


def _detect_breaks(stream, threshold_seconds=1.0, threshold_samples=500):
    """Detect breaks in the time_stamps of a stream.

    Returns:
        b_breaks : 1D bool array representing breaks between values.
    """
    diffs = np.diff(stream.time_stamps)

    b_breaks = np.abs(diffs) > np.max(
        (threshold_seconds, threshold_samples * stream.tdiff)
    )
    return b_breaks


def _stream_can_drop_samples(stream_meta):
    """Return True if stream metadata indicates samples can be dropped."""
    if not stream_meta:
        return False

    info = stream_meta.get("info", {})
    desc = info.get("desc")
    if not isinstance(desc, list) or len(desc) == 0 or not isinstance(desc[0], dict):
        return False

    synchronization = desc[0].get("synchronization")
    if (
        not isinstance(synchronization, list)
        or len(synchronization) == 0
        or not isinstance(synchronization[0], dict)
    ):
        return False

    can_drop_samples = synchronization[0].get("can_drop_samples")
    if not isinstance(can_drop_samples, list) or len(can_drop_samples) == 0:
        return False

    return str(can_drop_samples[0]).lower() == "true"


def _jitter_removal(
    streams,
    threshold_seconds=1,
    threshold_samples=500,
    stream_headers=None,
):
    for stream_id, stream in streams.items():
        stream.effective_srate = 0  # will be recalculated if possible
        nsamples = len(stream.time_stamps)
        if nsamples > 0:
            if stream.srate == 0:
                # Initialise default segment for irregular sampling rate streams
                stream.segments.append((0, nsamples - 1))  # inclusive
                continue

            # Streams that can drop samples (e.g., video/HMD) should not undergo linear
            # dejittering because it compresses dropped-frame intervals and can shift
            # the segment start substantially earlier.
            if _stream_can_drop_samples(
                None if stream_headers is None else stream_headers.get(stream_id)
            ):
                stream.segments.append((0, nsamples - 1))  # inclusive
                if nsamples > 1:
                    duration = stream.time_stamps[-1] - stream.time_stamps[0]
                    if duration > 0:
                        stream.effective_srate = (nsamples - 1) / duration
                continue

            # Find boundary breaks
            b_breaks = _detect_breaks(stream, threshold_seconds, threshold_samples)
            # Find segment indices
            segments, start_idx, stop_idx = _find_segment_indices(b_breaks)
            logger.debug(f" Stream {stream_id}: segments={len(segments)}")
            stream.segments.extend(segments)

            # Process each segment separately
            for start_i, stop_i in segments:
                # Calculate time stamps assuming constant intervals within each segment
                # (stop_i + 1 because we want inclusive closing range)
                n = stop_i - start_i + 1
                if n > 1:
                    # Closed-form least-squares line fit on centered sample indices
                    # (n * (n**2 - 1) / 12 is the sum of their squares)
                    y = stream.time_stamps[start_i : stop_i + 1]
                    idx = np.arange(n) - (n - 1) / 2
                    y_mean = np.mean(y)
                    slope = np.dot(idx, y - y_mean) / (n * (n**2 - 1) / 12)
                    y[:] = y_mean + slope * idx

            # Recalculate effective_srate if possible
            counts = (stop_idx + 1) - start_idx
            if np.any(counts > 1):
                # Calculate segment durations
                durations = stream.time_stamps[stop_idx] - stream.time_stamps[start_idx]
                # Calculate effective srate as weighted mean
                stream.effective_srate = np.sum(counts - 1) / np.sum(durations)

            srate, effective_srate = stream.srate, stream.effective_srate
            if np.abs(srate - effective_srate) / srate > 0.1:
                msg = (
                    "Stream %d: Calculated effective sampling rate %.4f Hz is different "
                    "from specified rate %.4f Hz."
                )
                logger.warning(msg, stream_id, effective_srate, srate)
    return streams


# noinspection PyTypeChecker
def _robust_fit(A, y, rho=1, iters=1000):
    """Perform a robust linear regression using the Huber loss function.

    solves the following problem via ADMM for x:
        minimize 1/2*sum(huber(A*x - y))

    Args:
        A : design matrix
        y : target variable
        rho : augmented Lagrangian variable (default: 1)
        iters : number of iterations to perform (default: 1000)

    Returns:
        x : solution for x

    Based on the ADMM Matlab codes also found at:
    http://www.stanford.edu/~boyd/papers/distr_opt_stat_learning_admm.html
    """
    A = np.copy(A)  # don't mutate input.
    offset = np.min(A[:, 1])
    A[:, 1] -= offset
    L = np.linalg.cholesky(np.dot(A.T, A))
    # the x-update solves (A'A) x = A'(y + z - u), so precompute (A'A)^-1 A'
    P = np.linalg.solve(L.T, np.linalg.solve(L, A.T))
    # the z-update is the Huber proximal operator, which makes the u-update
    # u = d - z = clip(d, -thresh, thresh) / (1 + rho), so z - u = d - 2u
    thresh = 1 + 1 / rho
    u = np.zeros_like(y)
    z_minus_u = np.zeros_like(y)
    x = np.zeros(A.shape[1])
    for k in range(iters):
        x = np.dot(P, y + z_minus_u)
        d = np.dot(A, x) - y + u
        u = np.clip(d, -thresh, thresh) / (1 + rho)
        z_minus_u = d - 2 * u
    x[0] -= x[1] * offset
    return x


def match_streaminfos(stream_infos, parameters, *, case_sensitive=True):
    """Find stream IDs matching specified criteria.

    Parameters
    ----------
    stream_infos : list of dicts
        List of dicts containing information on each stream. This information can be
        obtained using the function resolve_streams.
    parameters : list of dicts
        List of dicts containing key/values that should be present in streams.
        Examples:
          - [{"name": "Keyboard"}] matches all streams with a "name" field equal to
            "Keyboard".
          - [{"name": "Keyboard"}, {"type": "EEG"}] matches all streams with a "name"
            field equal to "Keyboard" and all streams with a "type" field equal to
            "EEG".
    case_sensitive : bool
        Whether or not matching of values corresponding to keys from `parameters` and
        the stream info should be done case sensitive. Defaults to `True`.

    Returns
    -------
    list of int
        A list of unique stream IDs matching the specified criteria.
    """
    matches = []
    match = False
    for request in parameters:
        for info in stream_infos:
            for key in request:
                if case_sensitive:
                    match = info[key] == request[key]
                else:
                    match = info[key].lower() == request[key].lower()
                if not match:
                    break
            if match:
                matches.append(info["stream_id"])

    return list(set(matches))  # unique values only


def resolve_streams(fname):
    """Resolve streams in given XDF file.

    Parameters
    ----------
    fname : str
        Name of the XDF file.

    Returns
    -------
    stream_infos : list of dicts
        List of dicts containing information on each stream.
    """
    return parse_chunks(parse_xdf(fname))


def parse_xdf(fname):
    """Parse and return chunks contained in an XDF file.

    Parameters
    ----------
    fname : str
        Name of the XDF file.

    Returns
    -------
    chunks : list
        List of all chunks contained in the XDF file.
    """
    with open_xdf(fname) as f:
        chunks = list(_read_chunks(f))
    return chunks


def parse_chunks(chunks):
    """Parse chunks and extract information on individual streams."""
    streams = []
    for chunk in chunks:
        if chunk["tag"] == 2:  # stream header chunk
            streams.append(_streaminfo(chunk["stream_id"], chunk))
    return streams


def _streaminfo(stream_id, header):
    """Create stream info (as used by match_streaminfos) from parsed header fields."""
    return {
        "stream_id": stream_id,
        "name": header.get("name"),  # optional
        "type": header.get("type"),  # optional
        "source_id": header.get("source_id"),  # optional
        "created_at": header.get("created_at"),  # optional
        "uid": header.get("uid"),  # optional
        "session_id": header.get("session_id"),  # optional
        "hostname": header.get("hostname"),  # optional
        "channel_count": int(header["channel_count"]),
        "channel_format": header["channel_format"],
        "nominal_srate": float(header["nominal_srate"]),
    }


def _read_chunks(f):
    """Read and yield XDF chunks.

    Parameters
    ----------
    f : file handle
        File handle of XDF file.

    Yields
    ------
    chunk : dict
        XDF chunk.
    """
    while True:
        chunk = {}
        try:
            chunk["nbytes"] = _read_varlen_int(f)
        except EOFError:
            return
        chunk["tag"] = struct.unpack("<H", f.read(2))[0]
        if chunk["tag"] in [2, 3, 4, 6]:
            chunk["stream_id"] = struct.unpack("<I", f.read(4))[0]
            if chunk["tag"] == 2:  # parse StreamHeader chunk
                # if you edit, check for consistency with parsing in load_xdf
                msg = f.read(chunk["nbytes"] - 6).decode("utf-8", "replace")
                xml = fromstring(msg)
                chunk = {**chunk, **_parse_streamheader(xml)}
            else:  # skip remaining chunk contents
                f.seek(chunk["nbytes"] - 6, 1)
        else:
            f.seek(chunk["nbytes"] - 2, 1)  # skip remaining chunk contents
        yield chunk


def _parse_streamheader(xml):
    """Parse stream header XML."""
    return {el.tag: el.text for el in xml if el.tag != "desc"}
