import numpy as np
import pytest
from mne import EpochsArray, create_info
from mne.utils import assert_object_equal
from numpy.testing import (
    assert_almost_equal,
    assert_array_almost_equal,
    assert_array_equal,
    assert_array_less,
)

from mne_connectivity import Connectivity, select_order, vector_auto_regression

warning_str = dict(
    sm_depr="ignore:Using or importing*.:DeprecationWarning",  # noqa
)


def bivariate_var_data():
    """Bivariate dataset for VAR estimation."""
    rng = np.random.RandomState(12345)
    e = rng.standard_normal((252, 2))
    y = np.zeros_like(e)
    y[:2] = e[:2]
    for i in range(2, 252):
        y[i] = 0.2 * y[i - 1] + 0.1 * y[i - 2] + e[i]
    return y


def create_noisy_data(
    add_noise,
    sigma=1e-4,
    m=100,
    random_state=12345,
):
    """Create noisy test data.

    Generate a 2x2 linear system, and perturb
    observations of the state variables with Gaussian noise.

    Parameters
    ----------
    add_noise : bool
        Whether to add noise or not.
    sigma : float
        noise standard deviation.
    m : int
        The number of samples.
    return_A : bool
        Whether to return the A matrix
    random_state : None | int | instance of ~numpy.random.RandomState
        If ``random_state`` is an :class:`int`, it will be used as a seed for
        :class:`~numpy.random.RandomState`. If ``None``, the seed will be
        obtained from the operating system (see
        :class:`~numpy.random.RandomState` for details). Default is
        ``None``.

    Returns
    -------
    sample_data : array, shape (n_channels, n_samples)
        Observed sample data. Possibly with noise.
    sample_eigs : array
        The true eigenvalues of the system.
    sample_A : array
        (Optional) if ``return_A`` is True, then returns the
        true linear system matrix.
    """
    rng = np.random.RandomState(random_state)

    mu = 0.0
    noise = rng.normal(mu, sigma, m)  # gaussian noise
    A = np.array([[1.0, 1.0], [-1.0, 2.0]])
    A /= np.sqrt(3)

    # compute true eigenvalues
    true_eigvals = np.linalg.eigvals(A)

    n = 2
    X = np.zeros((n, m))
    X[:, 0] = np.array([0.5, 1.0])
    # evolve the system and perturb the data with noise
    for k in range(1, m):
        X[:, k] = A.dot(X[:, k - 1])

        if add_noise:
            X[:, k - 1] += noise[k - 1]

    return X, true_eigvals, A


# XXX: get this to work with all trends
@pytest.mark.parametrize(
    ["lags", "trend"],
    [
        (1, "n"),
        (2, "n"),
        (3, "n"),
    ],
)
@pytest.mark.filterwarnings(warning_str["sm_depr"])
def test_regression_against_statsmodels(lags, trend):
    """Test regression against any statsmodels changes in VAR model."""
    from statsmodels.tsa.vector_ar.var_model import VAR

    sample_data, _, sample_A = create_noisy_data(add_noise=False, random_state=12345)
    block_size = sample_data.shape[0]

    # statsmodels feeds in (n_samples, n_channels)
    sm_var = VAR(endog=sample_data.T)
    sm_params = sm_var.fit(maxlags=lags, trend=trend)

    # the returned VAR model is transposed
    sm_A = sm_params.params.T

    # compute the model
    model = vector_auto_regression(sample_data[np.newaxis, ...], lags=lags)

    # the models should match against the sample A matrix without noise
    if lags == 1 and trend == "n":
        assert_array_almost_equal(model.get_data(output="dense").squeeze(), sample_A)

    # the models should match each other
    if lags == 1:
        assert_array_almost_equal(model.get_data().squeeze(), sm_A.squeeze())
    else:
        for idx in range(lags):
            assert_array_almost_equal(
                model.get_data().squeeze()[..., idx],
                sm_A.squeeze()[:, idx * block_size : (idx + 1) * block_size],
            )

    if lags == 3:
        if np.max(np.abs(np.linalg.eigvals(model.companion))) < 1.0:
            # the regressed model should be stable for sufficient lags
            assert model.is_stable()
        else:
            assert not model.is_stable()


@pytest.mark.filterwarnings(warning_str["sm_depr"])
@pytest.mark.parametrize(["lags"], [(None,), (5,), (200,)])
def test_regression_select_order(lags):
    """Test regression select_order."""
    from statsmodels.tsa.vector_ar.var_model import VAR

    x = bivariate_var_data()
    sm_model = VAR(endog=x)
    if lags != 200:
        results = sm_model.select_order(maxlags=lags)
    else:
        with pytest.raises(ValueError, match="maxlags is too large"):
            select_order(X=x, maxlags=lags)
        return

    sm_selected_orders = results.selected_orders

    # compare with our version
    selected_orders = select_order(X=x, maxlags=lags)
    assert_object_equal(sm_selected_orders, selected_orders)


def test_regression():
    """Regression test to prevent numerical changes for VAR.

    This was copied over from the working version that
    matches statsmodels VAR answer.
    """
    sample_data, sample_eigs, sample_A = create_noisy_data(add_noise=True)

    # create 3D array input
    sample_data = sample_data[np.newaxis, ...]

    # compute the model
    model = vector_auto_regression(sample_data, lags=1)

    # test the recovered model
    expected_A = np.array([[0.57733211, 0.57736152], [-0.57735815, 1.15471885]])
    assert_array_almost_equal(model.get_data(output="dense").squeeze(), expected_A)

    assert_array_almost_equal(
        sample_eigs, np.linalg.eigvals(model.get_data().squeeze())
    )

    # without noise, the estimated A should match exactly
    sample_data, _, sample_A = create_noisy_data(add_noise=False)
    sample_data = sample_data[np.newaxis, ...]
    model = vector_auto_regression(sample_data)
    assert_array_almost_equal(model.get_data(output="dense").squeeze(), sample_A)


def test_var_debiased():
    """Test forward backward operator."""
    sample_data, sample_eigs, _ = create_noisy_data(add_noise=True, sigma=1e-2)

    # test without forward backward de-biasing
    model = vector_auto_regression(sample_data[np.newaxis, ...])

    # test with forward backward de-biasing
    model_fb = vector_auto_regression(
        sample_data[np.newaxis, ...], compute_fb_operator=True
    )

    # manually solve things using pseudoinverse
    eigvals = model.eigvals()
    eigvals_fb = model_fb.eigvals()

    assert np.linalg.norm(eigvals - sample_eigs) > np.linalg.norm(
        eigvals_fb - sample_eigs
    )


@pytest.mark.parametrize("l2_reg", np.linspace(0, 5, 10))
def test_var_l2_reg(l2_reg):
    """Test l2 regularization works as expected."""
    sample_data, _, _ = create_noisy_data(add_noise=True)

    # test l2 regularization
    model = vector_auto_regression(sample_data[np.newaxis, ...], l2_reg=l2_reg)

    # manually solve things using pseudoinverse
    sample_data = sample_data.T
    X, Y = sample_data.squeeze()[:-1, :], sample_data.squeeze()[1:, :]
    n_col = X.shape[1]
    manual_A = np.linalg.lstsq(
        X.T.dot(X) + l2_reg * np.eye(n_col), X.T.dot(Y), rcond=-1
    )[0].T
    assert_array_almost_equal(model.get_data().squeeze(), manual_A)


@pytest.mark.timeout(15)
def test_vector_auto_regression_computation():
    """Test VAR model computation accuracy.

    Tests eigenvalue and state matrix recovery.
    """
    np.random.RandomState(12345)
    sample_data, sample_eigs, sample_A = create_noisy_data(add_noise=True)

    # create 3D array input
    sample_data = sample_data[np.newaxis, ...]

    # compute the model
    model = vector_auto_regression(sample_data)

    # test the recovered model
    assert_array_almost_equal(
        model.get_data(output="dense").squeeze(), sample_A, decimal=2
    )

    # get the eigenvalues and test accuracy of recovery
    eigs = np.linalg.eigvals(model.get_data(output="dense").squeeze())
    eigvals_diff = np.linalg.norm(eigs - sample_eigs)
    assert_almost_equal(
        np.linalg.norm(eigs[1]), np.linalg.norm(sample_eigs[1]), decimal=2
    )
    assert_almost_equal(eigvals_diff, 0, decimal=2)


def test_vector_auto_regression():
    """Test the var function."""
    rng = np.random.RandomState(0)
    n_epochs, n_signals, n_times = 2, 4, 64
    data = rng.randn(n_epochs, n_signals, n_times)
    times = np.arange(n_times)

    with pytest.raises(ValueError, match='"model" parameter'):
        vector_auto_regression(data, model="static")

    # compute time-varying var
    conn = vector_auto_regression(data, times=times)

    # parallel conn should be exactly the same
    parr_conn = vector_auto_regression(data, times=times, n_jobs=-1)
    assert_array_equal(parr_conn.get_data(), conn.get_data())

    # compute connectivity with forward-backwards operator
    vector_auto_regression(data, times=times, compute_fb_operator=True, n_jobs=-1)

    # compute single var
    single_conn = vector_auto_regression(data, model="avg-epochs")
    assert_array_almost_equal(
        conn.get_data().mean(axis=0), single_conn.get_data(), decimal=1
    )

    # compute single var with multiple lags
    single_conn_plags = vector_auto_regression(data, model="avg-epochs", lags=2)
    single_conn_plags.get_data("dense")  # just check data can be reshaped properly

    # compute residuals
    residuals = data - parr_conn.predict(data)
    assert residuals.shape == data.shape
    # TODO: Add checks about properties of residuals


@pytest.mark.parametrize("lags", [1, 2])
def test_vector_auto_regression_residuals(lags):
    """Test the residuals of a fitted VAR model."""
    rng = np.random.default_rng(0)
    n_epochs, n_signals, n_times = 5, 3, 64
    data = rng.standard_normal(size=(n_epochs, n_signals, n_times))

    # Compute VAR models
    var_dyn = vector_auto_regression(data, model="dynamic", lags=lags)
    var_avg = vector_auto_regression(data, model="avg-epochs", lags=lags)

    # Compute residuals
    res_dyn = data - var_dyn.predict(data)
    res_avg = data - var_avg.predict(data)

    # Check residuals for each channel are smaller for the dynamic model
    assert_array_less(
        np.abs(res_dyn[:, :, lags:]).mean((0, -1)),
        np.abs(res_avg[:, :, lags:]).mean((0, -1)),
    )


@pytest.mark.parametrize("model", ["avg-epochs", "dynamic"])
def test_vector_auto_regression_bad_channels(model):
    """Test bad channels are handled properly in vector_auto_regression."""
    rng = np.random.default_rng(0)
    n_epochs, n_signals, n_times = 1, 3, 64
    data = rng.standard_normal(size=(n_epochs, n_signals, n_times))
    info = create_info(n_signals, sfreq=n_times, ch_types="eeg")
    info["bads"] = ["1"]
    data = EpochsArray(data, info)
    corr = vector_auto_regression(data, model=model)
    corr_data = corr.get_data()
    if model == "dynamic":
        corr_data = corr_data[0]  # take only epoch

    assert corr.n_nodes == n_signals
    assert corr.names == data.ch_names
    assert_array_equal(corr_data[[0, 2, 1, 1, 1], [1, 1, 0, 1, 2]], 0)  # bads indices
    assert corr_data.shape == (n_signals, n_signals)


@pytest.mark.parametrize("model", ["avg-epochs", "dynamic"])
@pytest.mark.parametrize("lags", [1, 2])
def test_dynamic_mixin(model, lags):
    """Test the `DynamicMixin` for VAR models."""
    # Generate random data
    rng = np.random.default_rng(0)
    n_epochs, n_signals, n_times = 5, 3, 64
    data = rng.standard_normal(size=(n_epochs, n_signals, n_times))

    # Create a VAR model
    var = vector_auto_regression(data, model=model, lags=lags)

    # Check predictions can be made from the VAR model (using epoched data)
    prediction = var.predict(data)
    assert prediction.shape == data.shape
    assert_array_equal(prediction[..., :lags], 0)  # predictions for lags should be zero

    # Check predictions from a static model can be made from non-epoched data
    if model == "avg-epochs":
        prediction = var.predict(data[0])
        assert prediction.shape == data.shape[1:]
        assert_array_equal(prediction[..., :lags], 0)  # predictions for lags

    # Check data can be simulated from the VAR model
    n_samples = 10
    simulation = var.simulate(n_samples=n_samples)
    assert simulation.shape == (n_signals, n_samples)

    # Check the companion matrix can be computed for the VAR model
    companion = var.companion
    if lags == 1:
        expected_shape = (n_signals, n_signals)
    else:
        expected_shape = (n_signals * lags, n_signals * lags)
    if model == "dynamic":
        expected_shape = (n_epochs, *expected_shape)
    assert companion.shape == expected_shape
    if lags == 1:
        assert_array_equal(companion, var.get_data(output="dense"))


def test_dynamic_mixin_errors():
    """Test error handling in the `DynamicMixin` for VAR models."""
    # Generate random data
    rng = np.random.default_rng(0)
    n_epochs, n_signals, n_times = 5, 3, 64
    data = rng.standard_normal(size=(n_epochs, n_signals, n_times))

    # Create a dynamic VAR model
    dynamic_var = vector_auto_regression(data, model="dynamic")

    # Check non-epoched data can't be predicted from a dynamic VAR model
    with pytest.raises(
        ValueError, match="For a time-varying VAR model, `data` must be a 3D array"
    ):
        dynamic_var.predict(data[0])

    # Check the number of epochs in the data to predict matches the number in the model
    with pytest.raises(
        ValueError,
        match=(
            r"The number of epochs in `data`.*does not match the number of VAR models.*"
        ),
    ):
        dynamic_var.predict(data[:3])

    # Check bad number of data dims gets caught
    with pytest.raises(ValueError, match="`data` must be either 2D or 3D"):
        dynamic_var.predict(data[0, 0])

    # Check bad number of channels to predict gets caught
    with pytest.raises(
        ValueError,
        match=(
            r"The number of signals in `data`.*does not match the number of signals in "
            r"the VAR model.*"
        ),
    ):
        dynamic_var.predict(data[:, : n_signals - 1])

    # Check components in the connectivity data get caught
    n_comps = 2
    mv_var_data = rng.standard_normal(size=(n_signals**2, n_comps))
    mv_var = Connectivity(
        mv_var_data, n_nodes=n_signals, method="VAR(p)", lags=1, components=n_comps
    )
    with pytest.raises(
        NotImplementedError,
        match=(
            "Prediction is not currently supported from VAR models with multiple "
            "components."
        ),
    ):
        mv_var.predict(data)
    with pytest.raises(
        NotImplementedError,
        match=(
            "Simulation is not currently supported from VAR models with multiple "
            "components."
        ),
    ):
        mv_var.simulate(n_samples=10)
    with pytest.raises(
        NotImplementedError,
        match=(
            "Companion matrix generation is not currently supported for VAR models "
            "with multiple components."
        ),
    ):
        mv_var.companion

    # Check a warning is raised when a non-VAR model is used for prediction
    n_nodes = 3
    non_var_data = rng.standard_normal(size=(n_nodes**2,))
    non_var = Connectivity(
        non_var_data, n_nodes=n_nodes, method="not a var model", lags=1
    )
    expected_warning = (
        rf"The connectivity data comes from a method \({non_var.method}\) that is not "
        r"a recognised vector autoregressive \(VAR\) model."
    )
    with pytest.warns(UserWarning, match=expected_warning):
        non_var.predict(data)
    # ... for simulation
    with pytest.warns(UserWarning, match=expected_warning):
        non_var.simulate(n_samples=10)
    # ... for companion matrix
    with pytest.warns(UserWarning, match=expected_warning):
        non_var.companion
