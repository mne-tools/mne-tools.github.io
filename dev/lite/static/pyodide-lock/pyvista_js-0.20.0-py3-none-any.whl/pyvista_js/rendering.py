"""vtk.js rendering backend for pyvista-js.

This module provides the JavaScript bridge to vtk.js for rendering
in Pyodide/browser environments.

Architecture
------------
pyvista-js uses a backend abstraction to support multiple environments:

1. **VTKJSRenderer**: Used in Pyodide/browser with vtk.js for WebGL rendering
2. **BrowserRenderer**: Used in standard Python; opens the plot in the default browser
3. **MockRenderer**: Used in standard Python for development/testing

Environment Detection
---------------------
The library automatically detects the runtime:

>>> import sys
>>> PYODIDE_ENV = sys.platform == "emscripten"  # True in Pyodide

If running in Pyodide and vtk.js is available, VTKJSRenderer is used.
If running in standard Python, BrowserRenderer opens the plot in the default browser.
MockRenderer provides a fallback for testing.

Data Conversion
---------------
NumPy arrays are converted to JavaScript for vtk.js.

Python NumPy array (n, 3)::

    points = mesh.points

    # Convert to JavaScript flat array
    points_js = points.flatten().tolist()
    polydata.getPoints().setData(points_js, 3)

Loading vtk.js
--------------
vtk.js is automatically loaded when VTKJSRenderer is initialized in
IPython/Jupyter environments. No manual script loading required.

For manual loading or custom versions:

.. code-block:: html

    <script src="https://unpkg.com/vtk.js"></script>
    <script>
      window.vtk = vtk;  // Expose to global scope
    </script>

Examples
--------
Using the renderer (automatically selected)::

    from pyvista_js.rendering import get_renderer
    from pyvista_js import Sphere

    renderer = get_renderer()
    mesh = Sphere()
    renderer.add_mesh_actor(mesh, color='red', opacity=0.8)
    renderer.create_container('viz-container')
    renderer.render()

In Pyodide environment, this uses vtk.js. In standard Python,
it opens the visualization in the default web browser.

"""

from __future__ import annotations

import logging
import os
import pathlib
import secrets
import sys
import tempfile
import time
import webbrowser
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path
    from typing import Self

    import numpy as np
    from numpy.typing import ArrayLike
    from playwright.sync_api import Browser, Playwright

    from .camera import Camera
    from .light import Light
    from .mesh import PolyData, UnstructuredGrid
    from .text import Text
    from .texture import Texture


from jinja2 import Environment, StrictUndefined

from .examples import CubeMap
from .mesh import _dumps_scene, _has_plain_points, _scene_source


def scene_to_json(data: object) -> str:
    """Serialize scene or update data, as built by pyvista-js, to JSON.

    Float arrays are written with the fewest digits that give back the same
    float32 values, which is what vtk.js stores.

    Parameters
    ----------
    data : object
        The data, such as the output of ``build_update_data``.

    Returns
    -------
    str
        The JSON text.

    """
    return _dumps_scene(data)


# Load JavaScript templates
_TEMPLATES_DIR = pathlib.Path(__file__).parent / "templates"
_RENDERING_TEMPLATE = (_TEMPLATES_DIR / "standalone.html").read_text()
_RENDERER_JS = (_TEMPLATES_DIR / "renderer.js").read_text()

_jinja_env = Environment(undefined=StrictUndefined, autoescape=False)  # noqa: S701


# vtk.js CDN URL used across renderers
_VTKJS_CDN = "https://unpkg.com/vtk.js@29.5.0"

# Check if running in Pyodide environment
PYODIDE_ENV = sys.platform == "emscripten"

if PYODIDE_ENV:
    try:
        from js import document  # type: ignore[import-not-found]

        VTK_AVAILABLE = True
    except ImportError:
        VTK_AVAILABLE = False
        document = None  # type: ignore[assignment]
else:
    VTK_AVAILABLE = False
    document = None  # type: ignore[assignment]

# Check if running in IPython (Jupyter, JupyterLite, the IPython shell)
try:
    from IPython import get_ipython
    from IPython.display import HTML, Javascript, display

    # installed is not enough: a plain script still needs the browser renderer
    IPYTHON_AVAILABLE = get_ipython() is not None
except ImportError:
    IPYTHON_AVAILABLE = False
    HTML = None  # type: ignore[assignment]
    Javascript = None  # type: ignore[assignment]
    display = None  # type: ignore[assignment]


class _VTKJSLoader:
    """Singleton class to manage vtk.js library loading."""

    _instance: _VTKJSLoader | None = None
    _loaded: bool = False

    def __new__(cls) -> Self:
        """Ensure singleton instance."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance  # type: ignore[return-value]

    def load(self) -> None:
        """Load vtk.js library in IPython/Jupyter/Pyodide environment.

        This function automatically loads the vtk.js library from unpkg CDN
        when working in Jupyter notebooks or JupyterLite. It only loads the
        library once per session and waits for it to be available.
        """
        if self._loaded:
            return

        if IPYTHON_AVAILABLE:
            try:
                display(
                    HTML(f"""
<script src="{_VTKJS_CDN}"></script>
"""),
                )
                # Wait for vtk.js to load from CDN
                time.sleep(2)
                self._loaded = True
            except (NameError, TypeError):
                # display/HTML not available (e.g., in tests)
                pass
        elif PYODIDE_ENV and document is not None:
            # In pure Pyodide environment without IPython
            script = document.createElement("script")
            script.src = _VTKJS_CDN
            document.head.appendChild(script)
            # Wait for vtk.js to load from CDN
            time.sleep(2)
            self._loaded = True


logger = logging.getLogger(__name__)


def _color_name_to_rgb(color_name: str) -> tuple[float, float, float]:
    """Convert color name to RGB tuple.

    Parameters
    ----------
    color_name : str
        Color name (e.g., 'red', 'blue').

    Returns
    -------
    tuple of float
        RGB values (0-1). Returns gray (0.5, 0.5, 0.5) for unknown colors.

    """
    colors = {
        "red": (1.0, 0.0, 0.0),
        "green": (0.0, 1.0, 0.0),
        "blue": (0.0, 0.0, 1.0),
        "yellow": (1.0, 1.0, 0.0),
        "cyan": (0.0, 1.0, 1.0),
        "magenta": (1.0, 0.0, 1.0),
        "white": (1.0, 1.0, 1.0),
        "black": (0.0, 0.0, 0.0),
    }
    return colors.get(color_name.lower(), (0.5, 0.5, 0.5))


def _validate_update(
    mesh: object,
    points: np.ndarray | None,
    arrays: dict[str, np.ndarray],
    scalars: str | None,
) -> None:
    """Check that an actor update fits its mesh, raising ``ValueError`` if not."""
    if points is not None and (
        not _has_plain_points(mesh) or points.shape != mesh.points.shape  # type: ignore[attr-defined]
    ):
        msg = f"points must replace the {mesh.points.shape} points of a plain mesh"  # type: ignore[attr-defined]
        raise ValueError(msg)
    for name, array in arrays.items():
        if array.ndim not in (1, 2) or 0 in array.shape[1:]:
            msg = f"point_data[{name!r}] must be (n_points,) or (n_points, k>0), got {array.shape}"
            raise ValueError(msg)
        if len(array) != mesh.n_points:  # type: ignore[attr-defined]
            msg = f"point_data[{name!r}] has {len(array)} rows, expected {mesh.n_points}"  # type: ignore[attr-defined]
            raise ValueError(msg)
    if scalars is not None and scalars not in arrays and scalars not in mesh.point_data:  # type: ignore[attr-defined]
        msg = f"scalars {scalars!r} is not a point-data array of the mesh"
        raise ValueError(msg)


def _set_actor_properties(
    actor_info: dict[str, object],
    update: dict[str, object],
    color: str | tuple[float, float, float] | None,
    opacity: float | None,
) -> None:
    """Set the actor's solid color and opacity, if given, and add them to the update."""
    if color is not None:
        rgb = _color_name_to_rgb(color) if isinstance(color, str) else color
        actor_info["color"] = rgb
        update["color"] = [float(c) for c in rgb]
    if opacity is not None:
        actor_info["opacity"] = update["opacity"] = float(opacity)


class _BaseHTMLRenderer:
    """Base class providing shared state and HTML generation for vtk.js renderers.

    Subclasses implement :meth:`render` to display the generated HTML in their
    respective environments (Jupyter notebook, standalone browser, etc.).
    """

    def __init__(self, lighting: str | None = "default") -> None:
        """Initialize shared renderer state.

        Parameters
        ----------
        lighting : str or None, optional
            Lighting mode. ``"default"`` creates a default directional light,
            ``None`` creates no default lights. Default is ``"default"``.

        """
        self.actors: list[dict[str, object]] = []
        self.lights: list[Light] = []
        self.lighting: str | None = lighting
        self.text_actors: list[Text] = []
        self.background: tuple[float, float, float] = (1.0, 1.0, 1.0)
        self.container_id: str = "pyvista-container"
        self._environment_texture_url: str | None = None
        self._environment_texture_cubemap: CubeMap | None = None
        self._view_vector: tuple[float, float, float] | None = None
        self._view_up: tuple[float, float, float] = (0.0, 1.0, 0.0)
        self._camera: Camera | None = None
        self._axes_enabled: bool = False
        self._scalar_bar: dict[str, object] | None = None

    def create_container(self, element_id: str = "pyvista-container") -> object | None:
        """Store the container ID for later HTML generation.

        Parameters
        ----------
        element_id : str, default="pyvista-container"
            HTML element ID for the container.

        Returns
        -------
        object or None
            Subclasses may return a DOM element or None.

        """
        self.container_id = element_id
        return None

    def add_mesh_actor(  # noqa: PLR0913
        self,
        mesh: PolyData | UnstructuredGrid,
        color: str | tuple[float, float, float] | None = None,
        opacity: float = 1.0,
        pbr: bool = False,  # noqa: FBT001 FBT002
        metallic: float = 0.0,
        roughness: float = 0.5,
        smooth_shading: bool = True,  # noqa: FBT001 FBT002
        texture: Texture | None = None,
        show_edges: bool = False,  # noqa: FBT001 FBT002
        edge_color: str | tuple[float, float, float] | None = None,
        style: str = "surface",
        scalars: str | None = None,
        cmap: str = "viridis",
    ) -> dict[str, object]:
        """Add a mesh to the renderer.

        Parameters
        ----------
        mesh : PolyData
            The mesh object to render.
        color : tuple or str, optional
            RGB color tuple (0-1) or color name ('red', 'blue', etc.).
        opacity : float, default=1.0
            Opacity value between 0 and 1.
        pbr : bool, default=False
            Enable physically based rendering.
        metallic : float, default=0.0
            Metallic factor for PBR.
        roughness : float, default=0.5
            Roughness factor for PBR.
        smooth_shading : bool, default=True
            Enable smooth shading (Gouraud interpolation). When True, normals
            are interpolated across polygons for a smooth appearance. When
            False, flat shading is used.
        texture : Texture, optional
            Surface texture to apply. The texture image is loaded from the
            URL stored in the :class:`~pyvista_js.Texture` object.
        show_edges : bool, default=False
            Show the edges of the mesh.
        edge_color : tuple or str, optional
            RGB color tuple (0-1) or color name for edges when ``show_edges=True``.
            If not specified, defaults to black.
        style : str, default='surface'
            Visualization style. One of 'surface', 'wireframe', or 'points'.
        scalars : str, optional
            Name of the scalar array to use for coloring. The array must exist
            in ``mesh.point_data``.
        cmap : str, default='viridis'
            Name of the colormap to use when rendering scalars.

        Returns
        -------
        dict
            Actor information dictionary.

        Examples
        --------
        Compare smooth shading (left) and flat shading (right) side by side:

        >>> from pyvista_js import Sphere
        >>> from pyvista_js.rendering import get_renderer
        >>> renderer = get_renderer()
        >>> color = (0.8, 0.6, 0.2)
        >>> smooth = Sphere(center=(-1.5, 0, 0), theta_resolution=8, phi_resolution=8)
        >>> _ = renderer.add_mesh_actor(smooth, color=color, smooth_shading=True)
        >>> flat = Sphere(center=(1.5, 0, 0), theta_resolution=8, phi_resolution=8)
        >>> _ = renderer.add_mesh_actor(flat, color=color, smooth_shading=False)
        >>> renderer.render()  # doctest: +SKIP

        """
        if isinstance(color, str):
            color = _color_name_to_rgb(color)

        # Convert edge_color if it's a string
        if isinstance(edge_color, str):
            edge_color = _color_name_to_rgb(edge_color)

        actor_info: dict[str, object] = {
            "mesh": mesh,
            "color": color,
            "opacity": opacity,
            "pbr": pbr,
            "metallic": metallic,
            "roughness": roughness,
            "smooth_shading": smooth_shading,
            "texture": texture,
            "show_edges": show_edges,
            "edge_color": edge_color,
            "style": style,
            "scalars": scalars,
            "cmap": cmap,
        }
        self.actors.append(actor_info)
        return actor_info

    def add_points_actor(
        self,
        points: object,
        color: str | tuple[float, float, float] | None = None,
        opacity: float = 1.0,
        point_size: float = 5.0,
        render_points_as_spheres: bool = False,  # noqa: FBT001 FBT002
    ) -> dict[str, object]:
        """Add a point cloud to the renderer.

        Parameters
        ----------
        points : array-like or PolyData
            Point coordinates as an (n, 3) array or PolyData object.
        color : tuple or str, optional
            RGB color tuple (0-1) or color name ('red', 'blue', etc.).
        opacity : float, default=1.0
            Opacity value between 0 and 1.
        point_size : float, default=5.0
            Size of points in pixels.
        render_points_as_spheres : bool, default=False
            Render points as spheres instead of screen-space squares.

        Returns
        -------
        dict
            Actor information dictionary.

        """
        import numpy as np  # noqa: PLC0415

        from .mesh import PolyData  # noqa: PLC0415

        if isinstance(color, str):
            color = _color_name_to_rgb(color)

        # Convert to PolyData if needed
        if not isinstance(points, PolyData):
            points_array = np.asarray(points)
            if points_array.ndim != 2 or points_array.shape[1] != 3:  # noqa: PLR2004
                msg = f"Points must be an (n, 3) array, got shape {points_array.shape}"
                raise ValueError(msg)
            points = PolyData(points_array)

        actor_info: dict[str, object] = {
            "type": "points",
            "mesh": points,
            "color": color,
            "opacity": opacity,
            "point_size": point_size,
            "render_points_as_spheres": render_points_as_spheres,
        }
        self.actors.append(actor_info)
        return actor_info

    def add_light(self, light: Light) -> None:
        """Add a light source to the scene.

        Parameters
        ----------
        light : Light
            The :class:`~pyvista_js.light.Light` instance to add.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> from pyvista_js.rendering import get_renderer
        >>> renderer = get_renderer()
        >>> renderer.add_light(pv.Light(position=(1, 1, 1), intensity=2.0))

        """
        self.lights.append(light)

    def add_text_actor(self, text: Text) -> None:
        """Add a text actor to the scene.

        Parameters
        ----------
        text : Text
            The :class:`~pyvista_js.text.Text` instance to add.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> from pyvista_js.rendering import get_renderer
        >>> renderer = get_renderer()
        >>> renderer.add_text_actor(pv.Text("Hello", position=(0.5, 0.9)))

        """
        self.text_actors.append(text)

    def add_axes(self, **kwargs: object) -> None:  # noqa: ARG002
        """Add an orientation marker (axes indicator) to the viewport.

        Displays XYZ axes in the corner of the viewport to help orient
        the viewer. Backed by vtk.js ``vtkOrientationMarkerWidget``.

        Parameters
        ----------
        **kwargs
            Reserved for future implementation. Currently accepts no parameters.

        """
        self._axes_enabled = True

    def add_scalar_bar(
        self,
        title: str = "",
        vertical: bool = True,  # noqa: FBT001, FBT002
        n_labels: int = 5,
    ) -> None:
        """Add a scalar bar to the scene.

        The scalar bar displays a color legend mapping scalar values to
        colors using ``vtkScalarBarActor``.

        Parameters
        ----------
        title : str, optional
            Title text displayed on the scalar bar. Default is ``""``.
        vertical : bool, optional
            Whether to orient the scalar bar vertically (``True``) or
            horizontally (``False``). Default is ``True``.
        n_labels : int, optional
            Number of labels to display on the scalar bar. Default is ``5``.

        Examples
        --------
        >>> from pyvista_js.rendering import get_renderer
        >>> renderer = get_renderer()
        >>> renderer.add_scalar_bar(title="Height", vertical=True, n_labels=5)

        """
        self._scalar_bar = {
            "title": title,
            "vertical": vertical,
            "n_labels": n_labels,
        }

    def set_environment_texture(self, texture: str | CubeMap) -> None:
        """Set the environment texture for image-based lighting.

        Parameters
        ----------
        texture : str or CubeMap
            Either a URL string pointing to an equirectangular image, or a
            :class:`~pyvista_js.examples.CubeMap` with six face image URLs.

        """
        if isinstance(texture, CubeMap):
            self._environment_texture_cubemap = texture
            self._environment_texture_url = None
        else:
            self._environment_texture_url = texture
            self._environment_texture_cubemap = None

    def set_background(self, color: tuple[float, float, float]) -> None:
        """Set the background color of the renderer.

        Parameters
        ----------
        color : tuple
            RGB color tuple with values between 0 and 1.

        """
        self.background = color

    def view_vector(
        self,
        vector: tuple[float, float, float],
        viewup: tuple[float, float, float] | None = None,
    ) -> None:
        """Point the camera in the direction of the given vector.

        Parameters
        ----------
        vector : tuple of float
            Direction vector (vx, vy, vz) to point the camera.
        viewup : tuple of float, optional
            View-up vector. Defaults to (0, 1, 0).

        """
        self._view_vector = (float(vector[0]), float(vector[1]), float(vector[2]))
        if viewup is not None:
            self._view_up = (float(viewup[0]), float(viewup[1]), float(viewup[2]))

    @property
    def camera(self) -> Camera | None:
        """Get or set the camera for the renderer.

        Parameters
        ----------
        camera : Camera
            The camera object to use for rendering.

        Returns
        -------
        Camera or None
            The current camera, or None if not set.

        """
        return self._camera

    @camera.setter
    def camera(self, camera: Camera) -> None:
        """Set the camera."""
        self._camera = camera

    def clear(self) -> None:
        """Remove all actors, lights, and text actors from the renderer."""
        self.actors = []
        self.lights = []
        self._scalar_bar = None
        self.text_actors = []

    def _build_lights_data(self) -> list[dict[str, object]]:
        """Build JSON-serializable light configurations."""
        if not self.lights:
            if self.lighting is None:
                return []
            return [
                {
                    "type": "scene",
                    "positional": False,
                    "intensity": 1.0,
                    "position": [1, 1, 1],
                    "focalPoint": [0, 0, 0],
                    "color": [1, 1, 1],
                    "coneAngle": 30,
                    "coneFalloff": 0,
                    "attenuationValues": [1, 0, 0],
                },
            ]
        lights_data: list[dict[str, object]] = []
        for light in self.lights:
            light_type = light.light_type.lower().replace("light", "")
            lights_data.append(
                {
                    "type": light_type,
                    "positional": light.positional,
                    "intensity": light.intensity,
                    "position": list(light.position),
                    "focalPoint": list(light.focal_point),
                    "color": list(light.color),
                    "coneAngle": light.cone_angle,
                    "coneFalloff": light.cone_falloff,
                    "attenuationValues": list(light.attenuation_values),
                },
            )
        return lights_data

    @staticmethod
    def _build_scalars_data(actor_info: dict[str, object]) -> dict[str, object] | None:
        """Build the scalar-coloring configuration of an actor, if it has one."""
        scalars_name = actor_info.get("scalars")
        if scalars_name is None:
            return None
        scalars_array = actor_info["mesh"].point_data[str(scalars_name)]  # type: ignore[attr-defined]
        # a uint8 RGB(A) array is used as the colors directly, with no colormap
        rgb_components = (3, 4)
        direct = (
            scalars_array.dtype == "uint8"
            and scalars_array.ndim == 2  # noqa: PLR2004
            and scalars_array.shape[1] in rgb_components
        )
        return {
            "arrayName": scalars_name,
            "cmap": actor_info.get("cmap", "viridis"),
            "range": [float(scalars_array.min()), float(scalars_array.max())],
            "direct": direct,
        }

    @staticmethod
    def _actor_id(actor_info: dict[str, object]) -> str:
        """Return the actor's ID, which pages use to find it for updates.

        Unlike the actor's index, it is not reused after :meth:`clear`, so an
        update never reaches an unrelated actor in an earlier output.
        """
        return str(actor_info.setdefault("id", secrets.token_hex(8)))

    def build_update_data(  # noqa: PLR0913
        self,
        actor_index: int,
        *,
        points: ArrayLike | None = None,
        point_data: Mapping[str, ArrayLike] | None = None,
        scalars: str | None = None,
        color: str | tuple[float, float, float] | None = None,
        opacity: float | None = None,
        add: bool = False,
        remove: bool = False,
    ) -> dict[str, object]:
        """Update an actor and build the message that applies it in the page.

        The actor is updated too, so HTML generated afterwards shows the
        change. Apply the message in a rendered page with
        ``window.pvjsApplyUpdate(containerId, message)``, after serializing it
        with :func:`scene_to_json`. Updates reach the rendered mesh through
        smooth-shading normals, but not through filters such as ``clip``.

        Parameters
        ----------
        actor_index : int
            Index of the actor in :attr:`actors`, in the order it was added.
        points : array-like, optional
            New ``(n_points, 3)`` coordinates. The number of points cannot change.
        point_data : mapping, optional
            Point-data arrays to add or replace, by name.
        scalars : str, optional
            Name of the point-data array to color by. Without it, the coloring
            is re-sent only when its array is in ``point_data``.
        color : str or tuple, optional
            New solid color, as an RGB tuple (0-1) or a color name.
        opacity : float, optional
            New opacity, between 0 and 1.
        add : bool, default=False
            Send the whole actor, to add it to a page that does not have it
            yet, such as one rendered before the actor was added.
        remove : bool, default=False
            Remove the actor, here and from the page.

        Returns
        -------
        dict
            The update message, with the ``"actor"`` ID and whichever of ``"points"``,
            ``"pointData"``, ``"scalars"``, ``"color"``, ``"opacity"``, ``"add"``
            and ``"remove"`` changed.

        Raises
        ------
        IndexError
            If there is no actor ``actor_index``.
        TypeError
            If an array has complex values. Nothing is changed when this is raised.
        ValueError
            If an array does not have one row per point or has NaN or
            infinite values, ``points`` is given for a mesh that is not
            defined by its points, ``scalars`` names no point-data array, or
            ``add`` or ``remove`` is combined with any other change.
            Nothing is changed when this is raised.

        """
        # normalize the index, as the page looks actors up by a non-negative one
        actor_index = range(len(self.actors))[actor_index]
        if add or remove:
            changes = (points, point_data, scalars, color, opacity)
            return self._build_add_or_remove_data(actor_index, changes, add=add, remove=remove)
        return self._build_change_data(
            actor_index,
            points=points,
            point_data=point_data,
            scalars=scalars,
            color=color,
            opacity=opacity,
        )

    def _build_change_data(  # noqa: PLR0913
        self,
        actor_index: int,
        *,
        points: ArrayLike | None,
        point_data: Mapping[str, ArrayLike] | None,
        scalars: str | None,
        color: str | tuple[float, float, float] | None,
        opacity: float | None,
    ) -> dict[str, object]:
        """Build the message that changes an actor's data or properties, changing it here too."""
        import numpy as np  # noqa: PLC0415

        from .mesh import _Float32Array, _point_data_to_scene  # noqa: PLC0415

        actor_info = self.actors[actor_index]
        mesh = actor_info["mesh"]
        if points is not None:
            # built first, as it rejects complex values that the cast would mangle
            sent_points = _Float32Array(points)
            points = np.asarray(points, dtype=float)
        arrays = {name: np.asarray(array) for name, array in (point_data or {}).items()}
        # validate the whole request, and build what is sent, before changing anything
        _validate_update(mesh, points, arrays, scalars)
        update: dict[str, object] = {"actor": self._actor_id(actor_info)}
        if points is not None:
            update["points"] = sent_points
        if arrays:
            update["pointData"] = _point_data_to_scene(arrays)
        sent = [update.get("points"), *(a["values"] for a in update.get("pointData", []))]  # type: ignore[attr-defined]
        for values in sent:
            if isinstance(values, _Float32Array):
                values.finite()

        if points is not None:
            mesh.points = points  # type: ignore[attr-defined]
        for name, array in arrays.items():
            mesh.point_data[name] = array  # type: ignore[attr-defined]
        if scalars is not None:
            actor_info["scalars"] = scalars
        if scalars is not None or actor_info.get("scalars") in arrays:
            update["scalars"] = self._build_scalars_data(actor_info)
        _set_actor_properties(actor_info, update, color, opacity)
        return update

    def _build_add_or_remove_data(
        self,
        actor_index: int,
        changes: tuple[object, ...],
        *,
        add: bool,
        remove: bool,
    ) -> dict[str, object]:
        """Build the message that adds or removes an actor, removing it here too."""
        if (add and remove) or any(change is not None for change in changes):
            msg = "add and remove cannot be combined with each other or with other changes"
            raise ValueError(msg)
        actor_info = self.actors[actor_index]
        actor_id = self._actor_id(actor_info)
        if add:
            return {"actor": actor_id, "add": self._build_actor_data(actor_info)}
        del self.actors[actor_index]
        return {"actor": actor_id, "remove": True}

    def build_camera_update_data(self) -> dict[str, object]:
        """Build the message that sets the camera of a rendered page.

        The camera is the one set by :meth:`view_vector` or :attr:`camera`, set
        as a new page would set it, so ``view_vector`` frames the scene again.
        Apply it as the messages of :meth:`build_update_data` are applied.

        Returns
        -------
        dict
            The update message, with the ``"camera"`` if one is set.

        """
        camera = self._build_camera_data()
        return {} if camera is None else {"camera": camera}

    def _build_actor_data(self, actor_info: dict[str, object]) -> dict[str, object]:
        """Build JSON-serializable actor configuration."""
        mesh = actor_info["mesh"]
        color: tuple[float, ...] = actor_info.get("color") or (0.5, 0.5, 0.5)  # type: ignore[assignment]
        opacity = float(actor_info.get("opacity", 1.0))  # type: ignore[arg-type]
        smooth_shading = bool(actor_info.get("smooth_shading", True))
        style = str(actor_info.get("style", "surface"))

        source_data = _scene_source(mesh)

        # Normals configuration
        normals_data = None
        if smooth_shading or source_data.get("type") == "sphere":
            normals_data = {
                "computePointNormals": bool(smooth_shading),
                "computeCellNormals": not bool(smooth_shading),
            }

        # Texture
        texture_data = None
        texture: object = actor_info.get("texture")
        if texture is not None:
            texture_data = {"url": getattr(texture, "url", "")}

        scalars_data = self._build_scalars_data(actor_info)

        # PBR
        pbr_data = None
        if actor_info.get("pbr"):
            pbr_data = {
                "metallic": actor_info.get("metallic", 0.0),
                "roughness": actor_info.get("roughness", 0.5),
            }

        # Edge
        edge_data = None
        if actor_info.get("show_edges"):
            edge_color = actor_info.get("edge_color")
            if isinstance(edge_color, str):
                from pyvista_js.light import _color_name_to_rgb  # noqa: PLC0415

                edge_color = list(_color_name_to_rgb(edge_color))
            elif edge_color is not None:
                edge_color = list(edge_color)  # type: ignore[call-overload]
            else:
                edge_color = [0, 0, 0]
            edge_data = {"color": edge_color}

        actor_type = actor_info.get("type", "mesh")

        result: dict[str, object] = {
            "id": self._actor_id(actor_info),
            "source": source_data,
            "normals": normals_data,
            "mapper": {"class": "vtkMapper"},
            "color": list(color),
            "opacity": float(opacity),
            "style": style,
            "shading": "gouraud" if smooth_shading else "flat",
            "edges": edge_data,
            "pbr": pbr_data,
            "texture": texture_data,
            "scalars": scalars_data,
            "actorType": actor_type,
        }

        if actor_type == "points":
            point_size = float(actor_info.get("point_size", 5.0))  # type: ignore[arg-type]
            as_spheres = bool(
                actor_info.get("render_points_as_spheres", False),
            )
            result["pointSize"] = point_size
            result["renderPointsAsSpheres"] = as_spheres
            if as_spheres:
                result["mapper"] = {"class": "vtkSphereMapper"}
            else:
                result["mapper"] = {"class": "vtkMapper"}

        return result

    def _build_camera_data(self) -> dict[str, object] | None:
        """Build JSON-serializable camera configuration."""
        if self._camera is not None:
            cam = self._camera
            data: dict[str, object] = {
                "position": list(cam.position),
                "focalPoint": list(cam.focal_point),
                "viewUp": list(cam.view_up),
            }
            if cam.view_angle is not None:
                data["viewAngle"] = cam.view_angle
            if cam.clipping_range is not None:
                data["clippingRange"] = list(cam.clipping_range)
            if cam.parallel_projection:
                data["parallelProjection"] = True
            data["parallelScale"] = cam.parallel_scale
            return data
        if self._view_vector is not None:
            return {
                "viewVector": list(self._view_vector),
                "viewUp": list(self._view_up),
            }
        return None

    def _build_text_actors_data(self) -> list[dict[str, object]]:
        """Build JSON-serializable text actor configurations."""
        return [
            {
                "text": ta.input,
                "position": list(ta.position),
                "fontSize": ta.prop.font_size,
                "color": list(ta.prop.color),
                "opacity": ta.prop.opacity,
                "bold": ta.prop.bold,
                "italic": ta.prop.italic,
            }
            for ta in self.text_actors
        ]

    def _build_scene_data(self) -> dict[str, object]:
        """Build a complete scene description.

        Returns
        -------
        dict
            Scene configuration including container, background, lights,
            actors, camera, etc. Serialize it with ``_dumps_scene``, which
            handles the ``_Float32Array`` values in it.

        """
        actors_data = [self._build_actor_data(info) for info in self.actors]

        text_actors_data = self._build_text_actors_data()

        scene: dict[str, object] = {
            "containerId": self.container_id,
            "background": list(self.background),
            "lights": self._build_lights_data(),
            "actors": actors_data,
            "textActors": text_actors_data,
            "axes": self._axes_enabled,
            "camera": self._build_camera_data(),
            "lightingMode": self.lighting,
        }

        return scene

    def _generate_html(self) -> str:
        """Generate HTML fragment with embedded vtk.js JavaScript."""
        scene_json = _dumps_scene(self._build_scene_data())

        return _jinja_env.from_string(_RENDERING_TEMPLATE).render(
            VTKJS_CDN=_VTKJS_CDN,
            CONTAINER_ID=self.container_id,
            SCENE_JSON=scene_json,
            RENDERER_JS=_RENDERER_JS,
        )

    def generate_standalone_html(self) -> str:
        """Generate a complete standalone HTML page with vtk.js.

        Wraps the HTML fragment from _generate_html() in a full HTML document.
        """
        fragment = self._generate_html()
        return (
            "<!DOCTYPE html>\n"
            "<html>\n"
            "<head><meta charset='utf-8'></head>\n"
            "<body>\n" + fragment + "\n</body>\n"
            "</html>\n"
        )

    def _generate_update_js(self, update: dict[str, object]) -> str:
        """Generate JavaScript that applies an update message to the rendered scene."""
        import json as _json  # noqa: PLC0415

        return (
            f"window.pvjsApplyUpdate({_json.dumps(self.container_id)}, {scene_to_json(update)});\n"
        )

    def _generate_render_js(self) -> str:
        """Generate pure JavaScript for display(Javascript(...)) in JupyterLite.

        Embeds scene data as a JS variable and creates the container and
        scene-data elements inside the cell output area. Each invocation
        uses a unique scene-data ID to avoid collisions between cells.
        """
        import json as _json  # noqa: PLC0415

        scene_json = _dumps_scene(self._build_scene_data())

        # For JupyterLite: pass scene data and container via JS variables
        # so renderer.js can use them directly without DOM lookups.
        return (
            "(function() {\n"
            "  var container = document.createElement('div');\n"
            f"  container.id = {_json.dumps(self.container_id)};\n"
            "  container.style.cssText = "
            "'width:600px;height:400px;border:2px solid #333;position:relative';\n"
            "  var parent = (typeof element !== 'undefined' && element)"
            " ? element : document.body;\n"
            "  parent.appendChild(container);\n"
            f"  var __pvjsSceneData = {scene_json};\n"
            "  var __pvjsContainer = container;\n"
            "  function doRender() {\n"
            f"    {_RENDERER_JS}\n"
            "  }\n"
            "  if (typeof vtk !== 'undefined') {\n"
            "    doRender();\n"
            "  } else {\n"
            "    var script = document.createElement('script');\n"
            f"    script.src = {_json.dumps(_VTKJS_CDN)};\n"
            "    script.onload = doRender;\n"
            "    document.head.appendChild(script);\n"
            "  }\n"
            "})();\n"
        )

    def _repr_html_(self) -> str:
        """IPython representation as HTML for Jupyter notebooks."""
        return self._generate_html()

    @staticmethod
    def _color_name_to_rgb(color_name: str) -> tuple[float, float, float]:
        """Convert color name to RGB tuple.

        Parameters
        ----------
        color_name : str
            Color name (e.g., 'red', 'blue').

        Returns
        -------
        tuple of float
            RGB values (0-1). Returns gray (0.5, 0.5, 0.5) for unknown colors.

        """
        colors = {
            "red": (1.0, 0.0, 0.0),
            "green": (0.0, 1.0, 0.0),
            "blue": (0.0, 0.0, 1.0),
            "yellow": (1.0, 1.0, 0.0),
            "cyan": (0.0, 1.0, 1.0),
            "magenta": (1.0, 0.0, 1.0),
            "white": (1.0, 1.0, 1.0),
            "black": (0.0, 0.0, 0.0),
        }
        return colors.get(color_name.lower(), (0.5, 0.5, 0.5))

    def screenshot(
        self,
        filename: str | Path | None = None,
        transparent_background: bool | None = None,  # noqa: FBT001
        return_img: bool = True,  # noqa: FBT001, FBT002
        window_size: tuple[int, int] | list[int] | None = None,
        scale: int | None = None,
    ) -> np.ndarray | None:
        """Take a screenshot of the rendered scene.

        This is a base implementation that raises NotImplementedError.
        Subclasses should override this method to provide actual screenshot functionality.

        Parameters
        ----------
        filename : str, Path, or None, optional
            File path to save the image.
        transparent_background : bool or None, optional
            Whether to make the background transparent.
        return_img : bool, optional
            If True, return a numpy array of the image.
        window_size : tuple or list of int, optional
            Temporarily resize the window to (width, height).
        scale : int or None, optional
            Scale factor for higher resolution.

        Returns
        -------
        numpy.ndarray or None
            Image data as numpy array if return_img is True, otherwise None.

        Raises
        ------
        NotImplementedError
            This base implementation always raises NotImplementedError.

        """
        msg = "screenshot() must be implemented by renderer subclass"
        raise NotImplementedError(msg)


class VTKJSRenderer(_BaseHTMLRenderer):
    """Renderer using vtk.js for browser visualization.

    This class wraps vtk.js rendering components and provides
    a bridge between Python mesh data and JavaScript WebGL rendering.

    Notes
    -----
    This renderer can only be instantiated in a Pyodide environment
    with vtk.js loaded in the page. Use `get_renderer()` to automatically
    get the appropriate renderer for the current environment.

    The renderer creates standard vtk.js objects:
    - vtkRenderer: Scene renderer
    - vtkRenderWindow: Rendering window
    - vtkRenderWindowInteractor: User interaction handler

    Examples
    --------
    >>> # In Pyodide/browser environment
    >>> renderer = VTKJSRenderer()  # doctest: +SKIP
    >>> renderer.create_container('my-viz')  # doctest: +SKIP
    >>> # Add a mesh
    >>> from pyvista_js import Sphere  # doctest: +SKIP
    >>> mesh = Sphere()  # doctest: +SKIP
    >>> actor = renderer.add_mesh_actor(mesh, color='blue')  # doctest: +SKIP
    >>> # Render the scene
    >>> renderer.render()  # doctest: +SKIP

    """

    def __init__(self, lighting: str | None = "default") -> None:
        """Initialize the vtk.js renderer.

        Automatically loads vtk.js library if in IPython/Jupyter environment.

        Parameters
        ----------
        lighting : str or None, optional
            Lighting mode. ``"default"`` creates a default directional light,
            ``None`` creates no default lights. Default is ``"default"``.

        Raises
        ------
        RuntimeError
            If not running in Pyodide environment.
        ImportError
            If vtk.js is not available in the page.

        """
        if not PYODIDE_ENV and not IPYTHON_AVAILABLE:
            msg = "VTKJSRenderer requires either Pyodide environment or IPython"
            raise RuntimeError(msg)

        super().__init__(lighting=lighting)

        # Automatically load vtk.js in IPython/Jupyter (including Pyodide)
        if IPYTHON_AVAILABLE or PYODIDE_ENV:
            _VTKJSLoader().load()

        self.container = None
        self.use_ipython = IPYTHON_AVAILABLE

    def create_container(self, element_id: str = "pyvista-container") -> object | None:
        """Create a DOM container for rendering.

        Creates a <div> element in the document and configures it for
        vtk.js rendering with mouse/touch interaction support.

        Parameters
        ----------
        element_id : str, default="pyvista-container"
            HTML element ID for the container.

        Returns
        -------
        container
            The created DOM element (if using direct DOM) or None (if using IPython).

        Examples
        --------
        >>> renderer = VTKJSRenderer()  # doctest: +SKIP
        >>> container = renderer.create_container('my-visualization')  # doctest: +SKIP

        """
        if self.use_ipython:
            super().create_container(element_id)
            return None
        # Create container div directly
        self.container = document.createElement("div")  # type: ignore[attr-defined]
        self.container.setAttribute("id", element_id)  # type: ignore[attr-defined]
        self.container.style.width = "100%"  # type: ignore[attr-defined]
        self.container.style.height = "600px"  # type: ignore[attr-defined]

        # Append to body
        document.body.appendChild(self.container)  # type: ignore[union-attr]

        return self.container

    def render(self) -> None:
        """Render the scene.

        Resets the camera to show all actors and triggers rendering.
        In IPython/Jupyter, generates and displays HTML with vtk.js code.

        Examples
        --------
        >>> renderer.render()  # Display the visualization  # doctest: +SKIP

        """
        if self.use_ipython:
            js_code = self._generate_render_js()
            display(Javascript(js_code))
        else:
            # Direct rendering
            self.renderer.resetCamera()  # type: ignore[attr-defined]
            self.render_window.render()  # type: ignore[attr-defined]

    def clear(self) -> None:
        """Remove all actors from the renderer.

        Examples
        --------
        >>> renderer.clear()  # Remove all visualizations  # doctest: +SKIP

        """
        super().clear()
        if not self.use_ipython and hasattr(self, "renderer"):
            self.renderer.removeAllActors()


def _launch_chromium(playwright: Playwright) -> Browser:
    """Launch headless Chromium, or an installed Google Chrome if Playwright has none.

    Parameters
    ----------
    playwright : playwright.sync_api.Playwright
        The running Playwright.

    Returns
    -------
    playwright.sync_api.Browser
        The browser.

    """
    from playwright.sync_api import Error  # noqa: PLC0415

    try:
        return playwright.chromium.launch(headless=True)
    except Error:  # no ``playwright install chromium``
        return playwright.chromium.launch(headless=True, channel="chrome")


def _playwright_capture(html_path: str, w: int, h: int, omit_bg: bool) -> bytes:  # noqa: FBT001
    """Capture a screenshot of an HTML file using Playwright in a thread.

    Parameters
    ----------
    html_path : str
        Path to the HTML file to capture.
    w : int
        Viewport width in pixels.
    h : int
        Viewport height in pixels.
    omit_bg : bool
        Whether to omit the background (transparent PNG).

    Returns
    -------
    bytes
        PNG image data.

    """
    from playwright.sync_api import sync_playwright  # noqa: PLC0415

    with sync_playwright() as p:
        browser = _launch_chromium(p)
        pg = browser.new_page(viewport={"width": w, "height": h})
        pg.goto(f"file://{html_path}")
        pg.wait_for_timeout(2000)
        data = pg.screenshot(type="png", omit_background=omit_bg)
        browser.close()
    return data


class BrowserRenderer(_BaseHTMLRenderer):
    """Renderer that opens the visualization in the default web browser.

    Used automatically in standard Python environments (outside of
    Jupyter/Pyodide). Generates a standalone HTML file and opens it
    with :func:`webbrowser.open`.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> plotter = pv.Plotter()
    >>> _ = plotter.add_mesh(pv.Sphere(), color='red')
    >>> plotter.show()  # doctest: +SKIP

    """

    def render(self) -> None:
        """Write the visualization to a temp HTML file and open it in the browser."""
        html = self.generate_standalone_html()
        with tempfile.NamedTemporaryFile(
            suffix=".html",
            delete=False,
            mode="w",
            encoding="utf-8",
        ) as f:
            f.write(html)
            tmp_path = f.name

        url = pathlib.Path(tmp_path).as_uri()
        webbrowser.open(url)
        logger.info("Opened visualization in browser: %s", url)

    def generate_standalone_html(self) -> str:
        """Wrap the HTML fragment in a complete standalone HTML page."""
        fragment = self._generate_html()
        container_id = self.container_id
        container_rule = (
            f"    #{container_id} "
            "{ width: 100vw !important; height: 100vh !important; border: none !important; }\n"
        )
        style = (
            "  <style>\n"
            "    html, body { margin: 0; padding: 0; width: 100%; height: 100%;"
            " overflow: hidden; }\n" + container_rule + "  </style>\n"
        )
        return (
            "<!DOCTYPE html>\n"
            "<html>\n"
            "<head>\n"
            "  <meta charset='utf-8'>\n"
            "  <title>pyvista-js</title>\n"
            f"  <script src='{_VTKJS_CDN}'></script>\n" + style + "</head>\n"
            "<body>\n" + fragment + "</body>\n"
            "</html>\n"
        )

    def screenshot(
        self,
        filename: str | Path | None = None,
        transparent_background: bool | None = None,  # noqa: FBT001
        return_img: bool = True,  # noqa: FBT001, FBT002
        window_size: tuple[int, int] | list[int] | None = None,
        scale: int | None = None,
    ) -> np.ndarray | None:
        """Take a screenshot using Playwright browser automation.

        Parameters
        ----------
        filename : str, Path, or None, optional
            File path to save the image. If None, no file is written.
        transparent_background : bool or None, optional
            Whether to make the background transparent. If None, uses current setting.
        return_img : bool, optional
            If True, return a numpy array of the image.
        window_size : tuple or list of int, optional
            Window size as (width, height). Default is (600, 400).
        scale : int or None, optional
            Scale factor for higher resolution.

        Returns
        -------
        numpy.ndarray or None
            Image data as numpy array if return_img is True, otherwise None.

        """
        import numpy as np  # noqa: PLC0415

        # Set default window size
        width, height = (600, 400) if window_size is None else window_size
        if scale is not None:
            width *= scale
            height *= scale

        # Temporarily change background if transparent requested
        original_background = self.background
        if transparent_background:
            self.background = (0.0, 0.0, 0.0)  # Will be made transparent

        try:
            # Generate HTML
            html = self.generate_standalone_html()

            # Create temp HTML file
            with tempfile.NamedTemporaryFile(
                suffix=".html",
                delete=False,
                mode="w",
                encoding="utf-8",
            ) as f:
                f.write(html)
                tmp_html_path = f.name

            try:
                # Run Playwright in a thread to avoid conflicts when called
                # inside an existing asyncio event loop (e.g. pytest-playwright).
                import concurrent.futures  # noqa: PLC0415

                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                    future = executor.submit(
                        _playwright_capture,
                        tmp_html_path,
                        width,
                        height,
                        transparent_background or False,
                    )
                    screenshot_bytes = future.result()

                # Save to file if requested
                if filename is not None:
                    pathlib.Path(filename).write_bytes(screenshot_bytes)

                # Convert to numpy array if requested
                if return_img:
                    try:
                        from PIL import Image  # noqa: PLC0415
                    except ImportError as e:  # pragma: no cover
                        msg = (
                            "Pillow is required to return image as numpy array. "
                            "Install it with: pip install pillow"
                        )
                        raise ImportError(msg) from e

                    from io import BytesIO  # noqa: PLC0415

                    img = Image.open(BytesIO(screenshot_bytes))
                    if transparent_background:
                        img = img.convert("RGBA")
                    return np.array(img)
                return None

            finally:
                # Clean up temp file
                pathlib.Path(tmp_html_path).unlink()

        finally:
            # Restore original background
            if transparent_background:
                self.background = original_background


class MockRenderer:
    """Mock renderer for non-Pyodide environments.

    Provides a drop-in replacement for VTKJSRenderer that can be used
    in standard Python environments for development and testing.

    Why MockRenderer is Needed
    ---------------------------
    1. **Local Development**: Develop and test code on your PC without browser
    2. **CI/CD Testing**: Run pytest in GitHub Actions and other CI systems
    3. **Documentation**: Generate docs with sphinx-build without Pyodide
    4. **API Validation**: Verify API design before vtk.js integration
    5. **Cross-platform**: Same code works in Pyodide and standard Python

    The MockRenderer prints debug information instead of rendering,
    allowing you to verify that your visualization code is correct.

    Examples
    --------
    >>> # Works in standard Python
    >>> from pyvista_js.rendering import MockRenderer
    >>> from pyvista_js import Sphere
    >>>
    >>> renderer = MockRenderer()
    >>> mesh = Sphere()
    >>> _ = renderer.add_mesh_actor(mesh, color='red')
    >>>
    >>> renderer.render()  # doctest: +SKIP
    Mock: Rendering 1 actors

    Notes
    -----
    The mock renderer is automatically used when calling `get_renderer()`
    outside of a Pyodide environment. You typically don't need to instantiate
    it directly.

    """

    def __init__(self, lighting: str | None = "default") -> None:
        """Initialize mock renderer.

        Parameters
        ----------
        lighting : str or None, optional
            Lighting mode. ``"default"`` creates a default directional light,
            ``None`` creates no default lights. Default is ``"default"``.

        """
        self.actors: list[dict[str, object]] = []
        self.lights: list[Light] = []
        self.lighting: str | None = lighting
        self.text_actors: list[Text] = []
        self.background = (1.0, 1.0, 1.0)  # Default background color
        self._view_vector: tuple[float, float, float] | None = None
        self._view_up: tuple[float, float, float] = (0.0, 1.0, 0.0)
        self._camera: Camera | None = None
        self._scalar_bar: dict[str, object] | None = None

    def create_container(self, element_id: str = "pyvista-container") -> None:
        """Mock container creation.

        Parameters
        ----------
        element_id : str
            Container ID (for API compatibility).

        Returns
        -------
        None
            Mock renderers don't create actual containers.

        """
        logger.info("Created container '%s'", element_id)

    def add_mesh_actor(  # noqa: PLR0913
        self,
        mesh: PolyData | UnstructuredGrid,
        color: str | tuple[float, float, float] | None = None,
        opacity: float = 1.0,
        pbr: bool = False,  # noqa: FBT001 FBT002
        metallic: float = 0.0,
        roughness: float = 0.5,
        smooth_shading: bool = True,  # noqa: FBT001 FBT002
        texture: Texture | None = None,
        show_edges: bool = False,  # noqa: FBT001 FBT002
        edge_color: str | tuple[float, float, float] | None = None,
        style: str = "surface",
        scalars: str | None = None,
        cmap: str = "viridis",
    ) -> dict[str, object]:
        """Mock mesh addition.

        Parameters
        ----------
        mesh : PolyData
            The mesh to add.
        color : str or tuple, optional
            Color (stored but not rendered).
        opacity : float
            Opacity (stored but not rendered).
        pbr : bool
            PBR flag (stored but not rendered).
        metallic : float
            Metallic factor (stored but not rendered).
        roughness : float
            Roughness factor (stored but not rendered).
        smooth_shading : bool
            Smooth shading flag (stored but not rendered).
        texture : Texture, optional
            Surface texture (stored but not rendered).
        show_edges : bool
            Edge visibility (stored but not rendered).
        edge_color : str or tuple, optional
            Edge color (stored but not rendered).
        style : str
            Rendering style (stored but not rendered).
        scalars : str, optional
            Scalar array name (stored but not rendered).
        cmap : str
            Colormap name (stored but not rendered).

        Returns
        -------
        dict
            Mock actor dictionary with mesh data.

        """
        actor: dict[str, object] = {
            "mesh": mesh,
            "color": color,
            "opacity": opacity,
            "pbr": pbr,
            "metallic": metallic,
            "roughness": roughness,
            "smooth_shading": smooth_shading,
            "texture": texture,
            "show_edges": show_edges,
            "edge_color": edge_color,
            "style": style,
            "scalars": scalars,
            "cmap": cmap,
        }
        self.actors.append(actor)
        logger.info("Added mesh with %d points", mesh.n_points)
        return actor

    def add_points_actor(
        self,
        points: object,
        color: str | tuple[float, float, float] | None = None,
        opacity: float = 1.0,
        point_size: float = 5.0,
        render_points_as_spheres: bool = False,  # noqa: FBT001 FBT002
    ) -> dict[str, object]:
        """Mock point cloud addition.

        Parameters
        ----------
        points : array-like or PolyData
            Point coordinates (stored but not rendered).
        color : str or tuple, optional
            Color (stored but not rendered).
        opacity : float
            Opacity (stored but not rendered).
        point_size : float
            Point size (stored but not rendered).
        render_points_as_spheres : bool
            Sphere rendering flag (stored but not rendered).

        Returns
        -------
        dict
            Mock actor dictionary with point data.

        """
        import numpy as np  # noqa: PLC0415

        from .mesh import PolyData  # noqa: PLC0415

        if isinstance(color, str):
            color = _color_name_to_rgb(color)

        if not isinstance(points, PolyData):
            points_array = np.asarray(points)
            if points_array.ndim != 2 or points_array.shape[1] != 3:  # noqa: PLR2004
                msg = f"Points must be an (n, 3) array, got shape {points_array.shape}"
                raise ValueError(msg)
            points = PolyData(points_array)

        actor: dict[str, object] = {
            "type": "points",
            "mesh": points,
            "color": color,
            "opacity": opacity,
            "point_size": point_size,
            "render_points_as_spheres": render_points_as_spheres,
        }
        self.actors.append(actor)
        logger.info("Added point cloud with %d points", points.n_points)
        return actor

    def render(self) -> None:
        """Mock rendering.

        Logs the number of actors that would be rendered.
        """
        logger.info("Rendering %d actors", len(self.actors))

    def generate_standalone_html(self) -> str:
        """Return a minimal HTML string for mock rendering.

        Returns
        -------
        str
            A placeholder HTML document.

        """
        return (
            "<!DOCTYPE html>\n"
            "<html>\n"
            "<head><meta charset='utf-8'></head>\n"
            "<body><!-- mock renderer --></body>\n"
            "</html>\n"
        )

    def add_light(self, light: Light) -> None:
        """Mock add_light.

        Parameters
        ----------
        light : Light
            The light to add (stored but not rendered).

        """
        self.lights.append(light)
        logger.info("Added light type=%s intensity=%s", light.light_type, light.intensity)

    def add_scalar_bar(
        self,
        title: str = "",
        vertical: bool = True,  # noqa: FBT001, FBT002
        n_labels: int = 5,
    ) -> None:
        """Mock add_scalar_bar.

        Parameters
        ----------
        title : str, optional
            Title text for the scalar bar. Default is ``""``.
        vertical : bool, optional
            Whether to orient vertically. Default is ``True``.
        n_labels : int, optional
            Number of labels. Default is ``5``.

        """
        self._scalar_bar = {
            "title": title,
            "vertical": vertical,
            "n_labels": n_labels,
        }
        logger.info("Added scalar bar title=%s vertical=%s n_labels=%d", title, vertical, n_labels)

    def add_text_actor(self, text: Text) -> None:
        """Mock add_text_actor.

        Parameters
        ----------
        text : Text
            The text actor to add (stored but not rendered).

        """
        self.text_actors.append(text)
        logger.info("Added text actor: %s", text.input)

    def clear(self) -> None:
        """Mock clear.

        Removes all actors, lights, and text actors from the mock renderer.
        """
        self.actors = []
        self.lights = []
        self._scalar_bar = None
        self.text_actors = []
        logger.info("Cleared all actors")

    def set_background(self, color: tuple[float, float, float]) -> None:
        """Set the background color.

        Parameters
        ----------
        color : tuple
            RGB color tuple with values between 0 and 1.

        """
        self.background = color

    def view_vector(
        self,
        vector: tuple[float, float, float],
        viewup: tuple[float, float, float] | None = None,
    ) -> None:
        """Mock view_vector.

        Parameters
        ----------
        vector : tuple of float
            Direction vector (stored but not rendered).
        viewup : tuple of float, optional
            View-up vector (stored but not rendered).

        """
        self._view_vector = (float(vector[0]), float(vector[1]), float(vector[2]))
        if viewup is not None:
            self._view_up = (float(viewup[0]), float(viewup[1]), float(viewup[2]))
        logger.info("Set view vector: %s (viewup=%s)", vector, viewup)

    @property
    def camera(self) -> Camera | None:
        """Get or set the camera (mock).

        Parameters
        ----------
        camera : Camera
            Camera object (stored but not rendered).

        Returns
        -------
        Camera or None
            The current camera, or None if not set.

        """
        return self._camera

    @camera.setter
    def camera(self, camera: Camera) -> None:
        """Set the camera."""
        self._camera = camera
        logger.info("Set camera: %s", camera)

    def add_axes(self, **kwargs: object) -> None:  # noqa: ARG002
        """Mock add_axes.

        Parameters
        ----------
        **kwargs
            Reserved for future implementation.

        """
        logger.info("add_axes called (mock)")

    def set_environment_texture(self, texture: object) -> None:
        """Mock environment texture.

        Parameters
        ----------
        texture : str or CubeMap
            Environment texture (stored but not rendered).

        """
        logger.info("Set environment texture: %s", texture)

    def screenshot(
        self,
        filename: str | Path | None = None,
        transparent_background: bool | None = None,  # noqa: FBT001
        return_img: bool = True,  # noqa: FBT001, FBT002
        window_size: tuple[int, int] | list[int] | None = None,
        scale: int | None = None,
    ) -> np.ndarray | None:
        """Mock screenshot that returns a dummy numpy array.

        Parameters
        ----------
        filename : str, Path, or None, optional
            File path to save the image. If None, no file is written.
        transparent_background : bool or None, optional
            Whether to make the background transparent.
        return_img : bool, optional
            If True, return a numpy array of the image.
        window_size : tuple or list of int, optional
            Window size as (width, height). Default is (600, 400).
        scale : int or None, optional
            Scale factor for higher resolution.

        Returns
        -------
        numpy.ndarray or None
            Dummy image data as numpy array if return_img is True, otherwise None.

        """
        import numpy as np  # noqa: PLC0415

        width, height = (600, 400) if window_size is None else window_size
        if scale is not None:
            width *= scale
            height *= scale

        logger.info(
            "Mock screenshot: filename=%s size=(%d, %d) transparent=%s",
            filename,
            width,
            height,
            transparent_background,
        )

        if filename is not None:
            # Create a dummy PNG file
            try:
                from PIL import Image  # noqa: PLC0415
            except ImportError as e:  # pragma: no cover
                msg = "Pillow is required to save screenshot. Install it with: pip install pillow"
                raise ImportError(msg) from e

            channels = 4 if transparent_background else 3
            img = Image.new("RGBA" if transparent_background else "RGB", (width, height))
            img.save(filename)

        if return_img:
            # Return a dummy numpy array
            channels = 4 if transparent_background else 3
            return np.zeros((height, width, channels), dtype=np.uint8)
        return None


def get_renderer(
    lighting: str | None = "default",
) -> VTKJSRenderer | BrowserRenderer | MockRenderer:
    """Get appropriate renderer for current environment.

    Automatically detects whether running in Pyodide/browser and
    returns the appropriate renderer implementation.

    Parameters
    ----------
    lighting : str or None, optional
        Lighting mode. ``"default"`` creates a default directional light,
        ``None`` creates no default lights. Default is ``"default"``.

    Returns
    -------
    VTKJSRenderer or BrowserRenderer or MockRenderer
        - VTKJSRenderer if in Pyodide or IPython environment
        - BrowserRenderer in standard Python (opens the default browser)
        - MockRenderer if ``PYVISTA_JS_NO_BROWSER=1`` is set (for testing/CI)

    Examples
    --------
    >>> # Automatically gets the right renderer
    >>> renderer = get_renderer()  # doctest: +SKIP
    >>> # In Pyodide or Jupyter: returns VTKJSRenderer
    >>> # In standard Python: returns BrowserRenderer (opens browser)
    >>> # Same code works in both environments
    >>> from pyvista_js import Sphere  # doctest: +SKIP
    >>> mesh = Sphere()  # doctest: +SKIP
    >>> renderer.add_mesh_actor(mesh, color='blue')  # doctest: +SKIP
    >>> renderer.create_container()  # doctest: +SKIP
    >>> renderer.render()  # doctest: +SKIP

    Notes
    -----
    This function is used internally by the Plotter class. You typically
    don't need to call it directly unless implementing custom rendering logic.

    Set the environment variable ``PYVISTA_JS_NO_BROWSER=1`` to suppress
    browser opening (useful for CI/CD and automated testing).

    """
    # Use VTKJSRenderer if in Pyodide with vtk.js OR if IPython is available
    if (PYODIDE_ENV and VTK_AVAILABLE) or IPYTHON_AVAILABLE:
        return VTKJSRenderer(lighting=lighting)
    # Respect opt-out env var for CI/testing
    if os.environ.get("PYVISTA_JS_NO_BROWSER"):
        return MockRenderer(lighting=lighting)
    return BrowserRenderer(lighting=lighting)
