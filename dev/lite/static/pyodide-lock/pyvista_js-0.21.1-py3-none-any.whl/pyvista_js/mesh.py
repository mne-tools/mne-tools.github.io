"""Mesh classes for pyvista-js.

Provides geometric primitives and mesh handling compatible with PyVista API.
"""

from __future__ import annotations

import json
import re
import secrets
from typing import TYPE_CHECKING, Any

import numpy as np

try:
    import orjson
except ImportError:  # pragma: no cover
    orjson = None  # type: ignore[assignment]

if TYPE_CHECKING:
    from pathlib import Path

    from numpy.typing import ArrayLike


class PointData:
    """Dict-like container for point data arrays.

    This class provides a dictionary interface for storing named scalar arrays
    associated with mesh points, mimicking PyVista's point_data API.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> import numpy as np
    >>> mesh = pv.Sphere()
    >>> mesh.point_data['elevation'] = mesh.points[:, 2]
    >>> 'elevation' in mesh.point_data
    True

    Render with scalar coloring:

    >>> plotter = pv.Plotter()
    >>> _ = plotter.add_mesh(mesh, scalars='elevation', cmap='viridis')
    >>> plotter.show()  # doctest: +SKIP

    """

    def __init__(self) -> None:
        """Initialize an empty PointData container."""
        self._arrays: dict[str, np.ndarray] = {}

    def __setitem__(self, name: str, array: ArrayLike) -> None:
        """Set a named array.

        Parameters
        ----------
        name : str
            Name of the array.
        array : array-like
            Data array to store.

        """
        self._arrays[name] = np.asarray(array)

    def __getitem__(self, name: str) -> np.ndarray:
        """Get a named array.

        Parameters
        ----------
        name : str
            Name of the array.

        Returns
        -------
        np.ndarray
            The requested array.

        """
        return self._arrays[name]

    def __contains__(self, name: str) -> bool:
        """Check if an array with the given name exists.

        Parameters
        ----------
        name : str
            Name to check.

        Returns
        -------
        bool
            True if the array exists.

        """
        return name in self._arrays

    def __len__(self) -> int:
        """Return the number of arrays."""
        return len(self._arrays)

    def keys(self) -> list[str]:
        """Return the names of all arrays.

        Returns
        -------
        list
            List of array names.

        """
        return list(self._arrays.keys())

    def items(self) -> list[tuple[str, np.ndarray]]:
        """Return (name, array) pairs.

        Returns
        -------
        list
            List of (name, array) tuples.

        """
        return list(self._arrays.items())

    def values(self) -> list[np.ndarray]:
        """Return all arrays.

        Returns
        -------
        list
            List of arrays.

        """
        return list(self._arrays.values())


_CIRCLE_MIN_RESOLUTION = 3
_VECTOR_COMPONENTS = 3  # Number of components in a 3D vector (x, y, z)
_POINT_CLOUD_COMPONENTS = 3  # Points of a point cloud have x, y, and z coordinates
_POINT_PAIR_LENGTH = 2  # A threshold range is a pair of values
_MIN_SMOOTH_ITERATIONS = 1  # smoothing needs at least one pass
_TUBE_MIN_SIDES = 3
_TUBE_DEFAULT_RADIUS = 0.5
_TUBE_MAX_RADIUS = 100.0
_TUBE_SIDES_FOR_TUBES = 20
_FACE_DIMENSIONS = 2  # faces stored as (n_cells, n_corners) rows
_CORNERS_PER_BOX_FACE = 4  # each face of a box has four corners
_BOX_EDGE_CORNERS = 8  # a box has eight corners in total
_TRIANGLE_VERTICES = 3  # a triangle has three corners

# VTK cell type constants
_CELL_TYPE_VERTEX = 1
_CELL_TYPE_LINE = 3
_CELL_TYPE_TRIANGLE = 5
_CELL_TYPE_QUAD = 9
_CELL_TYPE_TETRA = 10
_CELL_TYPE_HEXAHEDRON = 12
_CELL_TYPE_WEDGE = 13
_CELL_TYPE_PYRAMID = 14


class CellType:
    """VTK cell type constants.

    Provides named constants for the most common VTK cell types,
    matching the :class:`pyvista.CellType` API.

    These constants are used to define the type of cells in an
    :class:`UnstructuredGrid`. Each cell type corresponds to a specific
    VTK cell type identifier.

    Examples
    --------
    Basic usage:

    >>> import pyvista_js as pv
    >>> pv.CellType.TETRA
    10
    >>> pv.CellType.HEXAHEDRON
    12
    >>> pv.CellType.TRIANGLE
    5
    >>> pv.CellType.QUAD
    9

    Use with UnstructuredGrid:

    >>> import numpy as np
    >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
    >>> cells = [4, 0, 1, 2, 3]
    >>> celltypes = [pv.CellType.TETRA]  # Use the constant
    >>> grid = pv.UnstructuredGrid(cells, celltypes, points)

    Available cell types:

    >>> # 0-D cells
    >>> pv.CellType.VERTEX  # Single point
    1
    >>> # 1-D cells
    >>> pv.CellType.LINE  # Line segment
    3
    >>> # 2-D cells
    >>> pv.CellType.TRIANGLE  # 3-point triangle
    5
    >>> pv.CellType.QUAD  # 4-point quadrilateral
    9
    >>> # 3-D cells
    >>> pv.CellType.TETRA  # 4-point tetrahedron
    10
    >>> pv.CellType.HEXAHEDRON  # 8-point hexahedron (cube)
    12
    >>> pv.CellType.WEDGE  # 6-point triangular prism
    13
    >>> pv.CellType.PYRAMID  # 5-point pyramid
    14

    """

    VERTEX: int = _CELL_TYPE_VERTEX
    LINE: int = _CELL_TYPE_LINE
    TRIANGLE: int = _CELL_TYPE_TRIANGLE
    QUAD: int = _CELL_TYPE_QUAD
    TETRA: int = _CELL_TYPE_TETRA
    HEXAHEDRON: int = _CELL_TYPE_HEXAHEDRON
    WEDGE: int = _CELL_TYPE_WEDGE
    PYRAMID: int = _CELL_TYPE_PYRAMID


class _Float32Array:
    """A float array that scene JSON emits as the shortest float32 text.

    vtk.js stores these values in a ``Float32Array``, so printing each one
    with the fewest digits that round-trip to the same float32 is lossless
    and about half the size of the 17-digit float64 text of ``tolist()``.

    Parameters
    ----------
    array : array-like
        The values, flattened and cast to float32.

    """

    __slots__ = ("array",)

    def __init__(self, array: ArrayLike) -> None:
        array = np.asarray(array)
        if np.iscomplexobj(array):
            # casting would silently drop the imaginary parts
            msg = "Cannot serialize complex values to scene JSON"
            raise TypeError(msg)
        self.array = array.astype(np.float32).ravel()

    def __len__(self) -> int:
        return self.array.size

    def tolist(self) -> list[float]:
        """Return the values as a list of Python floats."""
        return self.array.tolist()

    def finite(self) -> np.ndarray:
        """Return the values, checking that JSON can represent them."""
        if not np.isfinite(self.array).all():
            msg = "Cannot serialize NaN or infinite values to scene JSON"
            raise ValueError(msg)
        return self.array

    def to_json(self) -> str:
        """Return the values as a JSON array of shortest float32 text."""
        return "[" + ",".join(self.finite().astype(str).tolist()) + "]"


def _plain_scene(obj: object) -> object:
    """Return scene data with each ``_Float32Array`` replaced by a list of floats.

    Parameters
    ----------
    obj : object
        Scene data that may contain ``_Float32Array`` values.

    Returns
    -------
    object
        The same data, serializable by :func:`json.dumps`.

    """
    if isinstance(obj, _Float32Array):
        return obj.tolist()
    if isinstance(obj, dict):
        return {key: _plain_scene(value) for key, value in obj.items()}
    if isinstance(obj, list):
        return [_plain_scene(value) for value in obj]
    return obj


def _dumps_scene(obj: object) -> str:
    """Serialize scene data to compact JSON, splicing in ``_Float32Array`` text.

    Uses orjson when it is installed, which is several times faster and
    writes the same values.

    Parameters
    ----------
    obj : object
        JSON-serializable data that may contain ``_Float32Array`` values.

    Returns
    -------
    str
        The JSON text.

    """
    if orjson is not None:

        def to_array(value: object) -> np.ndarray:
            if not isinstance(value, _Float32Array):
                raise TypeError
            return value.finite()

        try:
            return orjson.dumps(obj, default=to_array, option=orjson.OPT_SERIALIZE_NUMPY).decode()
        except TypeError as err:
            # orjson wraps errors from ``default``; surface the NaN check as is
            if isinstance(err.__cause__, ValueError):
                raise err.__cause__ from None
            raise

    # each array is written as a placeholder string, then swapped for its text;
    # a random nonce keeps strings in the data from being taken for placeholders
    fragments: list[str] = []  # type: ignore[unreachable]
    nonce = secrets.token_hex(16)

    def default(value: object) -> str:
        if not isinstance(value, _Float32Array):
            msg = f"Object of type {type(value).__name__} is not JSON serializable"
            raise TypeError(msg)
        fragments.append(value.to_json())
        return f"pvjs-f32-{nonce}-{len(fragments) - 1}"

    text = json.dumps(obj, default=default, separators=(",", ":"))
    token = re.compile(rf'"pvjs-f32-{nonce}-(\d+)"')
    return token.sub(lambda match: fragments[int(match.group(1))], text)


def _point_data_to_scene(point_data: PointData | dict[str, np.ndarray]) -> list[dict[str, object]]:
    """Serialize point-data arrays for the vtk.js template.

    Unsigned 8-bit arrays are sent as ``Uint8Array`` so vtk.js can use them
    directly as RGB(A) colors; everything else becomes ``Float32Array``.

    Parameters
    ----------
    point_data : PointData or dict
        The arrays to serialize, by name.

    Returns
    -------
    list of dict
        One entry per array with its name, component count, data type and values.

    """
    return [
        {
            "name": name,
            "numberOfComponents": 1 if array.ndim == 1 else array.shape[1],
            "dataType": "Uint8Array" if array.dtype == np.uint8 else "Float32Array",
            "values": array.flatten().tolist() if array.dtype == np.uint8 else _Float32Array(array),
        }
        for name, array in point_data.items()
    ]


class PolyData:
    """Base polygonal mesh class.

    Parameters
    ----------
    points : array-like
        Vertex coordinates as an (n, 3) array.
    faces : array-like, optional
        Cell connectivity information.

    """

    def __init__(
        self,
        points: ArrayLike,
        faces: ArrayLike | None = None,
        *,
        t_coords: ArrayLike | None = None,
        scalars: ArrayLike | None = None,
        scalar_name: str = "scalars",
        _scene_data: dict[str, Any] | None = None,
    ) -> None:
        """Initialize a PolyData mesh."""
        self.points = np.asarray(points)
        self.faces = np.asarray(faces) if faces is not None else None
        self.t_coords = np.asarray(t_coords) if t_coords is not None else None
        self.scalars = np.asarray(scalars) if scalars is not None else None
        self.scalar_name = scalar_name
        self._scene_data = _scene_data
        self._point_data = PointData()

    @property
    def point_data(self) -> PointData:
        """Access point data arrays.

        Returns
        -------
        PointData
            Dict-like container for point data arrays.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> import numpy as np
        >>> mesh = pv.Sphere()
        >>> mesh.point_data['elevation'] = mesh.points[:, 2]
        >>> 'elevation' in mesh.point_data
        True

        Render with scalar coloring:

        >>> plotter = pv.Plotter()
        >>> _ = plotter.add_mesh(mesh, scalars='elevation', cmap='viridis')
        >>> plotter.show()  # doctest: +SKIP

        """
        return self._point_data

    def __setitem__(self, name: str, array: ArrayLike) -> None:
        """Set a point data array using dictionary-style access.

        Parameters
        ----------
        name : str
            Name of the array.
        array : array-like
            Data array to store.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> import numpy as np
        >>> mesh = pv.Sphere()
        >>> mesh['elevation'] = mesh.points[:, 2]
        >>> plotter = pv.Plotter()
        >>> _ = plotter.add_mesh(mesh, scalars='elevation', cmap='viridis')
        >>> plotter.show()  # doctest: +SKIP

        """
        self._point_data[name] = array

    def __getitem__(self, name: str) -> np.ndarray:
        """Get a point data array using dictionary-style access.

        Parameters
        ----------
        name : str
            Name of the array.

        Returns
        -------
        np.ndarray
            The requested array.

        """
        return self._point_data[name]

    @property
    def n_points(self) -> int:
        """Return the number of points."""
        return len(self.points)

    @property
    def bounding_sphere(self) -> tuple[float, tuple[float, float, float]]:
        """Compute the radius and center of a bounding sphere.

        Uses Ritter's algorithm to approximate the minimum bounding sphere.
        Returns NaN values if there are no points.

        Returns
        -------
        float, tuple
            Sphere radius as a float and center as a tuple of floats ``(x, y, z)``.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> mesh = pv.Sphere(radius=1.5, center=(1, 2, 3))
        >>> radius, center = mesh.bounding_sphere
        >>> round(radius, 5)
        1.5
        >>> [round(c, 5) for c in center]
        [1.0, 2.0, 3.0]

        """
        if self.n_points == 0:
            nan = float("nan")
            return nan, (nan, nan, nan)

        pts = self.points.astype(float)

        # Ritter's algorithm
        p = pts[0]
        dists = np.linalg.norm(pts - p, axis=1)
        q = pts[np.argmax(dists)]
        dists = np.linalg.norm(pts - q, axis=1)
        r = pts[np.argmax(dists)]

        center = (q + r) / 2.0
        radius = float(np.linalg.norm(r - q) / 2.0)

        for pt in pts:
            d = float(np.linalg.norm(pt - center))
            if d > radius:
                radius = (radius + d) / 2.0
                center = center + (d - radius) / d * (pt - center)

        return radius, (float(center[0]), float(center[1]), float(center[2]))

    @property
    def n_faces(self) -> int:
        """Return the number of faces."""
        return len(self.faces) if self.faces is not None else 0

    def _iter_face_cells(self) -> list[np.ndarray]:
        """Return the faces as a list of index arrays, one per cell."""
        if self.faces is None:
            return []
        if self.faces.ndim == _FACE_DIMENSIONS:
            return [np.asarray(row) for row in self.faces]
        cells: list[np.ndarray] = []
        flat = self.faces.reshape(-1)
        i = 0
        while i < len(flat):
            n_cell = int(flat[i])
            cells.append(flat[i + 1 : i + 1 + n_cell])
            i += n_cell + 1
        return cells

    def __add__(self, other: PolyData) -> PolyData:
        """Combine two meshes with dictionary-style ``+`` operator.

        Mirrors the PyVista ``PolyData.__add__`` API: point and cell arrays of
        both meshes are concatenated and the point indices of cells in
        ``other`` are shifted by ``n_points`` of this mesh.

        Parameters
        ----------
        other : PolyData
            The second mesh to append.

        Returns
        -------
        PolyData
            A new mesh containing points and cells from both meshes.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> combined = pv.Cube() + pv.Cube(x_length=2.0)
        >>> isinstance(combined, pv.PolyData)
        True

        """
        other._validate_same_points_dims(self)
        points = np.vstack([self.points, other.points])
        offset = len(self.points)
        cells = [*self._iter_face_cells(), *[cell + offset for cell in other._iter_face_cells()]]
        faces: np.ndarray | None
        if cells and all(len(cell) == len(cells[0]) for cell in cells):
            faces = np.array(cells)
        elif cells:
            faces = np.concatenate(
                [np.concatenate([[len(cell)], cell]) for cell in cells],
            )
        else:
            faces = None

        scalars: np.ndarray | None = None
        if self.scalars is not None and other.scalars is not None:
            scalars = np.concatenate([self.scalars, other.scalars])
        elif self.scalars is not None:
            scalars = np.concatenate(
                [self.scalars, np.full(len(other.points), np.nan)],
            )
        elif other.scalars is not None:
            scalars = np.concatenate(
                [np.full(len(self.points), np.nan), other.scalars],
            )

        combined = PolyData(
            points=points,
            faces=faces,
            scalars=scalars,
            scalar_name=self.scalar_name if scalars is not None else "scalars",
        )
        for name in (*self._point_data.keys(), *other._point_data.keys()):
            if name in self._point_data and name in other._point_data:
                combined.point_data[name] = np.concatenate(
                    [
                        np.asarray(self._point_data[name]),
                        np.asarray(other._point_data[name]),
                    ],
                )
            elif name in self._point_data:
                combined.point_data[name] = np.concatenate(
                    [
                        np.asarray(self._point_data[name]),
                        np.full(len(other.points), np.nan),
                    ],
                )
            else:
                combined.point_data[name] = np.concatenate(
                    [
                        np.full(len(self.points), np.nan),
                        np.asarray(other._point_data[name]),
                    ],
                )
        return combined

    def _validate_same_points_dims(self, expected: PolyData) -> None:
        """Check that another mesh has the same point dimensionality."""
        if self.points.shape[1:] != expected.points.shape[1:]:
            msg = "Both meshes must have 3D points to combine with '+'"
            raise ValueError(msg)

    def plot(
        self,
        color: str | tuple[float, float, float] | None = None,
        opacity: float = 1.0,
        pbr: bool = False,  # noqa: FBT001 FBT002
        metallic: float = 0.0,
        roughness: float = 0.5,
    ) -> None:
        """Plot this mesh.

        This is a convenience method that creates a :class:`~pyvista_js.Plotter`,
        adds this mesh, and calls :func:`~pyvista_js.Plotter.show`.

        Parameters
        ----------
        color : str or tuple, optional
            Color of the mesh. Can be a color name or RGB tuple.
        opacity : float, optional
            Opacity of the mesh, between 0 (transparent) and 1 (opaque).
        pbr : bool, optional
            Enable physically based rendering (PBR). Default is False.
        metallic : float, optional
            Metallic factor for PBR, between 0 and 1. Default is 0.0.
        roughness : float, optional
            Roughness factor for PBR, between 0 and 1. Default is 0.5.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> sphere.plot(color='red')  # doctest: +SKIP

        """
        from .plotter import Plotter  # noqa: PLC0415

        plotter = Plotter()
        plotter.add_mesh(
            self,
            color=color,
            opacity=opacity,
            pbr=pbr,
            metallic=metallic,
            roughness=roughness,
        )
        plotter.show()

    def save(self, filename: str | Path) -> None:
        """Write this mesh to disk using meshio.

        The file format is inferred from the extension of ``filename``.
        Any format supported by `meshio <https://github.com/nschloe/meshio>`_
        can be used (e.g. ``'.obj'``, ``'.vtk'``, ``'.ply'``, ``'.stl'``).

        .. note::

            Requires ``meshio`` to be installed::

                pip install "pyvista-js[io]"

            In Pyodide / JupyterLite, install it with micropip before calling
            this method::

                import micropip
                await micropip.install("meshio")

        Parameters
        ----------
        filename : str or Path
            Output path. The extension determines the file format.

        Returns
        -------
        None

        Raises
        ------
        ImportError
            If ``meshio`` is not installed.

        Examples
        --------
        >>> from pyvista_js import examples
        >>> mesh = examples.download_trumpet()  # doctest: +SKIP
        >>> mesh.save('trumpet.obj')  # doctest: +SKIP

        """
        try:
            import meshio  # noqa: PLC0415
        except ImportError:
            msg = (
                "meshio is required for save(). "
                "Install it with: pip install 'pyvista-js[io]'\n"
                "In Pyodide: await micropip.install('meshio')"
            )
            raise ImportError(msg) from None

        cells = self._meshio_cells()
        mesh = meshio.Mesh(points=self.points, cells=cells)
        mesh.write(str(filename))

    def _meshio_cells(self) -> list:
        """Build a meshio-compatible cell list from ``self.faces``."""
        if self.faces is None or len(self.faces) == 0:
            return []

        from collections import defaultdict  # noqa: PLC0415

        groups: dict = defaultdict(list)
        for face in self.faces:
            groups[len(face)].append(face)

        _CELL_TYPES = {3: "triangle", 4: "quad"}  # noqa: N806
        return [(_CELL_TYPES.get(n, "polygon"), np.array(faces)) for n, faces in groups.items()]

    def shrink(self, shrink_factor: float = 0.8) -> PolyData:
        """Shrink the cells of a mesh towards their centroid.

        This filter shrinks the individual cells of a mesh towards their
        centroids, producing visual separation between adjacent cells.
        It mirrors the PyVista ``shrink`` filter API.

        .. note::

            The shrink is computed in JavaScript at render time by
            iterating over the cell array from the vtk.js source,
            moving each vertex toward its cell's centroid.
            ``vtk.js`` does not include ``vtkShrinkFilter``, so this
            filter is implemented as a custom JavaScript pass.

        Parameters
        ----------
        shrink_factor : float, optional
            The factor to shrink each cell by, between 0 and 1.
            A value of 1.0 produces no change; lower values produce
            more shrinkage. Default is 0.8.

        Returns
        -------
        PolyData
            A new mesh with shrunk cells.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> shrunk = sphere.shrink(shrink_factor=0.8)
        >>> isinstance(shrunk, pv.PolyData)
        True

        Render the shrunk mesh:

        >>> shrunk.plot()  # doctest: +SKIP

        """
        if not (0.0 <= shrink_factor <= 1.0):
            msg = f"shrink_factor must be between 0 and 1, got {shrink_factor}"
            raise ValueError(msg)

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        filters_list.append(
            {
                "type": "shrink",
                "shrinkFactor": shrink_factor,
            },
        )

        return PolyData(
            points=self.points,
            faces=self.faces,
            _scene_data=base_scene,
        )

    def clean(self, point_tolerance: float = 0.0) -> PolyData:
        """Merge duplicate points and remove unused or degenerate cells.

        This filters coincident points into a single point and rebuilds
        the cell connectivity accordingly. Point data arrays are
        preserved by keeping the value of the first occurrence of each
        merged point. It mirrors the PyVista ``clean`` filter API.

        .. note::

            The merge is computed in Python with NumPy. Points are
            merged when their coordinates are equal (or within
            ``point_tolerance`` when it is greater than zero).

        Parameters
        ----------
        point_tolerance : float, optional
            Tolerance used to decide whether two points are coincident.
            The default of 0.0 merges only points that are exactly equal.

        Returns
        -------
        PolyData
            A new mesh without duplicate points or degenerate cells.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> import numpy as np
        >>> points = np.array([[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [1.0, 0.0, 0.0]])
        >>> faces = np.array([2, 0, 1])
        >>> mesh = pv.PolyData(points, faces)
        >>> cleaned = mesh.clean()
        >>> cleaned.n_points
        2

        Render the cleaned mesh:

        >>> cleaned.plot()  # doctest: +SKIP

        """
        pts = self.points
        faces = self.faces

        quantized = np.round(pts / point_tolerance) if point_tolerance > 0.0 else pts
        _, first_occurrence_indices, inverse_indices = np.unique(
            quantized,
            axis=0,
            return_index=True,
            return_inverse=True,
        )
        n_unique = len(first_occurrence_indices)
        order = np.argsort(first_occurrence_indices)
        rank = np.empty(n_unique, dtype=np.int64)
        rank[order] = np.arange(n_unique)
        remap = rank[inverse_indices]
        rep = first_occurrence_indices[order]
        new_points = pts[rep]

        new_faces: list[np.ndarray] = []
        if faces is not None and faces.ndim == 1:
            flat = faces.reshape(-1)
            i = 0
            while i < len(flat):
                n_cell = int(flat[i])
                cell = remap[flat[i + 1 : i + 1 + n_cell]]
                i += n_cell + 1
                if n_cell > 0 and len(np.unique(cell)) < n_cell:
                    continue
                new_faces.append(np.concatenate([[n_cell], cell]))
            faces = np.concatenate(new_faces) if new_faces else None
        elif faces is not None and faces.ndim == _VECTOR_COMPONENTS - 1:
            rows = remap[faces]
            keep = np.array([len(np.unique(row)) == len(row) for row in rows])
            faces = rows[keep]

        cleaned = PolyData(
            points=new_points,
            faces=faces,
            scalars=None if self.scalars is None else self.scalars[rep],
            scalar_name=self.scalar_name,
            t_coords=None if self.t_coords is None else self.t_coords[rep],
        )
        for name, array in self._point_data.items():
            cleaned.point_data[name] = np.asarray(array)[rep]
        return cleaned

    def clip(
        self,
        normal: str | tuple[float, float, float] = "x",
        origin: tuple[float, float, float] | None = None,
        *,
        invert: bool = False,
    ) -> PolyData:
        """Clip the mesh with a plane.

        This filter clips the mesh with a plane defined by a normal vector
        and an origin point. Points on one side of the plane are removed.
        It mirrors the PyVista ``clip`` filter API.

        .. note::

            The clipping is computed in JavaScript at render time by
            evaluating the signed distance of each vertex from the clip plane.
            Cells with all vertices on the clipped side are removed.
            ``vtk.js`` does not include a built-in clipping filter with
            the exact PyVista API, so this filter is implemented as a
            custom JavaScript pass.

        Parameters
        ----------
        normal : str or tuple of float, optional
            The normal vector of the clipping plane. Can be a string
            specifying a cardinal direction ('x', 'y', 'z', '-x', '-y', '-z')
            or a 3-tuple of floats (nx, ny, nz). Default is 'x'.
        origin : tuple of float, optional
            The origin point of the clipping plane as (x, y, z).
            If not provided, defaults to the center of the mesh's bounding box.
        invert : bool, optional
            If True, flip the clipping direction to keep the part that would
            normally be removed. Default is False.

        Returns
        -------
        PolyData
            A new mesh with clipped cells removed.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> clipped = sphere.clip(normal='x', origin=(0, 0, 0))
        >>> isinstance(clipped, pv.PolyData)
        True

        Clip along the negative Y axis:

        >>> clipped = sphere.clip(normal='-y')
        >>> isinstance(clipped, pv.PolyData)
        True

        Clip with a custom normal vector:

        >>> clipped = sphere.clip(normal=(1, 1, 0), origin=(0, 0, 0))
        >>> isinstance(clipped, pv.PolyData)
        True

        Render the clipped mesh:

        >>> clipped.plot()  # doctest: +SKIP

        """
        # Parse normal vector
        if isinstance(normal, str):
            normal_map = {
                "x": (1.0, 0.0, 0.0),
                "+x": (1.0, 0.0, 0.0),
                "-x": (-1.0, 0.0, 0.0),
                "y": (0.0, 1.0, 0.0),
                "+y": (0.0, 1.0, 0.0),
                "-y": (0.0, -1.0, 0.0),
                "z": (0.0, 0.0, 1.0),
                "+z": (0.0, 0.0, 1.0),
                "-z": (0.0, 0.0, -1.0),
            }
            if normal not in normal_map:
                msg = f"Invalid normal string '{normal}'. Must be one of {list(normal_map.keys())}"
                raise ValueError(msg)
            normal_vec = normal_map[normal]
        else:
            if len(normal) != _VECTOR_COMPONENTS:  # type: ignore[arg-type]
                msg = f"Normal vector must have {_VECTOR_COMPONENTS} components, got {len(normal)}"  # type: ignore[arg-type]
                raise ValueError(msg)
            n = [float(x) for x in normal]  # type: ignore[arg-type]
            normal_vec = (n[0], n[1], n[2])

        # Compute origin if not provided (use center of bounding box)
        if origin is None:
            pts = self.points
            origin = (
                float((pts[:, 0].min() + pts[:, 0].max()) / 2),
                float((pts[:, 1].min() + pts[:, 1].max()) / 2),
                float((pts[:, 2].min() + pts[:, 2].max()) / 2),
            )
        else:
            if len(origin) != _VECTOR_COMPONENTS:
                msg = f"Origin must have {_VECTOR_COMPONENTS} components, got {len(origin)}"
                raise ValueError(msg)
            o = [float(x) for x in origin]
            origin = (o[0], o[1], o[2])

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        filters_list.append(
            {
                "type": "clip",
                "normal": list(normal_vec),
                "origin": list(origin),
                "invert": invert,
            },
        )

        return PolyData(
            points=self.points,
            faces=self.faces,
            _scene_data=base_scene,
        )

    def slice(
        self,
        normal: str | tuple[float, float, float] = "z",
        origin: tuple[float, float, float] | None = None,
        generate_triangles: bool = False,  # noqa: FBT001, FBT002, ARG002
    ) -> PolyData:
        """Slice the mesh with a plane, producing cross-section lines.

        This mirrors the PyVista ``slice`` filter API and is backed by
        vtk.js's ``vtkCutter`` with a cut plane.

        .. note::

            The slicing is computed in JavaScript at render time by
            evaluating the cut function per point and triangulating the
            crossing edges. ``generate_triangles`` is accepted for API
            compatibility but currently has no effect.

        Parameters
        ----------
        normal : str or tuple of float, optional
            The normal vector of the slicing plane. Can be a string
            specifying a cardinal direction ('x', 'y', 'z', '-x', '-y',
            '-z') or a 3-tuple of floats (nx, ny, nz). Default is 'z'.
        origin : tuple of float, optional
            The origin point of the slicing plane as (x, y, z). If not
            provided, defaults to the center of the mesh's bounding box.
        generate_triangles : bool, optional
            Reserved for API compatibility with PyVista. No effect.

        Returns
        -------
        PolyData
            A new mesh with the cross-section geometry.

        Raises
        ------
        ValueError
            If the normal string is invalid or vectors have the wrong size.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> sliced = sphere.slice(normal='z')
        >>> isinstance(sliced, pv.PolyData)
        True

        Render the cross-section:

        >>> sliced.plot(color='red', opacity=1.0)  # doctest: +SKIP

        """
        if isinstance(normal, str):
            normal_map = {
                "x": (1.0, 0.0, 0.0),
                "+x": (1.0, 0.0, 0.0),
                "-x": (-1.0, 0.0, 0.0),
                "y": (0.0, 1.0, 0.0),
                "+y": (0.0, 1.0, 0.0),
                "-y": (0.0, -1.0, 0.0),
                "z": (0.0, 0.0, 1.0),
                "+z": (0.0, 0.0, 1.0),
                "-z": (0.0, 0.0, -1.0),
            }
            if normal not in normal_map:
                msg = f"Invalid normal string '{normal}'. Must be one of {list(normal_map.keys())}"
                raise ValueError(msg)
            normal_vec = normal_map[normal]
        else:
            if len(normal) != _VECTOR_COMPONENTS:  # type: ignore[arg-type]
                msg = f"Normal vector must have {_VECTOR_COMPONENTS} components, got {len(normal)}"
                raise ValueError(msg)
            n = [float(x) for x in normal]  # type: ignore[arg-type]
            normal_vec = (n[0], n[1], n[2])

        if origin is None:
            pts = self.points
            origin = (
                float((pts[:, 0].min() + pts[:, 0].max()) / 2),
                float((pts[:, 1].min() + pts[:, 1].max()) / 2),
                float((pts[:, 2].min() + pts[:, 2].max()) / 2),
            )
        else:
            if len(origin) != _VECTOR_COMPONENTS:
                msg = f"Origin must have {_VECTOR_COMPONENTS} components, got {len(origin)}"
                raise ValueError(msg)
            o = [float(x) for x in origin]
            origin = (o[0], o[1], o[2])

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        filters_list.append(
            {
                "type": "slice",
                "normal": list(normal_vec),
                "origin": list(origin),
            },
        )

        return PolyData(
            points=self.points,
            faces=self.faces,
            _scene_data=base_scene,
        )

    def tube(
        self,
        *,
        radius: float = 0.5,
        n_sides: int = 20,
        capping: bool = True,  # noqa: ARG002
    ) -> PolyData:
        """Generate a tube around a line polydata.

        This filter creates a tube representation around lines in the mesh
        by sweeping a polygonal cross-section along each line. It mirrors
        the PyVista ``tube`` filter API and is backed by vtk.js's
        ``vtkTubeFilter``.

        .. note::

            This filter is intended for use with line-based polydata (such as
            the output of :class:`Line`). It uses vtk.js's ``vtkTubeFilter``,
            which generates a tube by sweeping a circle with ``n_sides`` sides
            along the line segments.

        Parameters
        ----------
        radius : float, optional
            The radius of the tube. Default is 0.5.
        n_sides : int, optional
            The number of sides for the tube cross-section.
            Higher values produce smoother tubes. Default is 20.
        capping : bool, optional
            Whether to cap the ends of the tube. Default is True.

        Returns
        -------
        PolyData
            A new mesh representing the tube.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> line = pv.Line()
        >>> tube = line.tube(radius=0.05, n_sides=20)
        >>> isinstance(tube, pv.PolyData)
        True

        Render the tube:

        >>> tube.plot()  # doctest: +SKIP

        """
        if radius <= 0:
            msg = f"radius must be positive, got {radius}"
            raise ValueError(msg)
        if n_sides < _TUBE_MIN_SIDES:
            msg = f"n_sides must be at least {_TUBE_MIN_SIDES}, got {n_sides}"
            raise ValueError(msg)

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        filters_list.append(
            {
                "type": "tube",
                "radius": radius,
                "numberOfSides": n_sides,
            },
        )

        return PolyData(
            points=self.points,
            faces=self.faces,
            _scene_data=base_scene,
        )

    def contour(
        self,
        isosurfaces: int | list[float] = 10,
        scalars: ArrayLike | None = None,
        scalar_name: str | None = None,
    ) -> PolyData:
        """Generate contour lines at constant scalar values.

        This filter extracts isolines from the mesh at specified scalar values
        using a marching triangles algorithm implemented in JavaScript.
        It mirrors the PyVista ``contour`` filter API.

        .. note::

            The contour is computed in JavaScript at render time by applying
            the marching triangles algorithm to each triangle of the mesh,
            interpolating edge crossings at the specified iso-values.
            ``vtk.js`` does not support ``vtkPolyData`` input for
            ``vtkContourFilter``, so this filter is implemented as a custom
            JavaScript pass.

        Parameters
        ----------
        isosurfaces : int or list of float, optional
            Number of evenly spaced contours to generate, or a list of explicit
            scalar values at which to generate contours. Default is 10.
        scalars : array-like, optional
            Scalar values per point to use for contouring. If not provided,
            uses the mesh's existing ``scalars`` attribute. Must have length
            equal to ``n_points``.
        scalar_name : str, optional
            Name for the scalar array in vtk.js. If not provided, uses the
            mesh's existing ``scalar_name`` attribute or defaults to "scalars".

        Returns
        -------
        PolyData
            A new mesh containing the contour lines.

        Raises
        ------
        ValueError
            If no scalars are provided and the mesh has no scalar data, or if
            isosurfaces parameter is invalid.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> sphere_scalars = sphere.points[:, 2]
        >>> contours = sphere.contour(isosurfaces=5, scalars=sphere_scalars)
        >>> isinstance(contours, pv.PolyData)
        True

        Generate contours at specific values:

        >>> contours = sphere.contour(isosurfaces=[-0.5, 0.0, 0.5], scalars=sphere_scalars)

        Render the contours:

        >>> contours.plot()

        """
        # Determine scalar data to use
        scalar_data = self._get_contour_scalars(scalars)

        # Determine scalar name
        scalar_name_final = scalar_name or self.scalar_name

        # Generate contour values
        contour_values = self._get_contour_values(isosurfaces, scalar_data)

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        filters_list.append(
            {
                "type": "contour",
                "values": contour_values,
                "scalarName": scalar_name_final,
                "scalarData": _Float32Array(scalar_data),
            },
        )

        # Return new PolyData with contour filter applied
        return PolyData(
            points=self.points,
            faces=self.faces,
            scalars=scalar_data,
            scalar_name=scalar_name_final,
            _scene_data=base_scene,
        )

    def _get_contour_scalars(self, scalars: ArrayLike | None) -> np.ndarray:
        """Get scalar data for contouring, validating length."""
        if scalars is not None:
            scalar_data = np.asarray(scalars)
        elif self.scalars is not None:
            scalar_data = self.scalars
        else:
            msg = "No scalar data provided. Pass scalars parameter or set mesh.scalars"
            raise ValueError(msg)

        if len(scalar_data) != self.n_points:
            msg = f"scalars must have length {self.n_points}, got {len(scalar_data)}"
            raise ValueError(msg)

        return scalar_data

    def _get_contour_values(
        self,
        isosurfaces: int | list[float],
        scalar_data: np.ndarray,
    ) -> list[float]:
        """Generate contour values from isosurfaces parameter."""
        if isinstance(isosurfaces, int):
            if isosurfaces < 1:
                msg = f"isosurfaces must be >= 1 when int, got {isosurfaces}"
                raise ValueError(msg)
            scalar_min, scalar_max = float(scalar_data.min()), float(scalar_data.max())
            return np.linspace(scalar_min, scalar_max, isosurfaces).tolist()

        contour_values = [float(v) for v in isosurfaces]
        if len(contour_values) < 1:
            msg = "isosurfaces list must contain at least one value"
            raise ValueError(msg)
        return contour_values

    def triangulate(self) -> PolyData:
        """Convert all polygon cells into triangles.

        This filter replaces every polygon of more than three vertices with
        a fan of triangles sharing its first vertex, and leaves lines and
        vertices unchanged. It mirrors the PyVista ``triangulate`` filter
        API.

        .. note::

            The triangulation is computed in Python with NumPy.

        Returns
        -------
        PolyData
            A new mesh whose polygons are all triangles.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> cube = pv.Cube()
        >>> triangles = cube.triangulate()
        >>> triangles.n_points
        24

        Render the triangulated mesh:

        >>> triangles.plot()  # doctest: +SKIP

        """
        cells = self._iter_face_cells()
        triangulated: list[list[np.int64]] = []
        for cell in cells:
            if len(cell) == _TRIANGLE_VERTICES:
                triangulated.append(cell.tolist())
            elif len(cell) > _TRIANGLE_VERTICES:
                triangulated.extend(
                    [cell[0], cell[i], cell[i + 1]].copy() for i in range(1, len(cell) - 1)
                )
            else:
                triangulated.append(cell.tolist())

        faces: np.ndarray | None
        triangulated_array = np.asarray(triangulated) if triangulated else None
        if triangulated_array is not None and all(
            len(row) == len(triangulated[0]) for row in triangulated
        ):
            faces = triangulated_array
        elif triangulated_array is not None:
            faces = np.concatenate(
                [np.concatenate([[len(cell)], cell]) for cell in triangulated],
            )
        else:
            faces = None
        return PolyData(
            points=self.points,
            faces=faces,
            scalars=self.scalars,
            scalar_name=self.scalar_name,
            t_coords=self.t_coords,
        )

    def outline(self, generate_faces: bool = False) -> PolyData:  # noqa: FBT001 FBT002
        """Produce an outline of the bounds for the mesh.

        Mirrors the PyVista ``outline`` filter API: the default output is an
        outline of 12 line segments along the bounding box edges, and
        ``generate_faces=True`` returns the filled box surface instead.

        .. note::

            The outline is computed in Python with NumPy from the
            axis-aligned bounding box of the points.

        Parameters
        ----------
        generate_faces : bool, optional
            If True, produce the filled box surface. Default is False.

        Returns
        -------
        PolyData
            A new mesh representing the bounding box.

        Raises
        ------
        ValueError
            If the mesh has no points.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> outline = pv.Sphere().outline(generate_faces=True)
        >>> outline.n_points
        8

        Render the bounding box:

        >>> outline.plot(color="black")  # doctest: +SKIP

        """
        if self.n_points == 0:
            msg = "Cannot outline a mesh without points"
            raise ValueError(msg)

        pts = np.asarray(self.points)
        px = (float(pts[:, 0].min()), float(pts[:, 0].max()))
        py_ = (float(pts[:, 1].min()), float(pts[:, 1].max()))
        pz = (float(pts[:, 2].min()), float(pts[:, 2].max()))

        # Corner ordering shared with the Cube factory:
        # index bit 2 = x, bit 1 = y, bit 0 = z
        corners = np.array(
            [
                [px[i], py_[j], pz[k]]
                for i in range(_FACE_DIMENSIONS)
                for j in range(_FACE_DIMENSIONS)
                for k in range(_FACE_DIMENSIONS)
            ],
        )
        # Quad connectivity for the box faces:
        # index bit 2 = x, bit 1 = y, bit 0 = z; corners are a ring
        cube_quads = (
            (0, 1, 3, 2),
            (4, 5, 7, 6),
            (0, 1, 5, 4),
            (2, 3, 7, 6),
            (0, 2, 4, 6),
            (1, 3, 5, 7),
        )

        cells: list[np.ndarray] = []
        if generate_faces:
            cells.extend(np.array([4, *quad]) for quad in cube_quads)
        else:
            # 12 box edges: pairs of corners differing in exactly one coordinate
            for a in range(_BOX_EDGE_CORNERS):
                for bit in (_CORNERS_PER_BOX_FACE, _CORNERS_PER_BOX_FACE // 2, 1):
                    b = a ^ bit
                    if b > a:
                        cells.append(np.array([2, a, b]))

        faces = np.concatenate(cells)
        return PolyData(points=corners, faces=faces)

    def fill_holes(self, hole_size: float = 1000.0) -> PolyData:
        """Fill holes in a polygonal mesh.

        This filter identifies and fills holes in the mesh by locating
        boundary edges, linking them together into loops, and then
        triangulating the resulting loops. A hole size threshold controls
        which holes are filled.

        It mirrors the PyVista ``fill_holes`` filter API and replicates
        the behavior of the vtk.js FillHolesFilter example.

        .. note::

            The hole filling is computed in JavaScript at render time by
            finding boundary edges (edges belonging to only one polygon),
            linking them into loops, and fan-triangulating each loop whose
            perimeter is smaller than ``hole_size``.

        Parameters
        ----------
        hole_size : float, optional
            The maximum hole size to fill, specified as the length of the
            perimeter of the hole. Holes with a perimeter larger than this
            value will not be filled. Default is 1000.0.

        Returns
        -------
        PolyData
            A new mesh with holes filled.

        Raises
        ------
        ValueError
            If ``hole_size`` is not positive.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> filled = sphere.fill_holes(hole_size=100.0)
        >>> isinstance(filled, pv.PolyData)
        True

        Create a sphere with a hole and fill it:

        >>> import pyvista_js as pv
        >>> import numpy as np
        >>> # Create a sphere with a hole by clipping
        >>> sphere = pv.Sphere(radius=1.0)
        >>> clipped_sphere = sphere.clip(normal='z', origin=(0, 0, 0.5))
        >>> # Fill the hole
        >>> filled_sphere = clipped_sphere.fill_holes(hole_size=10.0)
        >>> filled_sphere.plot()  # doctest: +SKIP

        Render the filled mesh:

        >>> filled.plot()  # doctest: +SKIP

        """
        if hole_size <= 0:
            msg = f"hole_size must be positive, got {hole_size}"
            raise ValueError(msg)

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        filters_list.append(
            {
                "type": "fillHoles",
                "holeSize": hole_size,
            },
        )

        return PolyData(
            points=self.points,
            faces=self.faces,
            _scene_data=base_scene,
        )

    def threshold(
        self,
        value: float | list[float] | tuple[float, float],
        scalars: str | ArrayLike | None = None,
        invert: bool = False,  # noqa: FBT001 FBT002
    ) -> PolyData:
        """Extract the parts of the mesh whose scalars are inside a range.

        This filter keeps the points (and any cells having at least one kept
        point) whose scalar value lies in the threshold range. It mirrors
        the PyVista ``threshold`` filter API and is backed by vtk.js's
        ``vtkThresholdPoints``.

        .. note::

            The thresholding is applied in JavaScript at render time.

        Parameters
        ----------
        value : float or list/tuple of float
            A single value thresholds in the range ``[value, max]``; a pair
            of values thresholds in the range ``[low, high]``.
        scalars : array-like, optional
            The scalar array used for thresholding. Default uses the
            ``scalars`` attribute of the mesh.
        invert : bool, optional
            If True, invert the threshold range. Default is False.

        Returns
        -------
        PolyData
            A new mesh with the thresholded subset.

        Raises
        ------
        ValueError
            If no scalar data is available or the value has the wrong size.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> sphere.point_data['data'] = sphere.points[:, 2]
        >>> thresh = sphere.threshold(0.5, scalars='data')
        >>> isinstance(thresh, pv.PolyData)
        True

        Render the thresholded mesh:

        >>> thresh.plot()  # doctest: +SKIP

        """
        scalar_data = self._get_threshold_scalars(scalars)
        scalar_min, scalar_max = float(scalar_data.min()), float(scalar_data.max())
        if scalar_min == scalar_max:
            scalar_max = scalar_min + 1.0
        if not isinstance(value, (list, tuple)):
            lower, upper = float(value), scalar_max
        else:
            if len(value) != _POINT_PAIR_LENGTH:
                msg = f"value must be a single float or a pair of floats, got {len(value)} values"
                raise ValueError(msg)
            lower, upper = float(value[0]), float(value[1])
        if invert:
            lower, upper = upper, lower

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        scalar_name = scalars if isinstance(scalars, str) else self.scalar_name
        filters_list.append(
            {
                "type": "threshold",
                "lowerValue": lower,
                "upperValue": upper,
                "scalarName": scalar_name,
            },
        )
        thresholded = PolyData(
            points=self.points,
            faces=self.faces,
            scalars=scalar_data,
            scalar_name=scalar_name,
            _scene_data=base_scene,
        )
        thresholded.point_data[scalar_name] = scalar_data
        return thresholded

    def _get_threshold_scalars(self, scalars: str | ArrayLike | None) -> np.ndarray:
        """Resolve the scalar array used for thresholding."""
        if isinstance(scalars, str):
            if scalars not in self._point_data:
                msg = f"No point data array named '{scalars}' found"
                raise ValueError(msg)
            return np.asarray(self._point_data[scalars])
        if scalars is not None:
            scalar_data = np.asarray(scalars)
            if scalar_data.ndim != 0 and len(scalar_data) != self.n_points:
                msg = f"scalars must have length {self.n_points}, got {scalar_data.ndim}"
                raise ValueError(msg)
            return scalar_data
        if self.scalars is not None:
            return self.scalars
        if len(self._point_data) > 0:
            first = next(iter(self._point_data.values()))
            return np.asarray(first)
        msg = "No scalar data provided. Pass scalars parameter or set mesh.scalars"
        raise ValueError(msg)

    def warp_by_scalar(
        self,
        scalars: str | ArrayLike | None = None,
        factor: float = 1.0,
    ) -> PolyData:
        """Displace the points along their normals weighted by the scalars.

        This mirrors the PyVista ``warp_by_scalar`` filter API and is backed
        by vtk.js's ``vtkWarpScalar``.

        .. note::

            The warp is applied in JavaScript at render time.

        Parameters
        ----------
        scalars : str or array-like, optional
            The scalar array used for the warp. Default uses the
            ``scalars`` attribute of the mesh.
        factor : float, optional
            Scaling factor applied to the scalar values. Default is 1.0.

        Returns
        -------
        PolyData
            A new mesh with warped points.

        Raises
        ------
        ValueError
            If no scalar data is available.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> sphere.point_data['data'] = sphere.points[:, 2]
        >>> warped = sphere.warp_by_scalar(scalars='data', factor=0.5)
        >>> isinstance(warped, pv.PolyData)
        True

        Render the warped mesh:

        >>> warped.plot()  # doctest: +SKIP

        """
        scalar_data = self._get_threshold_scalars(scalars)
        scalar_name = scalars if isinstance(scalars, str) else self.scalar_name

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        filters_list.append(
            {
                "type": "warpByScalar",
                "factor": float(factor),
                "scalarName": scalar_name,
            },
        )
        warped = PolyData(
            points=self.points,
            faces=self.faces,
            scalars=scalar_data,
            scalar_name=scalar_name,
            _scene_data=base_scene,
        )
        warped.point_data[scalar_name] = scalar_data
        return warped

    def smooth_taubin(
        self,
        pass_band: float = 0.001,
        n_iter: int = 15,
    ) -> PolyData:
        """Smooth the mesh surface using a Taubin smoothing filter.

        This mirrors the PyVista ``smooth_taubin`` filter API and is backed
        by vtk.js's ``vtkWindowedSincPolyDataFilter``. Taubin smoothing
        avoids the surface shrinkage of Laplacian smoothing.

        .. note::

            The smoothing is applied in JavaScript at render time.

        Parameters
        ----------
        pass_band : float, optional
            Pass band frequency for the smoothing filter. The closer to
            zero, the greater the smoothing effect. Default is 0.001.
        n_iter : int, optional
            Number of iterations for the smoothing filter.
            Default is 15.

        Returns
        -------
        PolyData
            A new mesh with smoothed points.

        Raises
        ------
        ValueError
            If ``n_iter`` is less than 1.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> smoothed = sphere.smooth_taubin(pass_band=0.001, n_iter=15)
        >>> isinstance(smoothed, pv.PolyData)
        True

        Render the smoothed mesh:

        >>> smoothed.plot()  # doctest: +SKIP

        """
        if n_iter < _MIN_SMOOTH_ITERATIONS:
            msg = f"n_iter must be at least {_MIN_SMOOTH_ITERATIONS}, got {n_iter}"
            raise ValueError(msg)

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        filters_list.append(
            {
                "type": "smoothTaubin",
                "passBand": float(pass_band),
                "nIterations": int(n_iter),
            },
        )
        return PolyData(
            points=self.points,
            faces=self.faces,
            scalars=self.scalars,
            scalar_name=self.scalar_name,
            _scene_data=base_scene,
        )

    def texture_map_to_plane(self) -> PolyData:
        """Generate texture coordinates by projecting points onto the XY plane.

        Maps the mesh's X and Y extents to UV coordinates in the [0, 1] range.
        This mirrors the PyVista :meth:`pyvista.DataSet.texture_map_to_plane` API.

        Returns
        -------
        PolyData
            A new mesh with texture coordinates (``t_coords``) set.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> mesh = pv.Sphere()
        >>> mapped = mesh.texture_map_to_plane()
        >>> mapped.t_coords is not None
        True
        >>> mapped.t_coords.shape == (mesh.n_points, 2)
        True

        """
        pts = self.points.astype(float)
        x_min, x_max = float(pts[:, 0].min()), float(pts[:, 0].max())
        y_min, y_max = float(pts[:, 1].min()), float(pts[:, 1].max())
        x_range = x_max - x_min or 1.0
        y_range = y_max - y_min or 1.0

        u = (pts[:, 0] - x_min) / x_range
        v = (pts[:, 1] - y_min) / y_range
        t_coords = np.column_stack([u, v])

        return PolyData(
            points=self.points,
            faces=self.faces,
            t_coords=t_coords,
            scalars=self.scalars,
            scalar_name=self.scalar_name,
            _scene_data=self._scene_data,
        )

    def texture_map_to_sphere(
        self,
        center: tuple[float, float, float] | None = None,
        prevent_seam: bool = True,  # noqa: ARG002, FBT001, FBT002
    ) -> PolyData:
        """Texture map a mesh to a sphere.

        This mirrors the PyVista ``texture_map_to_sphere`` filter API and
        is backed by vtk.js's ``vtkTextureMapToSphere`` used by the
        sphere source pipeline.

        .. note::

            The texture coordinates are computed in JavaScript at render
            time by mapping each point onto a sphere.

        Parameters
        ----------
        center : tuple, optional
            Center of the sphere used for the mapping. Default uses the
            center of the mesh's bounding sphere.
        prevent_seam : bool, optional
            If True, controls whether or not to prevent seam artifacts.
            Default is True.

        Returns
        -------
        PolyData
            A new mesh with sphere texture coordinates.

        Raises
        ------
        ValueError
            If ``center`` is provided with the wrong size.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> sphere = pv.Sphere()
        >>> textured = sphere.texture_map_to_sphere()
        >>> isinstance(textured, pv.PolyData)
        True

        Render the textured mesh:

        >>> textured.plot()  # doctest: +SKIP

        """
        mapped_center: tuple[float, float, float]
        if center is None:
            radius, sph_center = self.bounding_sphere
            mapped_center = sph_center
            mapped_radius = radius
        else:
            if len(center) != _VECTOR_COMPONENTS:
                msg = f"center must have {_VECTOR_COMPONENTS} components, got {len(center)}"
                raise ValueError(msg)
            mapped_center = (float(center[0]), float(center[1]), float(center[2]))
            mapped_radius = self.bounding_sphere[0]

        base_scene = (
            dict(self._scene_data)
            if self._scene_data
            else {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
        )
        base_scene.setdefault("filters", [])
        filters_list: list[object] = base_scene["filters"]  # type: ignore[assignment]
        filters_list.append(
            {
                "type": "textureSphere",
                "center": list(mapped_center),
                "radius": mapped_radius,
            },
        )
        return PolyData(
            points=self.points,
            faces=self.faces,
            scalars=self.scalars,
            scalar_name=self.scalar_name,
            _scene_data=base_scene,
        )

    def glyph(
        self,
        orient: bool | str = True,  # noqa: FBT001, FBT002
        scale: bool | str = True,  # noqa: FBT001, FBT002
        factor: float = 1.0,
        geometry: PolyData | None = None,
    ) -> PolyData:
        """Glyph the mesh points with per-point geometry.

        This mirrors the PyVista ``glyph`` filter API: a point cloud is
        rendered with per-point arrows (by default) oriented and scaled by
        point vectors using vtk.js's ``vtkGlyph3DMapper`` at render time.

        .. note::

            The glyphing happens in JavaScript at render time. This method
            only serializes the configuration.

        Parameters
        ----------
        orient : bool or str, optional
            Whether to orient glyphs by the ``'vectors'`` point array.
            A string names the array to use. An array of 3 components gives
            each glyph a direction; one of 9 gives it a full 3x3 rotation,
            stored in column-major order as vtk.js reads it, such as
            ``rotations.transpose(0, 2, 1).reshape(-1, 9)`` for an
            ``(n_points, 3, 3)`` array of rotation matrices. Default is True.
        scale : bool or str, optional
            Whether to scale glyphs. A string names the point array whose
            magnitude scales each glyph, such as a one-component array of
            sizes. Default is True.
        factor : float, optional
            Scale factor applied to the glyphs. Default is 1.0.
        geometry : PolyData, optional
            Geometry to use for each glyph. Default uses an arrow
            (matching the PyVista default).

        Returns
        -------
        PolyData
            A mesh configured for glyph rendering.

        Raises
        ------
        ValueError
            If ``orient`` is set but the vectors array is missing or has a
            mismatched length or a number of components other than 3 or 9,
            or ``scale`` names a missing array.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> import numpy as np
        >>> mesh = pv.PolyData(points=np.zeros((4, 3)))
        >>> mesh.point_data['vectors'] = np.ones((4, 3))
        >>> glyphed = mesh.glyph()
        >>> glyphed.to_scene_data()['type']
        'glyph'

        Render the glyphs:

        >>> glyphed.plot()  # doctest: +SKIP

        """
        orientation_array = self._glyph_orientation_array(orient=orient, scale=scale)
        if factor < 0:
            msg = f"factor must be non-negative, got {factor}"
            raise ValueError(msg)

        scene: dict[str, object] = {
            "type": "glyph",
            "points": _Float32Array(self.points),
            "scaleFactor": float(factor),
            "orient": True,
            "orientationArray": orientation_array,
        }
        if isinstance(scale, str):
            scene["scaleArray"] = scale
        if geometry is not None:
            scene["geometryPoints"] = _Float32Array(geometry.points)
            flat_polys: list[float] = []
            for cell in geometry._iter_face_cells():  # noqa: SLF001
                flat_polys.extend([float(len(cell)), *(int(c) for c in cell)])
            scene["geometryPolys"] = flat_polys

        glyphed = PolyData(points=self.points, _scene_data=scene)
        # all of them, so a scale or color array reaches the page too
        for name, array in self._point_data.items():
            glyphed.point_data[name] = array
        return glyphed

    def _glyph_orientation_array(self, *, orient: bool | str, scale: bool | str) -> str:
        """Check the arrays that glyph() orients and scales by, returning the first's name."""
        if orient in (False, None):
            msg = "Orienting glyphs requires a 'vectors' or named vector array"
            raise ValueError(msg)
        if orient is not True and not isinstance(orient, str):
            msg = "orient must be a bool or a string naming the vector array"
            raise ValueError(msg)
        name = orient if isinstance(orient, str) else "vectors"
        for array_name in (name, scale):
            if isinstance(array_name, str) and array_name not in self._point_data:
                msg = f"No point data array named '{array_name}' found"
                raise ValueError(msg)
        n_components = np.asarray(self._point_data[name]).reshape(self.n_points, -1).shape[1]
        if n_components not in (3, 9):
            msg = f"'{name}' must have 3 or 9 components, got {n_components}"
            raise ValueError(msg)
        return name

    def to_scene_data(self) -> dict[str, object]:
        """Return a JSON-serializable dict describing this mesh source.

        Returns
        -------
        dict
            Source configuration with ``"type"`` key and type-specific parameters.

        """
        return _plain_scene(self._to_scene_data())  # type: ignore[return-value]

    def _to_scene_data(self) -> dict[str, object]:
        """Return the source description, with float arrays as ``_Float32Array``.

        Serialize it with ``_dumps_scene``.

        """
        if self._scene_data is not None:
            data: dict[str, object] = dict(self._scene_data)
        else:
            data = {
                "type": "mesh",
                "points": _Float32Array(self.points),
            }
            if self.faces is not None:
                data["polys"] = self.faces.tolist()

        # Inject texture coordinates
        if self.t_coords is not None:
            data["tCoords"] = _Float32Array(self.t_coords)

        # Inject point data arrays
        if len(self._point_data) > 0:
            data["pointData"] = _point_data_to_scene(self._point_data)

        return data

    def __getstate__(self) -> dict[str, object]:
        """Return state for pickling.

        Returns
        -------
        dict
            State dictionary containing points, faces, texture coordinates,
            point data, and scene data.

        """
        return {
            "points": self.points,
            "faces": self.faces,
            "t_coords": self.t_coords,
            "_point_data": self._point_data,
            "_scene_data": self._scene_data,
        }

    def __setstate__(self, state: dict[str, object]) -> None:
        """Restore state from pickle.

        Parameters
        ----------
        state : dict
            State dictionary from __getstate__.

        """
        self.points = state["points"]  # type: ignore[assignment]
        self.faces = state["faces"]  # type: ignore[assignment]
        self.t_coords = state["t_coords"]  # type: ignore[assignment]
        self._point_data = state["_point_data"]  # type: ignore[assignment]
        self._scene_data = state.get("_scene_data")  # type: ignore[assignment]


class ImageData:
    """Uniformly spaced image (structured mesh) dataset.

    Mirrors the PyVista ``ImageData`` class backed by
    ``vtk.Common.DataModel.vtkImageData`` at render time.

    Parameters
    ----------
    dimensions : tuple, optional
        Number of points in each (x, y, z) direction. Default is (1, 1, 1).
    spacing : tuple, optional
        Distance between points in each direction. Default is (1, 1, 1).
    origin : tuple, optional
        World coordinates of the (0, 0, 0) corner. Default is (0, 0, 0).

    Examples
    --------
    >>> import pyvista_js as pv
    >>> grid = pv.ImageData(dimensions=(8, 8, 8), spacing=(1, 1, 1))
    >>> grid.n_points
    512

    """

    def __init__(
        self,
        dimensions: tuple[int, int, int] = (1, 1, 1),
        spacing: tuple[float, float, float] = (1.0, 1.0, 1.0),
        origin: tuple[float, float, float] = (0.0, 0.0, 0.0),
    ) -> None:
        """Initialize the image data."""
        if any(dim < 1 for dim in dimensions):
            msg = f"dimensions must be at least 1 in each direction, got {dimensions}"
            raise ValueError(msg)
        self.dimensions = tuple(int(dim) for dim in dimensions)
        self.spacing = tuple(float(s) for s in spacing)
        self.origin = tuple(float(o) for o in origin)
        self._point_data = PointData()

    @property
    def point_data(self) -> PointData:
        """Access point data arrays.

        Returns
        -------
        PointData
            Dict-like container for point data arrays.

        Examples
        --------
        >>> import numpy as np
        >>> import pyvista_js as pv
        >>> grid = pv.ImageData(dimensions=(4, 4, 4))
        >>> grid.point_data['data'] = np.zeros(grid.n_points)
        >>> 'data' in grid.point_data
        True

        """
        return self._point_data

    @property
    def n_points(self) -> int:
        """Return the total number of points."""
        return int(np.prod(self.dimensions))

    @property
    def n_cells(self) -> int:
        """Return the total number of cells."""
        cells = [dim - 1 for dim in self.dimensions]
        return int(np.prod([max(cell, 0) for cell in cells]))

    @property
    def points(self) -> np.ndarray:
        """Return the point coordinates of the image.

        Returns
        -------
        np.ndarray
            Points array with shape ``(n_points, 3)``.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> grid = pv.ImageData(dimensions=(2, 2, 2))
        >>> grid.points.tolist()  # doctest: +NORMALIZE_WHITESPACE
        [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [1.0, 1.0, 0.0],
         [0.0, 0.0, 1.0], [1.0, 0.0, 1.0], [0.0, 1.0, 1.0], [1.0, 1.0, 1.0]]

        """
        n_x, n_y, n_z = self.dimensions
        d_x, d_y, d_z = self.spacing
        o_x, o_y, o_z = self.origin
        points = [
            [o_x + i * d_x, o_y + j * d_y, o_z + k * d_z]
            for k in range(n_z)
            for j in range(n_y)
            for i in range(n_x)
        ]
        return np.array(points)

    def to_scene_data(self) -> dict[str, object]:
        """Return a JSON-serializable dict describing this image.

        Returns
        -------
        dict
            Source configuration with ``"type": "image"``.

        """
        scene: dict[str, object] = {
            "type": "image",
            "dimensions": list(self.dimensions),
            "spacing": list(self.spacing),
            "origin": list(self.origin),
        }
        if len(self._point_data) > 0:
            scene["pointData"] = _point_data_to_scene(self._point_data)
        return scene

    def __getstate__(self) -> dict[str, object]:
        """Return state for pickling."""
        return {
            "dimensions": self.dimensions,
            "spacing": self.spacing,
            "origin": self.origin,
            "_point_data": self._point_data,
        }

    def __setstate__(self, state: dict[str, object]) -> None:
        """Restore state from pickle."""
        self.dimensions = state["dimensions"]  # type: ignore[assignment]
        self.spacing = state["spacing"]  # type: ignore[assignment]
        self.origin = state["origin"]  # type: ignore[assignment]
        self._point_data = state["_point_data"]  # type: ignore[assignment]

    def plot(self, color: str | tuple[float, float, float] | None = None) -> None:
        """Plot this image as an outline.

        This is a convenience method that creates a :class:`~pyvista_js.Plotter`,
        adds this image, and calls :func:`~pyvista_js.Plotter.show`.

        Parameters
        ----------
        color : str or tuple, optional
            Color of the image outline.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> grid = pv.ImageData(dimensions=(4, 4, 4))
        >>> grid.plot(color='red')  # doctest: +SKIP

        """
        from .plotter import Plotter  # noqa: PLC0415

        plotter = Plotter()
        plotter.add_image(self, color=color)
        plotter.show()


class UnstructuredGrid:
    """Unstructured grid dataset.

    An unstructured grid can hold cells of arbitrary type (tetrahedra,
    hexahedra, wedges, pyramids, triangles, quads, etc.).  This class
    mirrors the :class:`pyvista.UnstructuredGrid` constructor API.

    For rendering in vtk.js the 3-D cells are decomposed into their
    surface faces so that they can be displayed as polygonal geometry.

    Parameters
    ----------
    cells : array-like
        Cell connectivity in VTK format:
        ``[n_pts0, p0, p1, ..., n_pts1, p0, p1, ...]``.
    celltypes : array-like
        Array of VTK cell type constants (see :class:`CellType`) - one
        value per cell.
    points : array-like
        Vertex coordinates as an ``(n, 3)`` array.

    Examples
    --------
    Create a single tetrahedron:

    >>> import pyvista_js as pv
    >>> import numpy as np
    >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
    >>> cells = [4, 0, 1, 2, 3]
    >>> celltypes = [pv.CellType.TETRA]
    >>> grid = pv.UnstructuredGrid(cells, celltypes, points)
    >>> grid.n_points
    4
    >>> grid.n_cells
    1

    Create a hexahedron (cube):

    >>> import pyvista_js as pv
    >>> import numpy as np
    >>> points = np.array([
    ...     [0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0],  # bottom face
    ...     [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1],  # top face
    ... ], dtype=float)
    >>> cells = [8, 0, 1, 2, 3, 4, 5, 6, 7]
    >>> celltypes = [pv.CellType.HEXAHEDRON]
    >>> grid = pv.UnstructuredGrid(cells, celltypes, points)
    >>> grid.n_points
    8
    >>> grid.n_cells
    1

    Create a mixed mesh with multiple cell types:

    >>> import pyvista_js as pv
    >>> import numpy as np
    >>> # Triangle and quad cells
    >>> points = np.array([
    ...     [0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0],  # vertices
    ... ], dtype=float)
    >>> cells = [3, 0, 1, 2, 4, 1, 2, 3, 0]  # triangle, quad
    >>> celltypes = [pv.CellType.TRIANGLE, pv.CellType.QUAD]
    >>> grid = pv.UnstructuredGrid(cells, celltypes, points)
    >>> grid.n_cells
    2

    Access point data:

    >>> import pyvista_js as pv
    >>> import numpy as np
    >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
    >>> grid = pv.UnstructuredGrid([4, 0, 1, 2, 3], [pv.CellType.TETRA], points)
    >>> grid['temperature'] = np.array([20.0, 25.0, 22.0, 24.0])
    >>> grid['temperature']
    array([20., 25., 22., 24.])

    Plot the grid:

    >>> import pyvista_js as pv
    >>> import numpy as np
    >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
    >>> grid = pv.UnstructuredGrid([4, 0, 1, 2, 3], [pv.CellType.TETRA], points)
    >>> grid.plot()  # doctest: +SKIP

    """

    def __init__(
        self,
        cells: ArrayLike,
        celltypes: ArrayLike,
        points: ArrayLike,
    ) -> None:
        """Initialize an UnstructuredGrid."""
        self.points = np.asarray(points, dtype=float)
        self.cells = np.asarray(cells)
        self.celltypes = np.asarray(celltypes)
        self._point_data = PointData()
        self._scene_data: dict[str, Any] | None = None

    @property
    def point_data(self) -> PointData:
        """Access point data arrays.

        Returns
        -------
        PointData
            Dict-like container for point data arrays.

        """
        return self._point_data

    def __setitem__(self, name: str, array: ArrayLike) -> None:
        """Set a point data array using dictionary-style access.

        Parameters
        ----------
        name : str
            Name of the array.
        array : array-like
            Data array to store.

        Examples
        --------
        >>> import numpy as np
        >>> import pyvista_js as pv
        >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
        >>> grid = pv.UnstructuredGrid([4, 0, 1, 2, 3], [pv.CellType.TETRA], points)
        >>> # Set temperature data
        >>> grid['temperature'] = np.array([20.0, 25.0, 22.0, 24.0])
        >>> # Set vector data
        >>> grid['velocity'] = np.array(
        ...     [[0, 0, 1], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float
        ... )

        """
        self._point_data[name] = array

    def __getitem__(self, name: str) -> np.ndarray:
        """Get a point data array using dictionary-style access.

        Parameters
        ----------
        name : str
            Name of the array.

        Returns
        -------
        np.ndarray
            The requested array.

        Examples
        --------
        >>> import numpy as np
        >>> import pyvista_js as pv
        >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
        >>> grid = pv.UnstructuredGrid([4, 0, 1, 2, 3], [pv.CellType.TETRA], points)
        >>> grid['temperature'] = np.array([20.0, 25.0, 22.0, 24.0])
        >>> grid['temperature']
        array([20., 25., 22., 24.])
        >>> # Get vector data
        >>> grid['velocity'] = np.array([[0, 0, 1], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
        >>> grid['velocity'].shape
        (4, 3)

        """
        return self._point_data[name]

    @property
    def n_points(self) -> int:
        """Return the number of points.

        Returns
        -------
        int
            Number of points in the grid.

        Examples
        --------
        >>> import numpy as np
        >>> import pyvista_js as pv
        >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
        >>> grid = pv.UnstructuredGrid([4, 0, 1, 2, 3], [pv.CellType.TETRA], points)
        >>> grid.n_points
        4

        """
        return len(self.points)

    @property
    def n_cells(self) -> int:
        """Return the number of cells.

        Returns
        -------
        int
            Number of cells in the grid.

        Examples
        --------
        >>> import numpy as np
        >>> import pyvista_js as pv
        >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
        >>> grid = pv.UnstructuredGrid([4, 0, 1, 2, 3], [pv.CellType.TETRA], points)
        >>> grid.n_cells
        1

        >>> # Multiple cells
        >>> import numpy as np
        >>> import pyvista_js as pv
        >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
        >>> cells = [3, 0, 1, 2, 4, 1, 2, 3, 0]  # triangle + quad
        >>> celltypes = [pv.CellType.TRIANGLE, pv.CellType.QUAD]
        >>> grid = pv.UnstructuredGrid(cells, celltypes, points[:4])
        >>> grid.n_cells
        2

        """
        return len(self.celltypes)

    @property
    def bounding_sphere(self) -> tuple[float, tuple[float, float, float]]:
        """Compute the radius and center of a bounding sphere.

        Uses Ritter's algorithm to approximate the minimum bounding sphere.
        Returns NaN values if there are no points.

        Returns
        -------
        float, tuple
            Sphere radius as a float and center as a tuple of floats ``(x, y, z)``.

        """
        if self.n_points == 0:
            nan = float("nan")
            return nan, (nan, nan, nan)

        pts = self.points.astype(float)

        p = pts[0]
        dists = np.linalg.norm(pts - p, axis=1)
        q = pts[np.argmax(dists)]
        dists = np.linalg.norm(pts - q, axis=1)
        r = pts[np.argmax(dists)]

        center = (q + r) / 2.0
        radius = float(np.linalg.norm(r - q) / 2.0)

        for pt in pts:
            d = float(np.linalg.norm(pt - center))
            if d > radius:
                radius = (radius + d) / 2.0
                center = center + (d - radius) / d * (pt - center)

        return radius, (float(center[0]), float(center[1]), float(center[2]))

    def _extract_surface_polys(self) -> list[int]:
        """Extract surface faces from cells as a flat VTK polys array.

        Returns
        -------
        list[int]
            Flat list in VTK cell-array format:
            ``[n0, p0, p1, ..., n1, p0, p1, ...]``.

        """
        # Face definitions per cell type (local point indices)
        _TETRA_FACES = (  # noqa: N806
            (0, 1, 2),
            (0, 3, 1),
            (1, 3, 2),
            (0, 2, 3),
        )
        _HEX_FACES = (  # noqa: N806
            (0, 3, 2, 1),
            (4, 5, 6, 7),
            (0, 1, 5, 4),
            (2, 3, 7, 6),
            (0, 4, 7, 3),
            (1, 2, 6, 5),
        )
        _WEDGE_FACES = (  # noqa: N806
            (0, 1, 2),
            (3, 5, 4),
            (0, 3, 4, 1),
            (1, 4, 5, 2),
            (0, 2, 5, 3),
        )
        _PYRAMID_FACES = (  # noqa: N806
            (0, 3, 2, 1),
            (0, 1, 4),
            (1, 2, 4),
            (2, 3, 4),
            (3, 0, 4),
        )

        polys: list[int] = []
        idx = 0
        cells = self.cells
        for cell_type in self.celltypes:
            n_pts = int(cells[idx])
            pts = cells[idx + 1 : idx + 1 + n_pts]
            idx += n_pts + 1

            face_defs: tuple[tuple[int, ...], ...]
            if cell_type == _CELL_TYPE_TETRA:
                face_defs = _TETRA_FACES
            elif cell_type == _CELL_TYPE_HEXAHEDRON:
                face_defs = _HEX_FACES
            elif cell_type == _CELL_TYPE_WEDGE:
                face_defs = _WEDGE_FACES
            elif cell_type == _CELL_TYPE_PYRAMID:
                face_defs = _PYRAMID_FACES
            elif cell_type == _CELL_TYPE_TRIANGLE:
                face_defs = ((0, 1, 2),)
            elif cell_type == _CELL_TYPE_QUAD:
                face_defs = ((0, 1, 2, 3),)
            else:
                continue

            for face in face_defs:
                polys.append(len(face))
                polys.extend(int(pts[i]) for i in face)

        return polys

    def plot(
        self,
        color: str | tuple[float, float, float] | None = None,
        opacity: float = 1.0,
        pbr: bool = False,  # noqa: FBT001 FBT002
        metallic: float = 0.0,
        roughness: float = 0.5,
    ) -> None:
        """Plot this grid.

        This is a convenience method that creates a :class:`~pyvista_js.Plotter`,
        adds this grid, and calls :func:`~pyvista_js.Plotter.show`.

        Parameters
        ----------
        color : str or tuple, optional
            Color of the mesh.
        opacity : float, optional
            Opacity, between 0 and 1. Default is 1.
        pbr : bool, optional
            Enable physically based rendering. Default is False.
        metallic : float, optional
            Metallic factor for PBR. Default is 0.0.
        roughness : float, optional
            Roughness factor for PBR. Default is 0.5.

        Examples
        --------
        >>> import pyvista_js as pv
        >>> import numpy as np
        >>> points = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
        >>> grid = pv.UnstructuredGrid([4, 0, 1, 2, 3], [pv.CellType.TETRA], points)
        >>> grid.plot()  # doctest: +SKIP

        """
        from .plotter import Plotter  # noqa: PLC0415

        plotter = Plotter()
        plotter.add_mesh(
            self,
            color=color,
            opacity=opacity,
            pbr=pbr,
            metallic=metallic,
            roughness=roughness,
        )
        plotter.show()

    def to_scene_data(self) -> dict[str, object]:
        """Return a JSON-serializable dict describing this grid.

        The 3-D cells are decomposed into their surface polygons so that
        they can be rendered as a ``"mesh"`` source in vtk.js.

        Returns
        -------
        dict
            Source configuration with ``"type": "mesh"``.

        """
        return _plain_scene(self._to_scene_data())  # type: ignore[return-value]

    def _to_scene_data(self) -> dict[str, object]:
        """Return the grid description, with float arrays as ``_Float32Array``.

        Serialize it with ``_dumps_scene``.

        """
        if self._scene_data is not None:
            data: dict[str, object] = dict(self._scene_data)
        else:
            polys = self._extract_surface_polys()
            data = {
                "type": "mesh",
                "points": _Float32Array(self.points),
                "polys": polys,
            }

        # Inject point data arrays
        if len(self._point_data) > 0:
            data["pointData"] = _point_data_to_scene(self._point_data)

        return data


class _VolumeImageData(ImageData):
    """Image rendered as a volume (used internally by ``add_volume``)."""

    def __init__(
        self,
        image: ImageData,
        scalars_name: str,
        cmap: str,
    ) -> None:
        """Initialize from an image with the scalar settings to render."""
        super().__init__(
            dimensions=(image.dimensions[0], image.dimensions[1], image.dimensions[2]),
            spacing=(image.spacing[0], image.spacing[1], image.spacing[2]),
            origin=(image.origin[0], image.origin[1], image.origin[2]),
        )
        self._point_data = image._point_data  # noqa: SLF001
        self._scalars_name = scalars_name
        self._cmap = cmap

    def to_scene_data(self) -> dict[str, object]:
        """Return the volume scene configuration."""
        scalar_data = np.asarray(self._point_data[self._scalars_name])
        scene = super().to_scene_data()
        scene["type"] = "imageVolume"
        scene["scalars"] = {
            "arrayName": self._scalars_name,
            "cmap": self._cmap,
            "range": [float(scalar_data.min()), float(scalar_data.max())],
            "direct": False,
        }
        return scene


def _scene_source(mesh: object) -> dict[str, object]:
    """Return a mesh's scene source, for serializing with ``_dumps_scene``.

    Meshes that use the built-in ``to_scene_data`` give the compact form with
    ``_Float32Array`` values. A mesh whose class overrides the public
    ``to_scene_data`` gets that override, as before the compact form existed.

    Parameters
    ----------
    mesh : object
        The mesh.

    Returns
    -------
    dict
        The source configuration.

    """
    if getattr(type(mesh), "to_scene_data", None) in _COMPACT_TO_SCENE_DATA:
        return mesh._to_scene_data()  # type: ignore[attr-defined, no-any-return]  # noqa: SLF001
    return mesh.to_scene_data()  # type: ignore[attr-defined, no-any-return]


def _has_plain_points(mesh: object) -> bool:
    """Return whether pages build the mesh from its points, so they can be replaced in place.

    Parameters
    ----------
    mesh : object
        The mesh.

    Returns
    -------
    bool
        False for meshes given by a source, filter, reader, or custom ``to_scene_data``.

    """
    cls = type(mesh)
    return (
        getattr(mesh, "_scene_data", True) is None
        and getattr(cls, "to_scene_data", None) in _COMPACT_TO_SCENE_DATA
        and getattr(cls, "_to_scene_data", None) in _PLAIN_TO_SCENE_DATA
    )


_COMPACT_TO_SCENE_DATA = (PolyData.to_scene_data, UnstructuredGrid.to_scene_data)
_PLAIN_TO_SCENE_DATA = (PolyData._to_scene_data, UnstructuredGrid._to_scene_data)  # noqa: SLF001


def Sphere(  # noqa: N802
    radius: float = 1.0,
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    theta_resolution: int = 30,
    phi_resolution: int = 30,
) -> PolyData:
    """Create a sphere mesh.

    Parameters
    ----------
    radius : float, optional
        Sphere radius. Default is 1.0.
    center : tuple, optional
        Center of the sphere (x, y, z). Default is (0, 0, 0).
    theta_resolution : int, optional
        Number of points in the azimuthal direction. Default is 30.
    phi_resolution : int, optional
        Number of points in the polar direction. Default is 30.

    Returns
    -------
    PolyData
        A sphere mesh.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> sphere = pv.Sphere(radius=1.0)
    >>> sphere.n_points
    842

    """
    # Generate points matching vtk.js vtkSphereSource ordering exactly:
    #   index 0: north pole
    #   index 1: south pole
    #   then theta (outer) x phi (inner) for intermediate rows
    # phi[j] = j * pi / (phi_resolution - 1)  for j = 1 .. phi_resolution-2
    # theta[i] = i * 2*pi / theta_resolution   for i = 0 .. theta_resolution-1
    delta_phi = np.pi / (phi_resolution - 1)
    delta_theta = 2.0 * np.pi / theta_resolution

    points = []
    # North pole (index 0)
    points.append([center[0], center[1], center[2] + radius])
    # South pole (index 1)
    points.append([center[0], center[1], center[2] - radius])
    # Intermediate points: theta outer loop, phi inner loop
    for i in range(theta_resolution):
        theta = i * delta_theta
        for j in range(1, phi_resolution - 1):
            phi = j * delta_phi
            x = radius * np.sin(phi) * np.cos(theta) + center[0]
            y = radius * np.sin(phi) * np.sin(theta) + center[1]
            z = radius * np.cos(phi) + center[2]
            points.append([x, y, z])

    return PolyData(
        points=np.array(points),
        _scene_data={
            "type": "sphere",
            "center": list(center),
            "radius": radius,
            "thetaResolution": theta_resolution,
            "phiResolution": phi_resolution,
        },
    )


def Cube(  # noqa: N802
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    x_length: float = 1.0,
    y_length: float = 1.0,
    z_length: float = 1.0,
) -> PolyData:
    """Create a cube mesh.

    Parameters
    ----------
    center : tuple, optional
        Center of the cube (x, y, z). Default is (0, 0, 0).
    x_length : float, optional
        Length in x direction. Default is 1.0.
    y_length : float, optional
        Length in y direction. Default is 1.0.
    z_length : float, optional
        Length in z direction. Default is 1.0.

    Returns
    -------
    PolyData
        A cube mesh.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> cube = pv.Cube()
    >>> cube.n_points
    24

    """
    x, y, z = center
    dx, dy, dz = x_length / 2, y_length / 2, z_length / 2

    # Generate 24 points matching vtk.js vtkCubeSource ordering:
    # 4 points per face, 6 faces (3 axis pairs), each corner duplicated 3x with face normal.
    # Block 1 - X-facing faces (i=0: -hx face, i=1: +hx face), inner order: j(y), k(z)
    # Block 2 - Y-facing faces (i=0: -hy face, i=1: +hy face), inner order: j(x), k(z)
    # Block 3 - Z-facing faces (i=0: -hz face, i=1: +hz face), inner order: j(y), k(x)
    px = [x - dx, x + dx]
    py = [y - dy, y + dy]
    pz = [z - dz, z + dz]
    points = np.array(
        [
            # Block 1: X-facing faces
            [px[0], py[0], pz[0]],
            [px[0], py[0], pz[1]],
            [px[0], py[1], pz[0]],
            [px[0], py[1], pz[1]],
            [px[1], py[0], pz[0]],
            [px[1], py[0], pz[1]],
            [px[1], py[1], pz[0]],
            [px[1], py[1], pz[1]],
            # Block 2: Y-facing faces
            [px[0], py[0], pz[0]],
            [px[0], py[0], pz[1]],
            [px[1], py[0], pz[0]],
            [px[1], py[0], pz[1]],
            [px[0], py[1], pz[0]],
            [px[0], py[1], pz[1]],
            [px[1], py[1], pz[0]],
            [px[1], py[1], pz[1]],
            # Block 3: Z-facing faces
            [px[0], py[0], pz[0]],
            [px[1], py[0], pz[0]],
            [px[0], py[1], pz[0]],
            [px[1], py[1], pz[0]],
            [px[0], py[0], pz[1]],
            [px[1], py[0], pz[1]],
            [px[0], py[1], pz[1]],
            [px[1], py[1], pz[1]],
        ],
    )

    faces = np.array(
        [
            [0, 1, 2, 3],  # Bottom
            [4, 5, 6, 7],  # Top
            [0, 1, 5, 4],  # Front
            [2, 3, 7, 6],  # Back
            [0, 3, 7, 4],  # Left
            [1, 2, 6, 5],  # Right
        ],
    )

    return PolyData(
        points=points,
        faces=faces,
        _scene_data={
            "type": "cube",
            "xLength": x_length,
            "yLength": y_length,
            "zLength": z_length,
        },
    )


def Cylinder(  # noqa: N802
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    direction: tuple[float, float, float] = (1.0, 0.0, 0.0),  # noqa: ARG001
    radius: float = 0.5,
    height: float = 1.0,
    resolution: int = 100,
) -> PolyData:
    """Create a cylinder mesh.

    Parameters
    ----------
    center : tuple, optional
        Center of the cylinder (x, y, z). Default is (0, 0, 0).
    direction : tuple, optional
        Direction vector of the cylinder axis. Default is (1, 0, 0).
    radius : float, optional
        Radius of the cylinder. Default is 0.5.
    height : float, optional
        Height of the cylinder. Default is 1.0.
    resolution : int, optional
        Number of points around the cylinder. Default is 100.

    Returns
    -------
    PolyData
        A cylinder mesh.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> cylinder = pv.Cylinder(radius=1.0, height=2.0)

    """
    # Generate points matching vtk.js vtkCylinderSource ordering (capping=true default):
    # Cylinder axis is Y. Total = 4 * resolution points:
    #   indices 0..2R-1:   side wall, interleaved pairs [y=+h/2, y=-h/2] per angle step
    #   indices 2R..3R-1:  top cap ring at y=+h/2, forward angular order
    #   indices 3R..4R-1:  bottom cap ring at y=-h/2, REVERSED angular order
    # x = radius*cos(i*angle), z = -radius*sin(i*angle) (vtk.js uses -sin for z)
    angle = 2.0 * np.pi / resolution
    cx, cy, cz = center
    points_list = []
    # Side wall
    for i in range(resolution):
        px = radius * np.cos(i * angle) + cx
        pz = -radius * np.sin(i * angle) + cz
        points_list.append([px, cy + height / 2, pz])  # y = +h/2
        points_list.append([px, cy - height / 2, pz])  # y = -h/2
    # Top cap (forward order, y = +h/2)
    points_list.extend(
        [radius * np.cos(i * angle) + cx, cy + height / 2, -radius * np.sin(i * angle) + cz]
        for i in range(resolution)
    )
    # Bottom cap (reversed order, y = -h/2)
    points_list.extend(
        [
            radius * np.cos((resolution - 1 - k) * angle) + cx,
            cy - height / 2,
            -radius * np.sin((resolution - 1 - k) * angle) + cz,
        ]
        for k in range(resolution)
    )
    points = np.array(points_list)

    return PolyData(
        points=points,
        _scene_data={
            "type": "cylinder",
            "height": height,
            "radius": radius,
            "resolution": resolution,
        },
    )


def Disc(  # noqa: N802, PLR0913
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    inner: float = 0.25,
    outer: float = 0.5,
    normal: tuple[float, float, float] = (0.0, 0.0, 1.0),
    r_res: int = 1,
    c_res: int = 6,
) -> PolyData:
    """Create a disc (annular ring) geometric primitive.

    This mirrors the :func:`pyvista.Disc` API.  The geometry is built
    directly from ``(r_res + 1)`` rings of ``c_res`` points each, connected
    as triangles, so it renders correctly in vtk.js without depending on any
    specific vtk.js source filter.

    Parameters
    ----------
    center : tuple, optional
        Center of the disc (x, y, z). Default is (0, 0, 0).
    inner : float, optional
        Inner radius of the disc. Default is 0.25.
    outer : float, optional
        Outer radius of the disc. Default is 0.5.
    normal : tuple, optional
        Normal vector of the disc. Default is (0, 0, 1).
    r_res : int, optional
        Number of radial subdivisions. Default is 1.
    c_res : int, optional
        Number of circumferential subdivisions. Default is 6.

    Returns
    -------
    PolyData
        A disc (annular ring) mesh.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> disc = pv.Disc(center=(0, 0, 0), inner=0.25, outer=0.5)
    >>> disc.n_points
    12

    >>> disc.plot()  # doctest: +SKIP

    """
    # Generate points matching vtk.js vtkDiskSource ordering:
    # outer loop circumferential (i), inner loop radial (j)
    # point index = i * (r_res + 1) + j
    theta_step = 2.0 * np.pi / c_res
    delta_r = (outer - inner) / r_res
    pts_list = []
    for i in range(c_res):
        theta = i * theta_step
        cos_t = np.cos(theta)
        sin_t = np.sin(theta)
        for j in range(r_res + 1):
            r = inner + j * delta_r
            pts_list.append([r * cos_t, r * sin_t, 0.0])
    pts = np.array(pts_list)

    # Build triangular faces: two triangles per quad between adjacent rings
    faces = []
    for i in range(c_res):
        next_i = (i + 1) % c_res
        for j in range(r_res):
            p0 = i * (r_res + 1) + j
            p1 = p0 + 1
            p2 = next_i * (r_res + 1) + j + 1
            p3 = p2 - 1
            faces.append([p0, p1, p2])
            faces.append([p0, p2, p3])

    # Rotate from default normal (0,0,1) to requested normal
    n = np.asarray(normal, dtype=float)
    n = n / np.linalg.norm(n)
    z = np.array([0.0, 0.0, 1.0])
    if not np.allclose(n, z):
        if np.allclose(n, -z):
            pts[:, 2] = -pts[:, 2]
        else:
            axis = np.cross(z, n)
            axis = axis / np.linalg.norm(axis)
            angle = np.arccos(np.clip(np.dot(z, n), -1.0, 1.0))
            c, s = np.cos(angle), np.sin(angle)
            t_val = 1.0 - c
            ax, ay, az = axis
            rot = np.array(
                [
                    [t_val * ax * ax + c, t_val * ax * ay - s * az, t_val * ax * az + s * ay],
                    [t_val * ax * ay + s * az, t_val * ay * ay + c, t_val * ay * az - s * ax],
                    [t_val * ax * az - s * ay, t_val * ay * az + s * ax, t_val * az * az + c],
                ],
            )
            pts = pts @ rot.T

    pts += np.asarray(center, dtype=float)

    return PolyData(
        points=pts,
        faces=np.array(faces) if faces else None,
        _scene_data={
            "type": "disk",
            "innerRadius": inner,
            "outerRadius": outer,
            "resolution": c_res,
        },
    )


def Circle(  # noqa: N802
    radius: float = 0.5,
    resolution: int = 100,
) -> PolyData:
    """Create a circle defined by a set of points in the XY plane.

    This mirrors the :func:`pyvista.Circle` API, producing a closed polygon
    outline of ``resolution`` points lying in the XY plane.

    Parameters
    ----------
    radius : float, optional
        Radius of the circle. Default is 0.5.
    resolution : int, optional
        Number of points on the circle. Default is 100.

    Returns
    -------
    PolyData
        A circle mesh (closed polyline in the XY plane).

    Examples
    --------
    >>> import pyvista_js as pv
    >>> circle = pv.Circle(radius=1.0)
    >>> circle.n_points
    101

    >>> circle.plot(color="black")  # doctest: +SKIP

    """
    if resolution < _CIRCLE_MIN_RESOLUTION:
        msg = f"resolution must be >= {_CIRCLE_MIN_RESOLUTION}, got {resolution}"
        raise ValueError(msg)

    theta = np.linspace(0, 2 * np.pi, resolution, endpoint=False)
    points = np.column_stack([radius * np.cos(theta), radius * np.sin(theta), np.zeros(resolution)])
    # Close the loop by appending the first point
    points = np.vstack([points, points[0]])

    return PolyData(
        points=points,
        _scene_data={
            "type": "circle",
            "radius": radius,
            "resolution": resolution,
        },
    )


def Arrow(  # noqa: N802, PLR0913
    start: tuple[float, float, float] = (0.0, 0.0, 0.0),
    direction: tuple[float, float, float] = (1.0, 0.0, 0.0),
    tip_length: float = 0.25,
    tip_radius: float = 0.1,
    tip_resolution: int = 20,  # noqa: ARG001
    shaft_radius: float = 0.05,
    shaft_resolution: int = 20,  # noqa: ARG001
    scale: float | None = None,
) -> PolyData:
    """Create an arrow mesh.

    Returns a :class:`PolyData` representing an arrow starting at ``start``
    and pointing in ``direction``, backed by vtk.js ``vtkArrowSource``.

    Parameters
    ----------
    start : tuple, optional
        Starting point of the arrow ``(x, y, z)``. Default is ``(0, 0, 0)``.
    direction : tuple, optional
        Direction vector of the arrow. Default is ``(1, 0, 0)``.
    tip_length : float, optional
        Length of the conical tip as a fraction of the total arrow length.
        Default is 0.25.
    tip_radius : float, optional
        Radius of the base of the tip. Default is 0.1.
    tip_resolution : int, optional
        Number of faces around the tip cone. Default is 20.
    shaft_radius : float, optional
        Radius of the cylindrical shaft. Default is 0.05.
    shaft_resolution : int, optional
        Number of faces around the shaft cylinder. Default is 20.
    scale : float, optional
        Scaling factor applied to the entire arrow. When ``None`` the arrow
        is not scaled.

    Returns
    -------
    PolyData
        An arrow mesh.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> arrow = pv.Arrow()
    >>> isinstance(arrow, pv.PolyData)
    True

    Create an arrow with a custom start point and direction:

    >>> arrow = pv.Arrow(start=(1, 0, 0), direction=(0, 1, 0))
    >>> isinstance(arrow, pv.PolyData)
    True

    Plot the arrow:

    >>> arrow.plot()  # doctest: +SKIP

    """
    direction_arr = np.asarray(direction, dtype=float)
    norm = float(np.linalg.norm(direction_arr))
    if norm == 0.0:
        msg = "direction must be a non-zero vector"
        raise ValueError(msg)
    unit_dir = direction_arr / norm

    length = 1.0 if scale is None else float(scale)

    # Build a simple representative point set: shaft start + tip end
    start_arr = np.asarray(start, dtype=float)
    end = start_arr + unit_dir * length
    points = np.array([start_arr, end])

    return PolyData(
        points=points,
        _scene_data={
            "type": "arrow",
            "tipLength": tip_length,
            "tipRadius": tip_radius,
            "shaftRadius": shaft_radius,
        },
    )


def Cone(  # noqa: N802 PLR0913
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    direction: tuple[float, float, float] = (1.0, 0.0, 0.0),
    height: float = 1.0,
    radius: float = 0.5,
    resolution: int = 6,
    capping: bool = True,  # noqa: FBT001 FBT002
) -> PolyData:
    """Create a cone mesh.

    Parameters
    ----------
    center : tuple, optional
        Center of the cone (x, y, z). Default is (0, 0, 0).
    direction : tuple, optional
        Direction vector of the cone axis. Default is (1, 0, 0).
    height : float, optional
        Height of the cone. Default is 1.0.
    radius : float, optional
        Base radius of the cone. Default is 0.5.
    resolution : int, optional
        Number of facets around the cone. Default is 6.
    capping : bool, optional
        Whether to cap the base of the cone. Default is True.

    Returns
    -------
    PolyData
        A cone mesh.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> cone = pv.Cone(center=(0, 0, 0), direction=(1, 0, 0), height=1.0, radius=0.5, resolution=6)
    >>> cone.plot()  # doctest: +SKIP

    """
    # Generate approximate points for the cone
    norm = np.linalg.norm(direction)
    d = np.asarray(direction, dtype=float) / (norm if norm > 0 else 1.0)

    # Build two perpendicular vectors to d
    perp1 = np.cross(d, [1.0, 0.0, 0.0]) if abs(d[0]) < 0.9 else np.cross(d, [0.0, 1.0, 0.0])  # noqa: PLR2004
    perp1 /= np.linalg.norm(perp1)
    perp2 = np.cross(d, perp1)

    apex = np.asarray(center, dtype=float) + d * (height / 2.0)
    base_center = np.asarray(center, dtype=float) - d * (height / 2.0)

    theta = np.linspace(0, 2 * np.pi, resolution, endpoint=False)
    base_points = np.array(
        [base_center + radius * (np.cos(t) * perp1 + np.sin(t) * perp2) for t in theta],
    )

    points = np.vstack([apex[np.newaxis, :], base_points])
    if capping:
        points = np.vstack([points, base_center[np.newaxis, :]])

    return PolyData(
        points=points,
        _scene_data={
            "type": "cone",
            "height": height,
            "radius": radius,
            "resolution": resolution,
        },
    )


def Line(  # noqa: N802
    pointa: tuple[float, float, float] = (0.0, 0.0, 0.0),
    pointb: tuple[float, float, float] = (1.0, 0.0, 0.0),
    resolution: int = 1,
) -> PolyData:
    """Create a line segment between two points.

    This mirrors the :func:`pyvista.Line` API, producing a polyline of
    ``resolution + 1`` evenly spaced points from ``pointa`` to ``pointb``.

    Parameters
    ----------
    pointa : tuple, optional
        Start point of the line (x, y, z). Default is (0, 0, 0).
    pointb : tuple, optional
        End point of the line (x, y, z). Default is (1, 0, 0).
    resolution : int, optional
        Number of line segments (i.e. ``resolution + 1`` points). Default is 1.

    Returns
    -------
    PolyData
        A line mesh.

    Raises
    ------
    ValueError
        If ``resolution`` is less than 1.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> line = pv.Line(pointa=(0, 0, 0), pointb=(1, 0, 0), resolution=1)
    >>> line.n_points
    2

    >>> line.plot(color="black")  # doctest: +SKIP

    """
    if resolution < 1:
        msg = f"resolution must be >= 1, got {resolution}"
        raise ValueError(msg)

    points = np.linspace(pointa, pointb, resolution + 1)

    return PolyData(
        points=points,
        _scene_data={
            "type": "line",
            "point1": list(pointa),
            "point2": list(pointb),
        },
    )


def Plane(  # noqa: N802 PLR0913
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    direction: tuple[float, float, float] = (0.0, 0.0, 1.0),
    i_size: float = 1.0,
    j_size: float = 1.0,
    i_resolution: int = 10,
    j_resolution: int = 10,
) -> PolyData:
    """Create a plane mesh.

    This mirrors the :func:`pyvista.Plane` API, producing a flat rectangular
    mesh oriented according to the given normal ``direction``.

    Parameters
    ----------
    center : tuple, optional
        Center of the plane (x, y, z). Default is (0, 0, 0).
    direction : tuple, optional
        Normal direction of the plane (x, y, z). Default is (0, 0, 1).
    i_size : float, optional
        Size in the i (first) direction. Default is 1.0.
    j_size : float, optional
        Size in the j (second) direction. Default is 1.0.
    i_resolution : int, optional
        Number of subdivisions in the i direction. Default is 10.
    j_resolution : int, optional
        Number of subdivisions in the j direction. Default is 10.

    Returns
    -------
    PolyData
        A plane mesh.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> plane = pv.Plane()
    >>> plane.n_points
    121

    >>> plane.plot()  # doctest: +SKIP

    """
    n = np.array(direction, dtype=float)
    n = n / np.linalg.norm(n)

    # Find two orthogonal vectors in the plane
    if not np.allclose(np.abs(n), [0.0, 1.0, 0.0]):
        ref = np.array([0.0, 1.0, 0.0])
    else:
        ref = np.array([1.0, 0.0, 0.0])
    i_hat = np.cross(ref, n)
    i_hat = i_hat / np.linalg.norm(i_hat)
    j_hat = np.cross(n, i_hat)
    j_hat = j_hat / np.linalg.norm(j_hat)

    c = np.array(center, dtype=float)
    origin = c - (i_size / 2) * i_hat - (j_size / 2) * j_hat

    # Build Python points grid for PolyData
    points = []
    for j in range(j_resolution + 1):
        for i in range(i_resolution + 1):
            p = origin + (i / i_resolution) * i_size * i_hat + (j / j_resolution) * j_size * j_hat
            points.append(p)

    # Build quad faces
    faces = []
    for j in range(j_resolution):
        for i in range(i_resolution):
            idx0 = j * (i_resolution + 1) + i
            idx1 = idx0 + 1
            idx2 = idx0 + i_resolution + 2
            idx3 = idx0 + i_resolution + 1
            faces.append([idx0, idx1, idx2, idx3])

    return PolyData(
        points=np.array(points),
        faces=np.array(faces),
        _scene_data={
            "type": "plane",
            "origin": [float(origin[0]), float(origin[1]), float(origin[2])],
            "normal": [float(n[0]), float(n[1]), float(n[2])],
        },
    )


def PointSource(  # noqa: N802
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
    n_points: int = 100,
    radius: float = 1.0,
) -> PolyData:
    """Create a point cloud distributed randomly inside a sphere.

    This mirrors the :func:`pyvista.PointSource` API. The points are
    generated by vtk.js at render time and rendered as isolated vertices.

    Parameters
    ----------
    center : tuple, optional
        Center of the sphere (x, y, z). Default is (0, 0, 0).
    n_points : int, optional
        Number of generated points. Default is 100.
    radius : float, optional
        Radius of the bounding sphere. Default is 1.0.

    Returns
    -------
    PolyData
        A point cloud mesh.

    Raises
    ------
    ValueError
        If ``n_points`` is less than 1 or ``radius`` is not positive.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> cloud = pv.PointSource(n_points=100, radius=1.0)
    >>> cloud.n_points
    100

    Render the point cloud:

    >>> cloud.plot()  # doctest: +SKIP

    """
    if n_points < 1:
        msg = f"n_points must be at least 1, got {n_points}"
        raise ValueError(msg)
    if radius <= 0:
        msg = f"radius must be positive, got {radius}"
        raise ValueError(msg)

    return PolyData(
        points=np.zeros((n_points, _POINT_CLOUD_COMPONENTS)),
        _scene_data={
            "type": "pointSource",
            "center": list(center),
            "radius": radius,
            "nPoints": n_points,
        },
    )


def PlatonicSolid(  # noqa: N802
    kind: str = "octahedron",
    radius: float = 1.0,
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> PolyData:
    """Create one of the Platonic solids.

    This mirrors the :func:`pyvista.PlatonicSolid` API. The geometry is
    generated by vtk.js at render time.

    Parameters
    ----------
    kind : str, optional
        One of 'tetrahedron', 'cube', 'octahedron', 'icosahedron',
        or 'dodecahedron'. Default is 'octahedron'.
    radius : float, optional
        Circumradius of the solid. Default is 1.0.
    center : tuple, optional
        Center of the solid (x, y, z). Default is (0, 0, 0).

    Returns
    -------
    PolyData
        A Platonic solid mesh.

    Raises
    ------
    ValueError
        If ``kind`` is not a valid solid name.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> solid = pv.PlatonicSolid(kind='dodecahedron', radius=1.0)
    >>> isinstance(solid, pv.PolyData)
    True

    Render the solid:

    >>> solid.plot()  # doctest: +SKIP

    """
    solids = ("tetrahedron", "cube", "octahedron", "icosahedron", "dodecahedron")
    if kind not in solids:
        msg = f"kind must be one of {list(solids)}, got '{kind}'"
        raise ValueError(msg)
    if radius <= 0:
        msg = f"radius must be positive, got {radius}"
        raise ValueError(msg)

    return PolyData(
        points=np.zeros((1, _POINT_CLOUD_COMPONENTS)),
        _scene_data={
            "type": "platonicSolid",
            "kind": kind,
            "radius": radius,
            "center": list(center),
        },
    )


def RegularPolygon(  # noqa: N802
    n_sides: int = 6,
    radius: float = 0.5,
    center: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> PolyData:
    """Create a regular polygon in the XY plane.

    This mirrors the :func:`pyvista.RegularPolygon` API. The geometry is
    generated by vtk.js at render time.

    Parameters
    ----------
    n_sides : int, optional
        Number of polygon sides. Must be at least 3. Default is 6.
    radius : float, optional
        Distance from the center to a vertex. Default is 0.5.
    center : tuple, optional
        Center of the polygon (x, y, z). Default is (0, 0, 0).

    Returns
    -------
    PolyData
        A regular polygon mesh.

    Raises
    ------
    ValueError
        If ``n_sides`` is less than 3 or ``radius`` is not positive.

    Examples
    --------
    >>> import pyvista_js as pv
    >>> hexagon = pv.RegularPolygon(n_sides=6, radius=0.5)
    >>> isinstance(hexagon, pv.PolyData)
    True

    Render the polygon:

    >>> hexagon.plot()  # doctest: +SKIP

    """
    if n_sides < _CIRCLE_MIN_RESOLUTION:
        msg = f"n_sides must be at least {_CIRCLE_MIN_RESOLUTION}, got {n_sides}"
        raise ValueError(msg)
    if radius <= 0:
        msg = f"radius must be positive, got {radius}"
        raise ValueError(msg)

    return PolyData(
        points=np.zeros((n_sides, _POINT_CLOUD_COMPONENTS)),
        _scene_data={
            "type": "regularPolygon",
            "nSides": n_sides,
            "radius": radius,
            "center": list(center),
        },
    )
